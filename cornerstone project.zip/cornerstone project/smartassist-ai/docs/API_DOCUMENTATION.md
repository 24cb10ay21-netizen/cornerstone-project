# SmartAssist AI - Complete REST API Catalog

Base URL: `http://127.0.0.1:5000/api`

## 1. Authentication Endpoints

### Register Account
- **Endpoint:** `POST /api/auth/register`
- **Payload:**
```json
{
  "email": "alex.chen@smartassist.edu",
  "password": "password123",
  "full_name": "Alex Chen",
  "role": "student",
  "department": "Computer Science",
  "program": "B.Tech CSE",
  "semester": 6
}
```
- **Response:** `201 Created` with JWT token and user profile object.

### Login Account
- **Endpoint:** `POST /api/auth/login`
- **Payload:**
```json
{
  "email": "alex.student@smartassist.edu",
  "password": "student123"
}
```
- **Response:** `200 OK` with token and user object.

### Current User Profile
- **Endpoint:** `GET /api/auth/me`
- **Headers:** `Authorization: Bearer <token>`
- **Response:** `200 OK` with user details.

---

## 2. Conversational AI & RAG Endpoints

### Send Chat Query
- **Endpoint:** `POST /api/chat/message`
- **Payload:**
```json
{
  "query": "What is the minimum attendance requirement for examinations?",
  "domain": "student",
  "conversation_id": null
}
```
- **Response:** `200 OK`
```json
{
  "status": "success",
  "data": {
    "conversation_id": 1,
    "answer": "### Admissions Guidelines\n\nStudents must maintain a minimum of 75% aggregate attendance...",
    "domain": "student",
    "intent": "attendance",
    "confidence": 0.94,
    "sources": [
      {
        "title": "FAQ: What is the mandatory minimum attendance percentage?",
        "category": "Attendance",
        "relevance": 0.92
      }
    ],
    "suggested_questions": [
      "What happens if attendance is between 65% and 75%?",
      "How do I submit a medical leave certificate?"
    ],
    "can_escalate": false,
    "response_time_ms": 160
  }
}
```

### Submit Message Feedback
- **Endpoint:** `POST /api/chat/feedback`
- **Payload:** `{"message_id": 2, "rating": 1}`

---

## 3. Support Ticket Endpoints

### List User / All Tickets
- **Endpoint:** `GET /api/tickets?status=open&domain=student`
- **Headers:** `Authorization: Bearer <token>`

### Create New Support Ticket
- **Endpoint:** `POST /api/tickets`
- **Headers:** `Authorization: Bearer <token>`
- **Payload:**
```json
{
  "subject": "Missing Lab Marks in ERP",
  "description": "Database Systems practical marks missing.",
  "domain": "student",
  "category": "Examinations",
  "priority": "high"
}
```

### Thread Reply to Ticket
- **Endpoint:** `POST /api/tickets/:id/respond`
- **Payload:** `{"message": "Faculty confirmed lab marks updated."}`

### Admin Update Ticket Status
- **Endpoint:** `PATCH /api/tickets/:id/status`
- **Headers:** `Authorization: Bearer <admin_token>`
- **Payload:**
```json
{
  "status": "resolved",
  "admin_response": "Marks synchronized in ERP portal."
}
```

---

## 4. Administrator & Knowledge Base Endpoints

### System Overview
- **Endpoint:** `GET /api/admin/overview`
- **Headers:** `Authorization: Bearer <admin_token>`

### Upload & Chunk Document
- **Endpoint:** `POST /api/knowledge/upload`
- **Headers:** `multipart/form-data` with `file`, `title`, `domain`, `category`.

### Re-Index Vector Space
- **Endpoint:** `POST /api/knowledge/reindex`
- **Headers:** `Authorization: Bearer <admin_token>`
