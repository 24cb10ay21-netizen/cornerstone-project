# SmartAssist AI - System Architecture

```mermaid
flowchart TD
    subgraph ClientLayer ["Client & User Presentation Layer"]
        UI_Student["Student Portal (React + Vite + Tailwind)"]
        UI_Customer["Customer Care Portal (React + Tailwind)"]
        UI_Admin["Admin Management Suite (React + Charts)"]
        Chat_Component["Dual-Domain Interactive Chatbot"]
    end

    subgraph GatewayLayer ["API Gateway & Security Layer"]
        Flask_Server["REST API Gateway (Python / Flask)"]
        CORS_Handler["CORS & Origin Filtering"]
        JWT_Auth["JWT Token Authentication (HS256)"]
        RBAC["Role-Based Access Control (Student | Customer | Admin)"]
    end

    subgraph AIEngine ["AI & NLP Processing Core"]
        Preprocessor["Query Normalizer & Typo Corrector"]
        Classifier["Intent & Domain Classifier"]
        
        subgraph RAGPipeline ["Retrieval-Augmented Generation (RAG)"]
            Doc_Processor["Document Chunking Engine (Sliding Window)"]
            Vector_Store["In-Memory Vector Space Store (TF-IDF & BM25)"]
            Retriever["Context Retriever & Threshold Filter"]
            LLM_Interface["Configurable LLM Client"]
            Local_Synthesizer["Zero-Hallucination Local Synthesizer"]
            Gemini_API["Google Gemini Pro / Flash API (Optional)"]
        end
    end

    subgraph DataLayer ["Data & Storage Persistence Layer"]
        SQLite_DB[("SQLite / PostgreSQL Database")]
        File_Storage["Document & Upload File Storage"]
    end

    %% Connections
    UI_Student -->|REST / JSON| Flask_Server
    UI_Customer -->|REST / JSON| Flask_Server
    UI_Admin -->|REST / JSON| Flask_Server
    Chat_Component -->|REST / JSON| Flask_Server

    Flask_Server --> CORS_Handler
    CORS_Handler --> JWT_Auth
    JWT_Auth --> RBAC

    Flask_Server --> Preprocessor
    Preprocessor --> Classifier
    Classifier --> Retriever
    
    Doc_Processor --> Vector_Store
    Retriever --> Vector_Store
    Retriever --> Local_Synthesizer
    Retriever --> LLM_Interface
    LLM_Interface -.-> Gemini_API

    Flask_Server --> SQLite_DB
    Doc_Processor --> File_Storage
```

---

## Architectural Principles

1. **Dual Independent Domains**: Complete data and prompt isolation between academic student services and commercial customer care.
2. **Zero-Hallucination Guardrails**: The RAG synthesizer responds strictly using verified chunks. When similarity scores fall below the threshold (0.15), it generates an empathetic fallback notice and provides a 1-click ticket escalation action.
3. **High-Performance In-Memory Vector Search**: TF-IDF and BM25 cosine retrieval executes in under 10 milliseconds without requiring heavy external GPU runtimes.
4. **Single-Port Production Deployment**: The Flask backend serves both the compiled React SPA static assets and the `/api/*` REST endpoints on port 5000.
