# SmartAssist AI - Project Workflow & User Journeys

## 1. RAG Query Resolution Workflow

```mermaid
sequenceDiagram
    autonumber
    actor User as Student / Customer
    participant UI as Chat Interface (React)
    participant API as Flask REST Gateway
    participant NLU as Intent Classifier
    participant Vector as Vector Store (TF-IDF/BM25)
    participant LLM as RAG Synthesizer
    participant DB as SQLite / PostgreSQL

    User->>UI: Enters query ("What is the minimum attendance?")
    UI->>API: POST /api/chat/message { query, domain }
    API->>NLU: Classify domain & fine-grained intent
    NLU-->>API: { domain: "student", intent: "attendance", confidence: 0.94 }
    
    API->>Vector: Search top chunks (threshold >= 0.15)
    Vector-->>API: Chunks: Student Handbook Section 3 (score: 0.82)
    
    alt Verified Context Found
        API->>LLM: Synthesize Grounded Response (Context + Rules)
        LLM-->>API: Formatted Answer + Follow-up chips + Citations
        API->>DB: Store user query, assistant reply, and analytics log
        API-->>UI: 200 OK { answer, sources, suggestions }
        UI-->>User: Displays verified answer & citations
    else Information Not in Knowledge Base
        API->>LLM: Apply Fallback Guardrail
        LLM-->>API: "Information unverified. Would you like to open a ticket?"
        API-->>UI: 200 OK { answer, is_fallback: true, can_escalate: true }
        UI-->>User: Displays Fallback message with "Open Ticket" button
    end
```

---

## 2. Support Ticket Escalation & Incident Resolution Workflow

```mermaid
flowchart TD
    Start([User Query Triggers Fallback / Complex Issue]) --> EscalateChoice{User clicks 'Escalate to Ticket'?}
    
    EscalateChoice -->|Yes| AutoPopulate[System auto-populates query text, domain & category]
    AutoPopulate --> CreateTicket[POST /api/tickets]
    CreateTicket --> DB_Insert[(Assign unique ID e.g. TCK-STU-1002)]
    
    DB_Insert --> AdminAlert[Ticket appears in Admin Incident Dashboard]
    AdminAlert --> AdminReview[Admin reviews query context & student/customer history]
    
    AdminReview --> AdminAction{Action Needed}
    AdminAction -->|Clarification Required| PostReply[Admin posts threaded response]
    PostReply --> UserNotified[User views admin reply on Tickets Page and responds]
    UserNotified --> AdminReview
    
    AdminAction -->|Official Resolution| ResolveTicket[Admin marks Resolved and enters resolution statement]
    ResolveTicket --> CloseTicket[Status: 'Resolved' + Timestamp recorded]
    CloseTicket --> End([User views resolution note & gives thumbs up rating])
```
