# SmartAssist AI - Database Entity-Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS ||--o| STUDENT_PROFILES : "has profile"
    USERS ||--o| CUSTOMER_PROFILES : "has profile"
    USERS ||--o{ CONVERSATIONS : "starts"
    USERS ||--o{ SUPPORT_TICKETS : "opens"
    USERS ||--o{ TICKET_RESPONSES : "posts"
    USERS ||--o{ USER_FEEDBACK : "submits"
    
    CONVERSATIONS ||--o{ CHAT_MESSAGES : "contains"
    KNOWLEDGE_DOCUMENTS ||--o{ DOCUMENT_CHUNKS : "chunked into"
    SUPPORT_TICKETS ||--o{ TICKET_RESPONSES : "threads"

    USERS {
        int id PK
        string email UK
        string password_hash
        string full_name
        string role "student | customer | admin"
        boolean is_active
        timestamp created_at
        timestamp updated_at
    }

    STUDENT_PROFILES {
        int id PK
        int user_id FK
        string student_id UK
        string department
        string program
        int year_of_study
        int semester
        string roll_number
        float cgpa
        float attendance_pct
    }

    CUSTOMER_PROFILES {
        int id PK
        int user_id FK
        string customer_code UK
        string company_name
        string phone_number
        string customer_tier
        string address
    }

    CONVERSATIONS {
        int id PK
        int user_id FK
        string title
        string domain "student | customer"
        timestamp created_at
        timestamp updated_at
    }

    CHAT_MESSAGES {
        int id PK
        int conversation_id FK
        string sender "user | assistant | system"
        text text
        string intent
        float confidence
        text sources_json
        int helpful_rating "1: Helpful | -1: Unhelpful"
        timestamp created_at
    }

    KNOWLEDGE_DOCUMENTS {
        int id PK
        string title
        string domain "student | customer | general"
        string category
        string file_path
        string file_type
        text content
        int chunk_count
        boolean is_active
        timestamp created_at
    }

    DOCUMENT_CHUNKS {
        int id PK
        int document_id FK
        int chunk_index
        text content
        string category
        string domain
        timestamp created_at
    }

    FAQS {
        int id PK
        string domain "student | customer"
        string category
        string question
        text answer
        string keywords
        int view_count
        boolean is_active
        timestamp created_at
    }

    SUPPORT_TICKETS {
        int id PK
        string ticket_number UK
        int user_id FK
        string domain "student | customer"
        string category
        string subject
        text description
        string priority "low | medium | high | urgent"
        string status "open | in_progress | resolved | closed"
        text admin_response
        timestamp resolved_at
        timestamp created_at
        timestamp updated_at
    }

    TICKET_RESPONSES {
        int id PK
        int ticket_id FK
        int sender_id FK
        string sender_name
        string sender_role
        text message
        timestamp created_at
    }

    USER_FEEDBACK {
        int id PK
        int user_id FK
        string domain "student | customer"
        int rating "1 to 5"
        string category
        text feedback_text
        timestamp created_at
    }

    CHATBOT_ANALYTICS {
        int id PK
        timestamp timestamp
        string domain
        string query_text
        string intent
        float confidence
        int response_time_ms
        boolean was_answered
        string resolution_method
        int feedback
    }
```
