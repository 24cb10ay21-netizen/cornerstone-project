import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BASE_DIR.parent

class Settings:
    # App
    PROJECT_NAME: str = "SmartAssist AI"
    VERSION: str = "1.0.0"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() in ("true", "1")
    
    # Security
    SECRET_KEY: str = os.getenv("SECRET_KEY", "smartassist-super-secret-jwt-key-2026-production")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440")) # 24 hours
    
    # Database
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        f"sqlite:///{BASE_DIR / 'database' / 'smartassist.db'}"
    )
    
    # LLM Settings
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "auto") # auto | gemini | openai | offline
    
    # RAG Settings
    CHUNK_SIZE: int = int(os.getenv("CHUNK_SIZE", "450"))
    CHUNK_OVERLAP: int = int(os.getenv("CHUNK_OVERLAP", "50"))
    TOP_K_RESULTS: int = int(os.getenv("TOP_K_RESULTS", "4"))
    SIMILARITY_THRESHOLD: float = float(os.getenv("SIMILARITY_THRESHOLD", "0.25"))
    
    # Uploads
    UPLOAD_FOLDER: Path = BASE_DIR / "uploads"
    KNOWLEDGE_BASE_FOLDER: Path = BASE_DIR / "knowledge_base"
    MAX_CONTENT_LENGTH: int = 16 * 1024 * 1024 # 16 MB max upload
    ALLOWED_EXTENSIONS: set = {"txt", "pdf", "docx", "md", "csv", "json"}

settings = Settings()

# Ensure directories exist
settings.UPLOAD_FOLDER.mkdir(parents=True, exist_ok=True)
settings.KNOWLEDGE_BASE_FOLDER.mkdir(parents=True, exist_ok=True)
(BASE_DIR / "database").mkdir(parents=True, exist_ok=True)
