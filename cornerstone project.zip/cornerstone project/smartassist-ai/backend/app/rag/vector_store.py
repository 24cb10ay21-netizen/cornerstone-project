import math
import re
from collections import Counter
from typing import List, Dict, Any, Optional

def tokenize(text: str) -> List[str]:
    return [w for w in re.findall(r'\b[a-zA-Z0-9_-]+\b', text.lower()) if len(w) > 1]

class VectorStore:
    def __init__(self):
        # We store chunks separately per domain ('student', 'customer')
        self.documents: Dict[str, List[Dict[str, Any]]] = {
            "student": [],
            "customer": []
        }
        self.doc_freqs: Dict[str, Dict[str, int]] = {
            "student": Counter(),
            "customer": Counter()
        }
        self.idf: Dict[str, Dict[str, float]] = {
            "student": {},
            "customer": {}
        }

    def clear(self, domain: Optional[str] = None):
        if domain:
            self.documents[domain] = []
            self.doc_freqs[domain] = Counter()
            self.idf[domain] = {}
        else:
            for d in ["student", "customer"]:
                self.documents[d] = []
                self.doc_freqs[d] = Counter()
                self.idf[d] = {}

    def add_chunk(self, domain: str, chunk_id: str, content: str, title: str, category: str, source_type: str = "doc"):
        if domain not in self.documents:
            self.documents[domain] = []
            self.doc_freqs[domain] = Counter()
            self.idf[domain] = {}
            
        tokens = tokenize(content + " " + title + " " + category)
        term_counts = Counter(tokens)
        
        self.documents[domain].append({
            "id": chunk_id,
            "title": title,
            "category": category,
            "content": content,
            "source_type": source_type,
            "term_counts": term_counts,
            "token_length": len(tokens)
        })
        
        # Update document frequency for IDF
        for term in set(tokens):
            self.doc_freqs[domain][term] += 1

    def build_index(self, domain: Optional[str] = None):
        domains = [domain] if domain else ["student", "customer"]
        for d in domains:
            n_docs = len(self.documents[d])
            if n_docs == 0:
                self.idf[d] = {}
                continue
            self.idf[d] = {
                term: math.log(1.0 + (n_docs / (freq + 1.0)))
                for term, freq in self.doc_freqs[d].items()
            }

    def search(self, query: str, domain: str, top_k: int = 4, threshold: float = 0.15) -> List[Dict[str, Any]]:
        if domain not in self.documents or not self.documents[domain]:
            return []
            
        q_tokens = tokenize(query)
        if not q_tokens:
            return []
            
        q_counts = Counter(q_tokens)
        domain_idf = self.idf.get(domain, {})
        
        # Calculate Query Vector magnitude
        q_norm = 0.0
        for term, count in q_counts.items():
            idf = domain_idf.get(term, 0.5)
            q_norm += (count * idf) ** 2
        q_norm = math.sqrt(q_norm) if q_norm > 0 else 1.0
        
        scores = []
        for doc in self.documents[domain]:
            doc_counts = doc["term_counts"]
            dot_product = 0.0
            doc_norm = 0.0
            
            # TF-IDF dot product calculation
            for term, count in doc_counts.items():
                idf = domain_idf.get(term, 0.5)
                w_doc = (1.0 + math.log(count)) * idf
                doc_norm += w_doc ** 2
                if term in q_counts:
                    w_query = (1.0 + math.log(q_counts[term])) * idf
                    dot_product += w_doc * w_query
                    
            doc_norm = math.sqrt(doc_norm) if doc_norm > 0 else 1.0
            similarity = dot_product / (q_norm * doc_norm) if (q_norm * doc_norm) > 0 else 0.0
            
            # Boost score if category or title matches query terms
            title_lower = doc["title"].lower()
            category_lower = doc["category"].lower()
            for token in q_tokens:
                if token in title_lower:
                    similarity += 0.08
                if token in category_lower:
                    similarity += 0.05
                    
            if similarity >= threshold:
                scores.append({
                    "id": doc["id"],
                    "title": doc["title"],
                    "category": doc["category"],
                    "content": doc["content"],
                    "source_type": doc["source_type"],
                    "score": round(min(1.0, similarity), 3)
                })
                
        # Sort descending by score
        scores.sort(key=lambda x: x["score"], reverse=True)
        return scores[:top_k]

# Global singleton
vector_store = VectorStore()
