import os
import json
import urllib.request
from typing import List, Dict, Any, Optional
from config.settings import settings

class LLMClient:
    def __init__(self):
        self.gemini_key = settings.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY", "")
        self.openai_key = settings.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY", "")
        self.provider = settings.LLM_PROVIDER

    def generate_response(
        self, 
        query: str, 
        domain: str, 
        intent_info: Dict[str, Any], 
        retrieval_data: Dict[str, Any], 
        chat_history: Optional[List[Dict[str, str]]] = None
    ) -> Dict[str, Any]:
        """
        Orchestrates LLM generation or precise local RAG synthesis strictly grounded in verified context.
        """
        has_context = retrieval_data.get("has_context", False)
        chunks = retrieval_data.get("results", [])
        intent = intent_info.get("intent", "general")
        category = intent_info.get("category", "General")
        
        # 1. Check if greeting
        if intent.startswith("greeting"):
            if domain == "student":
                msg = (
                    "Hello! 👋 I am your **SmartAssist Student AI Advisor**. "
                    "I can assist you with college admissions, course syllabi, examination schedules, "
                    "fee structure, scholarships, attendance criteria, placement drives, and campus facilities. "
                    "\n\nHow can I help you today?"
                )
                suggestions = [
                    "What is the minimum attendance requirement?",
                    "How can I apply for merit scholarships?",
                    "When does the semester examination start?"
                ]
            else:
                msg = (
                    "Welcome to **SmartAssist Customer Support**! 🛍️ "
                    "I am here to answer product specifications, order tracking updates, "
                    "pricing queries, return/refund policies, and technical troubleshooting. "
                    "\n\nHow may I assist your business or order today?"
                )
                suggestions = [
                    "How do I track my active order?",
                    "What is your return and refund policy?",
                    "How do I request an enterprise quote?"
                ]
                
            return {
                "answer": msg,
                "engine": "rule_based_greeting",
                "is_fallback": False,
                "sources": [],
                "suggested_questions": suggestions,
                "can_escalate": False
            }

        # 2. If NO verified context found in knowledge base -> Strict No-Hallucination Fallback
        if not has_context or not chunks:
            if domain == "student":
                fallback_msg = (
                    "⚠️ **Information Not Found in Official Student Records**\n\n"
                    "I could not locate verified university guidelines or records for your question in our current knowledge base. "
                    "To prevent misinformation regarding official college policies, fees, or examination regulations, "
                    "I avoid making assumptions.\n\n"
                    "👉 **Recommended Action:** Would you like to **create a support ticket**? "
                    "Your query will be routed directly to the Academic Dean or Administrative Office for an official response."
                )
                suggestions = [
                    "Contact Student Affairs Office",
                    "Check Academic Calendar",
                    "Browse Student FAQs"
                ]
            else:
                fallback_msg = (
                    "⚠️ **Verified Information Unavailable**\n\n"
                    "I am unable to find verified documentation or records matching your query in our customer database. "
                    "To ensure you receive strictly accurate assistance without speculation on warranties, billing, or policies:\n\n"
                    "👉 **Recommended Action:** Please click **Create Support Ticket** below. "
                    "Our customer care team will review your account and get back to you shortly."
                )
                suggestions = [
                    "Check Order Status",
                    "View Refund Policy",
                    "Contact Technical Support"
                ]
                
            return {
                "answer": fallback_msg,
                "engine": "strict_fallback_guardrail",
                "is_fallback": True,
                "sources": [],
                "suggested_questions": suggestions,
                "can_escalate": True
            }

        # 3. Context is available: Try external LLM API if key provided
        context_text = "\n\n---\n\n".join([
            f"[Source: {c['title']} | Category: {c['category']}]\n{c['content']}"
            for c in chunks
        ])
        
        if self.gemini_key and (self.provider in ["auto", "gemini"]):
            gemini_ans = self._call_gemini(query, domain, context_text, chat_history)
            if gemini_ans:
                return {
                    "answer": gemini_ans,
                    "engine": "google_gemini_pro",
                    "is_fallback": False,
                    "sources": retrieval_data.get("sources", []),
                    "suggested_questions": self._generate_suggestions(domain, intent),
                    "can_escalate": False
                }
                
        # 4. Default: Production-grade Local RAG Synthesizer (Fast, reliable, zero token cost)
        synthesized_answer = self._synthesize_local_rag(query, domain, intent_info, chunks)
        
        return {
            "answer": synthesized_answer,
            "engine": "smartassist_rag_engine",
            "is_fallback": False,
            "sources": retrieval_data.get("sources", []),
            "suggested_questions": self._generate_suggestions(domain, intent),
            "can_escalate": False
        }

    def _synthesize_local_rag(self, query: str, domain: str, intent_info: Dict[str, Any], chunks: List[Dict[str, Any]]) -> str:
        """
        Synthesizes a structured, natural language, context-grounded response from verified chunks.
        """
        top_chunk = chunks[0]
        content = top_chunk["content"].strip()
        title = top_chunk["title"]
        category = top_chunk["category"]
        
        # Format a professional answer header
        parts = []
        parts.append(f"### 📋 {category} Guidelines")
        parts.append(f"{content}\n")
        
        # If additional relevant chunks exist, append relevant highlights
        if len(chunks) > 1:
            parts.append("#### 🔍 Additional Verified Details:")
            for extra in chunks[1:3]:
                # extract first sentence or 140 chars
                first_line = extra["content"].split("\n")[0]
                if len(first_line) > 120:
                    first_line = first_line[:120] + "..."
                parts.append(f"- **{extra['title']}:** {first_line}")
                
        parts.append(f"\n*Source verified against official {domain.capitalize()} Knowledge Repository.*")
        return "\n\n".join(parts)

    def _call_gemini(self, query: str, domain: str, context: str, chat_history: Optional[List[Dict[str, str]]]) -> Optional[str]:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.gemini_key}"
            
            system_prompt = (
                f"You are SmartAssist AI, an expert, courteous, and accurate support agent for {domain.upper()} support.\n"
                f"STRICT INSTRUCTION: Answer the user's question using ONLY the provided verified context.\n"
                f"If the answer cannot be found in the context, clearly state that information is unavailable and advise opening a ticket.\n"
                f"Do not invent fees, rules, or order details. Format your response clearly in Markdown.\n\n"
                f"VERIFIED CONTEXT:\n{context}"
            )
            
            payload = {
                "contents": [
                    {"role": "user", "parts": [{"text": f"{system_prompt}\n\nUser Question: {query}"}]}
                ]
            }
            
            data = json.dumps(payload).encode('utf-8')
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                res_json = json.loads(resp.read().decode('utf-8'))
                text = res_json['candidates'][0]['content']['parts'][0]['text']
                return text.strip()
        except Exception:
            return None

    def _generate_suggestions(self, domain: str, intent: str) -> List[str]:
        suggestions_map = {
            "admissions": [
                "What is the eligibility criteria for B.Tech CS?",
                "What documents are required during admission?",
                "What is the last date for fee submission?"
            ],
            "fees": [
                "Can I pay tuition fees in installments?",
                "What is the late fee policy?",
                "How do I download my fee receipt?"
            ],
            "examinations": [
                "When will semester exam admit cards be issued?",
                "What is the procedure for revaluation?",
                "What is the minimum passing grade?"
            ],
            "attendance": [
                "What happens if attendance is between 65% and 75%?",
                "How do I submit a medical leave certificate?",
                "Where can I check my daily attendance percentage?"
            ],
            "scholarships": [
                "What are the eligibility criteria for merit scholarships?",
                "When is the application deadline for financial aid?",
                "Are government scholarships accepted?"
            ],
            "placements": [
                "What was the highest package offered last season?",
                "Which top tech companies visit campus drives?",
                "Are internships mandatory in 3rd year?"
            ],
            "product_info": [
                "What are the technical specifications?",
                "Is this product covered under manufacturer warranty?",
                "Can I see product user manuals?"
            ],
            "order_status": [
                "How do I track my active courier package?",
                "What is the standard delivery timeframe?",
                "How do I update my shipping address?"
            ],
            "refund_cancellation": [
                "How many days do I have to request a refund?",
                "What is the refund processing timeline?",
                "Can I cancel an order before dispatch?"
            ],
            "complaints": [
                "How do I escalate an unresolved complaint?",
                "Where can I upload photos of a damaged item?",
                "What is the complaint resolution turnaround time?"
            ]
        }
        
        if intent in suggestions_map:
            return suggestions_map[intent]
            
        if domain == "student":
            return [
                "Tell me about course syllabus & electives",
                "What are the library hours and book issue limits?",
                "Who should I contact for student affairs?"
            ]
        else:
            return [
                "How can I request enterprise bulk pricing?",
                "What payment methods do you accept?",
                "How do I speak to human technical support?"
            ]

llm_client = LLMClient()
