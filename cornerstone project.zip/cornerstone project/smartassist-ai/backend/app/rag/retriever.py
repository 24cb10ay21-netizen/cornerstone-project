from typing import List, Dict, Any
from app.rag.vector_store import vector_store
from app.utils.db import get_db_connection

class Retriever:
    @staticmethod
    def retrieve_context(query: str, domain: str, top_k: int = 4, threshold: float = 0.15) -> Dict[str, Any]:
        """
        Retrieves top relevant chunks from vector store and verified FAQs from the database.
        """
        # Vector search
        chunks = vector_store.search(query=query, domain=domain, top_k=top_k, threshold=threshold)
        
        # Also check FAQs directly in database for fast keyword matches
        conn = get_db_connection()
        faqs = conn.execute(
            "SELECT id, question, answer, category FROM faqs WHERE domain = ? AND is_active = 1",
            (domain,)
        ).fetchall()
        conn.close()
        
        q_lower = query.lower()
        faq_matches = []
        for faq in faqs:
            f_q = faq["question"].lower()
            # If high overlap
            overlap_words = set(q_lower.split()).intersection(set(f_q.split()))
            if len(overlap_words) >= 3 or f_q in q_lower or q_lower in f_q:
                faq_matches.append({
                    "id": f"faq_{faq['id']}",
                    "title": f"FAQ: {faq['question']}",
                    "category": faq["category"],
                    "content": faq["answer"],
                    "source_type": "faq",
                    "score": 0.92
                })
                
        # Merge results, prioritizing exact FAQ matches
        combined = []
        seen_contents = set()
        
        for item in faq_matches + chunks:
            # Simple content fingerprint to avoid duplicates
            snippet = item["content"][:80].strip()
            if snippet not in seen_contents:
                seen_contents.add(snippet)
                combined.append(item)
                
        combined.sort(key=lambda x: x["score"], reverse=True)
        final_results = combined[:top_k]
        
        max_score = final_results[0]["score"] if final_results else 0.0
        
        return {
            "has_context": len(final_results) > 0 and max_score >= threshold,
            "max_score": max_score,
            "results": final_results,
            "sources": [
                {
                    "title": r["title"],
                    "category": r["category"],
                    "source_type": r["source_type"],
                    "relevance": r["score"]
                }
                for r in final_results
            ]
        }
