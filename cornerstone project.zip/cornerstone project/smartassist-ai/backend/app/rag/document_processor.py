import re
from pathlib import Path
from typing import List, Dict, Any

class DocumentProcessor:
    @staticmethod
    def chunk_text(text: str, chunk_size: int = 400, overlap: int = 50) -> List[str]:
        """
        Splits text into semantic chunks respecting paragraphs, bullet points, and sentences.
        """
        text = text.strip()
        if not text:
            return []
            
        # First split into paragraphs
        paragraphs = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
        chunks = []
        current_chunk = []
        current_length = 0
        
        for para in paragraphs:
            para_len = len(para)
            if current_length + para_len <= chunk_size:
                current_chunk.append(para)
                current_length += para_len + 2
            else:
                if current_chunk:
                    chunks.append("\n\n".join(current_chunk))
                # If paragraph itself exceeds chunk_size, split by sentences
                if para_len > chunk_size:
                    sentences = re.split(r'(?<=[.!?])\s+', para)
                    s_chunk = []
                    s_len = 0
                    for s in sentences:
                        if s_len + len(s) <= chunk_size:
                            s_chunk.append(s)
                            s_len += len(s) + 1
                        else:
                            if s_chunk:
                                chunks.append(" ".join(s_chunk))
                            s_chunk = [s]
                            s_len = len(s)
                    if s_chunk:
                        current_chunk = s_chunk
                        current_length = s_len
                    else:
                        current_chunk = []
                        current_length = 0
                else:
                    current_chunk = [para]
                    current_length = para_len
                    
        if current_chunk:
            chunks.append("\n\n".join(current_chunk))
            
        return [c.strip() for c in chunks if len(c.strip()) > 20]

    @staticmethod
    def extract_text_from_file(file_path: Path) -> str:
        """Extracts text content from various supported file extensions."""
        suffix = file_path.suffix.lower()
        
        if suffix in [".txt", ".md", ".json", ".csv"]:
            try:
                return file_path.read_text(encoding='utf-8', errors='ignore')
            except Exception:
                return file_path.read_text(encoding='latin-1', errors='ignore')
                
        if suffix == ".pdf":
            try:
                import pypdf
                reader = pypdf.PdfReader(str(file_path))
                pages = [page.extract_text() for page in reader.pages if page.extract_text()]
                return "\n\n".join(pages)
            except Exception:
                # Fallback to plain binary extraction or notice
                return f"[PDF document: {file_path.name}]"
                
        if suffix == ".docx":
            try:
                import docx
                doc = docx.Document(str(file_path))
                paras = [p.text for p in doc.paragraphs if p.text.strip()]
                return "\n\n".join(paras)
            except Exception:
                return f"[DOCX document: {file_path.name}]"
                
        return file_path.read_text(encoding='utf-8', errors='ignore')
