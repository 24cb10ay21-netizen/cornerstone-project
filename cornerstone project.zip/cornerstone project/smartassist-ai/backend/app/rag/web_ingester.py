import re
import urllib.request
import urllib.error
from html.parser import HTMLParser
from typing import Dict, Any, Tuple

class HTMLContentExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.text_parts = []
        self.page_title = ""
        self.in_title = False
        self.ignored_tags = {'script', 'style', 'nav', 'footer', 'header', 'noscript', 'svg', 'iframe'}
        self.current_ignored = 0

    def handle_starttag(self, tag, attrs):
        tag_lower = tag.lower()
        if tag_lower in self.ignored_tags:
            self.current_ignored += 1
        if tag_lower == 'title':
            self.in_title = True

    def handle_endtag(self, tag):
        tag_lower = tag.lower()
        if tag_lower in self.ignored_tags and self.current_ignored > 0:
            self.current_ignored -= 1
        if tag_lower == 'title':
            self.in_title = False
        if tag_lower in {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr', 'article', 'section'}:
            self.text_parts.append('\n')

    def handle_data(self, data):
        if self.in_title:
            self.page_title += data
        elif self.current_ignored == 0:
            clean = data.strip()
            if clean:
                self.text_parts.append(clean + ' ')

    def get_clean_content(self) -> Tuple[str, str]:
        raw_text = "".join(self.text_parts)
        # Collapse multi-newlines and spaces
        lines = [re.sub(r'[ \t]+', ' ', line).strip() for line in raw_text.split('\n')]
        clean_lines = [line for line in lines if len(line) > 10] # Filter out short menu items
        clean_text = "\n\n".join(clean_lines)
        return self.page_title.strip() or "Official Web Page", clean_text

class WebIngester:
    @staticmethod
    def scrape_url(url: str, timeout: int = 15) -> Dict[str, Any]:
        """
        Fetches an official website URL, parses the HTML, and extracts clean, chunkable text.
        """
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "https://" + url

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 (SmartAssist-AI-Bot)"
        }
        
        req = urllib.request.Request(url, headers=headers)
        
        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                content_type = response.headers.get_content_type()
                if "text/html" not in content_type and "text/plain" not in content_type:
                    return {
                        "success": False,
                        "error": f"Unsupported content type: {content_type}. Please provide an HTML webpage."
                    }
                charset = response.headers.get_content_charset() or 'utf-8'
                html_bytes = response.read()
                html_text = html_bytes.decode(charset, errors='replace')
                
                extractor = HTMLContentExtractor()
                extractor.feed(html_text)
                title, content = extractor.get_clean_content()
                
                if len(content) < 50:
                    return {
                        "success": False,
                        "error": "Webpage content was too short or rendered client-side with JavaScript. Try uploading the PDF or handbook directly."
                    }
                    
                return {
                    "success": True,
                    "url": url,
                    "title": title,
                    "content": content,
                    "char_count": len(content)
                }
        except urllib.error.HTTPError as e:
            return {"success": False, "error": f"HTTP Error {e.code}: {e.reason}"}
        except urllib.error.URLError as e:
            return {"success": False, "error": f"Connection Error: {e.reason}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
