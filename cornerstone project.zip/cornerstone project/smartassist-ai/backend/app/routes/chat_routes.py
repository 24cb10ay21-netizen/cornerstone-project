import json
from flask import Blueprint, request, jsonify, g
from app.chatbot.engine import ChatbotEngine
from app.authentication.dependencies import optional_auth, require_auth
from app.utils.db import get_db_connection

chat_bp = Blueprint("chat", __name__, url_prefix="/api/chat")

@chat_bp.route("/message", methods=["POST"])
@optional_auth
def send_message():
    data = request.get_json() or {}
    query = data.get("query", "").strip()
    domain = data.get("domain", "student").strip().lower()
    conversation_id = data.get("conversation_id")
    
    if not query:
        return jsonify({"status": "error", "message": "Query message cannot be empty."}), 400
        
    user_id = g.current_user["id"] if hasattr(g, "current_user") and g.current_user else None
    
    # Process through Chatbot Engine
    response_data = ChatbotEngine.process_message(
        query=query,
        domain=domain,
        user_id=user_id,
        conversation_id=conversation_id
    )
    
    return jsonify({
        "status": "success",
        "data": response_data
    })

@chat_bp.route("/conversations", methods=["GET"])
@optional_auth
def get_conversations():
    user_id = g.current_user["id"] if hasattr(g, "current_user") and g.current_user else None
    domain = request.args.get("domain")
    
    conn = get_db_connection()
    if user_id:
        if domain:
            convs = conn.execute(
                "SELECT * FROM conversations WHERE user_id = ? AND domain = ? ORDER BY updated_at DESC",
                (user_id, domain)
            ).fetchall()
        else:
            convs = conn.execute(
                "SELECT * FROM conversations WHERE user_id = ? ORDER BY updated_at DESC",
                (user_id,)
            ).fetchall()
    else:
        # Return empty list for guest
        convs = []
        
    conn.close()
    return jsonify({
        "status": "success",
        "conversations": [dict(c) for c in convs]
    })

@chat_bp.route("/conversations/<int:conversation_id>", methods=["GET"])
def get_conversation_detail(conversation_id):
    conn = get_db_connection()
    conv = conn.execute("SELECT * FROM conversations WHERE id = ?", (conversation_id,)).fetchone()
    if not conv:
        conn.close()
        return jsonify({"status": "error", "message": "Conversation not found."}), 404
        
    messages = conn.execute(
        "SELECT * FROM chat_messages WHERE conversation_id = ? ORDER BY id ASC",
        (conversation_id,)
    ).fetchall()
    
    msg_list = []
    for m in messages:
        item = dict(m)
        if item.get("sources_json"):
            try:
                item["sources"] = json.loads(item["sources_json"])
            except Exception:
                item["sources"] = []
        else:
            item["sources"] = []
        msg_list.append(item)
        
    conn.close()
    return jsonify({
        "status": "success",
        "conversation": dict(conv),
        "messages": msg_list
    })

@chat_bp.route("/conversations/<int:conversation_id>", methods=["DELETE"])
def delete_conversation(conversation_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
    conn.commit()
    conn.close()
    return jsonify({"status": "success", "message": "Conversation deleted."})

@chat_bp.route("/feedback", methods=["POST"])
def submit_chat_feedback():
    data = request.get_json() or {}
    message_id = data.get("message_id")
    rating = data.get("rating", 0) # 1: Helpful, -1: Unhelpful
    
    if not message_id:
        return jsonify({"status": "error", "message": "Message ID is required."}), 400
        
    conn = get_db_connection()
    conn.execute("UPDATE chat_messages SET helpful_rating = ? WHERE id = ?", (rating, message_id))
    # Also log to analytics
    conn.execute("""
        UPDATE chatbot_analytics 
        SET feedback = ? 
        WHERE id = (SELECT id FROM chatbot_analytics ORDER BY id DESC LIMIT 1)
    """, (rating,))
    conn.commit()
    conn.close()
    
    return jsonify({"status": "success", "message": "Feedback submitted. Thank you!"})

@chat_bp.route("/escalate-ticket", methods=["POST"])
@require_auth
def escalate_to_ticket():
    data = request.get_json() or {}
    user = g.current_user
    
    subject = data.get("subject", "Escalated from Chatbot Query")
    description = data.get("description", "")
    domain = data.get("domain", "student")
    category = data.get("category", "General Inquiry")
    priority = data.get("priority", "medium")
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Generate unique ticket number
    count = cur.execute("SELECT COUNT(*) FROM support_tickets").fetchone()[0] + 1
    prefix = "STU" if domain == "student" else "CUST"
    ticket_num = f"TCK-{prefix}-{1000 + count}"
    
    cur.execute("""
        INSERT INTO support_tickets (ticket_number, user_id, domain, category, subject, description, priority, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'open')
    """, (ticket_num, user["id"], domain, category, subject, description, priority))
    
    ticket_id = cur.lastrowid
    
    # Add initial system message in ticket responses
    cur.execute("""
        INSERT INTO ticket_responses (ticket_id, sender_id, sender_name, sender_role, message)
        VALUES (?, ?, ?, ?, ?)
    """, (ticket_id, user["id"], user["full_name"], user["role"], description))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        "status": "success",
        "message": f"Support ticket {ticket_num} created successfully.",
        "ticket_number": ticket_num,
        "ticket_id": ticket_id
    }), 201
