from flask import Blueprint, request, jsonify, g
from app.utils.db import get_db_connection
from app.authentication.dependencies import require_role, optional_auth

student_bp = Blueprint("student", __name__, url_prefix="/api/student")

@student_bp.route("/dashboard-summary", methods=["GET"])
@require_role("student", "admin")
def get_student_dashboard():
    user = g.current_user
    conn = get_db_connection()
    
    # Fetch profile
    profile = conn.execute("SELECT * FROM student_profiles WHERE user_id = ?", (user["id"],)).fetchone()
    
    # Fetch user tickets count
    open_tickets = conn.execute(
        "SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status IN ('open', 'in_progress')",
        (user["id"],)
    ).fetchone()[0]
    
    resolved_tickets = conn.execute(
        "SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status = 'resolved'",
        (user["id"],)
    ).fetchone()[0]
    
    recent_tickets = conn.execute(
        "SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC LIMIT 3",
        (user["id"],)
    ).fetchall()
    
    recent_convs = conn.execute(
        "SELECT * FROM conversations WHERE user_id = ? AND domain = 'student' ORDER BY updated_at DESC LIMIT 3",
        (user["id"],)
    ).fetchall()
    
    conn.close()
    
    return jsonify({
        "status": "success",
        "data": {
            "user": user,
            "profile": dict(profile) if profile else None,
            "stats": {
                "open_tickets": open_tickets,
                "resolved_tickets": resolved_tickets,
                "attendance_pct": profile["attendance_pct"] if profile else 85.0,
                "cgpa": profile["cgpa"] if profile else 8.5
            },
            "recent_tickets": [dict(t) for t in recent_tickets],
            "recent_conversations": [dict(c) for c in recent_convs]
        }
    })

@student_bp.route("/faqs", methods=["GET"])
@optional_auth
def get_student_faqs():
    category = request.args.get("category")
    search = request.args.get("search", "").strip().lower()
    
    conn = get_db_connection()
    query = "SELECT * FROM faqs WHERE domain = 'student' AND is_active = 1"
    params = []
    
    if category and category.lower() != "all":
        query += " AND category = ?"
        params.append(category)
        
    if search:
        query += " AND (question LIKE ? OR answer LIKE ? OR keywords LIKE ?)"
        wildcard = f"%{search}%"
        params.extend([wildcard, wildcard, wildcard])
        
    query += " ORDER BY category ASC, id ASC"
    rows = conn.execute(query, params).fetchall()
    
    # Get distinct categories
    cats = conn.execute(
        "SELECT DISTINCT category FROM faqs WHERE domain = 'student' AND is_active = 1"
    ).fetchall()
    
    conn.close()
    
    return jsonify({
        "status": "success",
        "categories": [c["category"] for c in cats],
        "faqs": [dict(r) for r in rows]
    })
