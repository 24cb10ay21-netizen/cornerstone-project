from flask import Blueprint, request, jsonify, g
from app.utils.db import get_db_connection
from app.authentication.password import hash_password, verify_password
from app.authentication.jwt_handler import JWTHandler
from app.authentication.dependencies import require_auth

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    full_name = data.get("full_name", "").strip()
    role = data.get("role", "student").strip().lower()
    
    if not email or not password or not full_name:
        return jsonify({"status": "error", "message": "Email, password, and full name are required."}), 400
        
    if role not in ["student", "customer", "admin"]:
        role = "student"
        
    if len(password) < 6:
        return jsonify({"status": "error", "message": "Password must be at least 6 characters long."}), 400
        
    conn = get_db_connection()
    cur = conn.cursor()
    
    # Check if user already exists
    existing = cur.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
    if existing:
        conn.close()
        return jsonify({"status": "error", "message": "An account with this email already exists."}), 400
        
    pw_hash = hash_password(password)
    cur.execute(
        "INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
        (email, pw_hash, full_name, role)
    )
    user_id = cur.lastrowid
    
    # Create associated profile
    if role == "student":
        cur.execute("""
            INSERT INTO student_profiles (user_id, student_id, department, program, year_of_study, semester, roll_number, cgpa, attendance_pct)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            data.get("student_id", f"STU{user_id:04d}"),
            data.get("department", "Computer Science"),
            data.get("program", "B.Tech Computer Science"),
            int(data.get("year_of_study", 3)),
            int(data.get("semester", 6)),
            data.get("roll_number", f"22CS{user_id:03d}"),
            float(data.get("cgpa", 8.2)),
            float(data.get("attendance_pct", 82.0))
        ))
    elif role == "customer":
        cur.execute("""
            INSERT INTO customer_profiles (user_id, customer_code, company_name, phone_number, customer_tier, address)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            user_id,
            data.get("customer_code", f"CUST-{user_id:04d}"),
            data.get("company_name", "Individual Client"),
            data.get("phone_number", data.get("phone", "+1 (555) 000-0000")),
            data.get("customer_tier", "Standard"),
            data.get("address", "")
        ))
        
    conn.commit()
    conn.close()
    
    # Generate JWT token
    token = JWTHandler.create_access_token({
        "user_id": user_id,
        "email": email,
        "role": role,
        "full_name": full_name
    })
    
    return jsonify({
        "status": "success",
        "message": "Registration successful.",
        "token": token,
        "user": {
            "id": user_id,
            "email": email,
            "full_name": full_name,
            "role": role
        }
    }), 201

@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    
    if not email or not password:
        return jsonify({"status": "error", "message": "Email and password are required."}), 400
        
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    
    if not user or not verify_password(password, user["password_hash"]):
        conn.close()
        return jsonify({"status": "error", "message": "Invalid email or password."}), 401
        
    if not user["is_active"]:
        conn.close()
        return jsonify({"status": "error", "message": "This account has been deactivated. Please contact an administrator."}), 403
        
    user_dict = {
        "id": user["id"],
        "email": user["email"],
        "full_name": user["full_name"],
        "role": user["role"]
    }
    
    # Fetch additional profile information
    if user["role"] == "student":
        prof = conn.execute("SELECT * FROM student_profiles WHERE user_id = ?", (user["id"],)).fetchone()
        if prof:
            user_dict["profile"] = dict(prof)
    elif user["role"] == "customer":
        prof = conn.execute("SELECT * FROM customer_profiles WHERE user_id = ?", (user["id"],)).fetchone()
        if prof:
            user_dict["profile"] = dict(prof)
            
    conn.close()
    
    token = JWTHandler.create_access_token({
        "user_id": user["id"],
        "email": user["email"],
        "role": user["role"],
        "full_name": user["full_name"]
    })
    
    return jsonify({
        "status": "success",
        "message": "Login successful.",
        "token": token,
        "user": user_dict
    })

@auth_bp.route("/me", methods=["GET"])
@require_auth
def get_current_user():
    user = g.current_user
    conn = get_db_connection()
    
    user_data = {
        "id": user["id"],
        "email": user["email"],
        "full_name": user["full_name"],
        "role": user["role"],
        "is_active": user["is_active"]
    }
    
    if user["role"] == "student":
        prof = conn.execute("SELECT * FROM student_profiles WHERE user_id = ?", (user["id"],)).fetchone()
        if prof:
            user_data["profile"] = dict(prof)
    elif user["role"] == "customer":
        prof = conn.execute("SELECT * FROM customer_profiles WHERE user_id = ?", (user["id"],)).fetchone()
        if prof:
            user_data["profile"] = dict(prof)
            
    conn.close()
    return jsonify({"status": "success", "user": user_data})

@auth_bp.route("/logout", methods=["POST"])
def logout():
    return jsonify({"status": "success", "message": "Logged out successfully."})
