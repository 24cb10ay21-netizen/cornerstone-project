from flask import Blueprint, request, jsonify, g
from app.utils.db import get_db_connection
from app.authentication.dependencies import require_role, optional_auth

customer_bp = Blueprint("customer", __name__, url_prefix="/api/customer")

@customer_bp.route("/dashboard-summary", methods=["GET"])
@require_role("customer", "admin")
def get_customer_dashboard():
    user = g.current_user
    conn = get_db_connection()
    
    profile = conn.execute("SELECT * FROM customer_profiles WHERE user_id = ?", (user["id"],)).fetchone()
    
    open_tickets = conn.execute(
        "SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status IN ('open', 'in_progress')",
        (user["id"],)
    ).fetchone()[0]
    
    resolved_tickets = conn.execute(
        "SELECT COUNT(*) FROM support_tickets WHERE user_id = ? AND status = 'resolved'",
        (user["id"],)
    ).fetchone()[0]
    
    recent_tickets = conn.execute(
        "SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC LIMIT 3",
        (user["id"],)
    ).fetchall()
    
    recent_convs = conn.execute(
        "SELECT * FROM conversations WHERE user_id = ? AND domain = 'customer' ORDER BY updated_at DESC LIMIT 3",
        (user["id"],)
    ).fetchall()
    
    conn.close()
    
    return jsonify({
        "status": "success",
        "data": {
            "user": user,
            "profile": dict(profile) if profile else None,
            "stats": {
                "open_tickets": open_tickets,
                "resolved_tickets": resolved_tickets,
                "tier": profile["customer_tier"] if profile else "Enterprise",
                "active_orders": 2
            },
            "recent_tickets": [dict(t) for t in recent_tickets],
            "recent_conversations": [dict(c) for c in recent_convs]
        }
    })

@customer_bp.route("/faqs", methods=["GET"])
@optional_auth
def get_customer_faqs():
    category = request.args.get("category")
    search = request.args.get("search", "").strip().lower()
    
    conn = get_db_connection()
    query = "SELECT * FROM faqs WHERE domain = 'customer' AND is_active = 1"
    params = []
    
    if category and category.lower() != "all":
        query += " AND category = ?"
        params.append(category)
        
    if search:
        query += " AND (question LIKE ? OR answer LIKE ? OR keywords LIKE ?)"
        wildcard = f"%{search}%"
        params.extend([wildcard, wildcard, wildcard])
        
    query += " ORDER BY category ASC, id ASC"
    rows = conn.execute(query, params).fetchall()
    
    cats = conn.execute(
        "SELECT DISTINCT category FROM faqs WHERE domain = 'customer' AND is_active = 1"
    ).fetchall()
    
    conn.close()
    
    return jsonify({
        "status": "success",
        "categories": [c["category"] for c in cats],
        "faqs": [dict(r) for r in rows]
    })

@customer_bp.route("/order-status", methods=["POST"])
def check_order_status():
    data = request.get_json() or {}
    order_id = data.get("order_id", "").strip().upper()
    
    if not order_id:
        return jsonify({"status": "error", "message": "Order ID is required (e.g. ORD-9821)."}), 400
        
    # Realistic mock order database
    mock_orders = {
        "ORD-9821": {
            "order_id": "ORD-9821",
            "item": "SmartAssist AI Edge Terminal X2 + Wall Mount Kit",
            "status": "In Transit",
            "carrier": "FedEx Express",
            "tracking_number": "784920194820",
            "estimated_delivery": "Within 2 business days",
            "destination": "San Francisco, CA",
            "steps": [
                {"stage": "Order Confirmed", "completed": True, "date": "Oct 30, 2026 10:14 AM"},
                {"stage": "Package Dispatched", "completed": True, "date": "Nov 01, 2026 04:30 PM"},
                {"stage": "In Transit via Carrier Hub", "completed": True, "date": "Nov 02, 2026 09:12 AM"},
                {"stage": "Out for Delivery", "completed": False, "date": "Pending"}
            ]
        },
        "ORD-5412": {
            "order_id": "ORD-5412",
            "item": "Enterprise AI SaaS Annual License - 50 Seats",
            "status": "Delivered / Provisioned",
            "carrier": "Digital Cloud Delivery",
            "tracking_number": "LIC-ENT-2026-9912",
            "estimated_delivery": "Instant Activation",
            "destination": "api.acmecorp.com",
            "steps": [
                {"stage": "Payment Approved", "completed": True, "date": "Oct 15, 2026"},
                {"stage": "Tenant Provisioned", "completed": True, "date": "Oct 15, 2026"},
                {"stage": "License Keys Generated", "completed": True, "date": "Oct 15, 2026"}
            ]
        }
    }
    
    if order_id in mock_orders:
        return jsonify({"status": "success", "order": mock_orders[order_id]})
    else:
        # Generate dynamic realistic record for any ORD-XXXX entered
        return jsonify({
            "status": "success",
            "order": {
                "order_id": order_id,
                "item": "SmartAssist Commercial Module & Accessories",
                "status": "Processing in Fulfillment Center",
                "carrier": "DHL Express Worldwide",
                "tracking_number": f"DHL-{hash(order_id) % 1000000000:09d}",
                "estimated_delivery": "Expected in 3-4 business days",
                "destination": "Registered Customer Address",
                "steps": [
                    {"stage": "Order Verified & Paid", "completed": True, "date": "Recent"},
                    {"stage": "Packed at Logistics Hub", "completed": True, "date": "Recent"},
                    {"stage": "Handover to Courier", "completed": False, "date": "In Queue"},
                    {"stage": "Delivered", "completed": False, "date": "Pending"}
                ]
            }
        })

@customer_bp.route("/feedback", methods=["POST"])
@optional_auth
def submit_customer_feedback():
    data = request.get_json() or {}
    rating = int(data.get("rating", 5))
    category = data.get("category", "General")
    feedback_text = data.get("feedback_text", "").strip()
    user_id = g.current_user["id"] if hasattr(g, "current_user") and g.current_user else None
    
    conn = get_db_connection()
    conn.execute("""
        INSERT INTO user_feedback (user_id, domain, rating, category, feedback_text)
        VALUES (?, 'customer', ?, ?, ?)
    """, (user_id, rating, category, feedback_text))
    conn.commit()
    conn.close()
    
    return jsonify({"status": "success", "message": "Thank you for your valuable feedback!"})
