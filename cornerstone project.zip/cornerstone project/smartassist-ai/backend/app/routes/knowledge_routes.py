import os
from pathlib import Path
from flask import Blueprint, request, jsonify, g
from werkzeug.utils import secure_filename
from config.settings import settings
from app.utils.db import get_db_connection
from app.authentication.dependencies import require_role, optional_auth
from app.rag.document_processor import DocumentProcessor
from app.utils.seed_data import rebuild_vector_store

knowledge_bp = Blueprint("knowledge", __name__, url_prefix="/api/knowledge")

@knowledge_bp.route("/faqs", methods=["GET"])
@optional_auth
def list_faqs():
    domain = request.args.get("domain")
    category = request.args.get("category")
    
    conn = get_db_connection()
    query = "SELECT * FROM faqs WHERE 1=1"
    params = []
    
    if domain:
        query += " AND domain = ?"
        params.append(domain)
        
    if category and category != "all":
        query += " AND category = ?"
        params.append(category)
        
    query += " ORDER BY id DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    
    return jsonify({
        "status": "success",
        "faqs": [dict(r) for r in rows]
    })

@knowledge_bp.route("/faqs", methods=["POST"])
@require_role("admin")
def create_faq():
    data = request.get_json() or {}
    domain = data.get("domain", "student")
    category = data.get("category", "General").strip()
    question = data.get("question", "").strip()
    answer = data.get("answer", "").strip()
    keywords = data.get("keywords", "").strip()
    
    if not question or not answer:
        return jsonify({"status": "error", "message": "Question and answer are required."}), 400
        
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO faqs (domain, category, question, answer, keywords, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
    """, (domain, category, question, answer, keywords))
    faq_id = cur.lastrowid
    conn.commit()
    conn.close()
    
    # Automatically update vector index
    rebuild_vector_store()
    
    return jsonify({
        "status": "success",
        "message": "FAQ created and vector index updated.",
        "faq_id": faq_id
    }), 201

@knowledge_bp.route("/faqs/<int:faq_id>", methods=["PUT"])
@require_role("admin")
def update_faq(faq_id):
    data = request.get_json() or {}
    domain = data.get("domain")
    category = data.get("category")
    question = data.get("question")
    answer = data.get("answer")
    keywords = data.get("keywords")
    is_active = data.get("is_active")
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute("""
        UPDATE faqs 
        SET domain = COALESCE(?, domain),
            category = COALESCE(?, category),
            question = COALESCE(?, question),
            answer = COALESCE(?, answer),
            keywords = COALESCE(?, keywords),
            is_active = COALESCE(?, is_active)
        WHERE id = ?
    """, (domain, category, question, answer, keywords, is_active, faq_id))
    
    conn.commit()
    conn.close()
    
    rebuild_vector_store()
    return jsonify({"status": "success", "message": "FAQ updated successfully."})

@knowledge_bp.route("/faqs/<int:faq_id>", methods=["DELETE"])
@require_role("admin")
def delete_faq(faq_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM faqs WHERE id = ?", (faq_id,))
    conn.commit()
    conn.close()
    
    rebuild_vector_store()
    return jsonify({"status": "success", "message": "FAQ deleted successfully."})

@knowledge_bp.route("/documents", methods=["GET"])
@require_role("admin")
def list_documents():
    conn = get_db_connection()
    docs = conn.execute("""
        SELECT d.*, COUNT(c.id) as chunk_total 
        FROM knowledge_documents d 
        LEFT JOIN document_chunks c ON d.id = c.document_id 
        GROUP BY d.id 
        ORDER BY d.created_at DESC
    """).fetchall()
    conn.close()
    
    return jsonify({
        "status": "success",
        "documents": [dict(d) for d in docs]
    })

@knowledge_bp.route("/upload", methods=["POST"])
@require_role("admin")
def upload_document():
    if "file" not in request.files:
        return jsonify({"status": "error", "message": "No file part in request."}), 400
        
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"status": "error", "message": "No selected file."}), 400
        
    title = request.form.get("title", file.filename).strip()
    domain = request.form.get("domain", "student").strip()
    category = request.form.get("category", "General").strip()
    
    filename = secure_filename(file.filename)
    suffix = Path(filename).suffix.lower().lstrip(".")
    
    if suffix not in settings.ALLOWED_EXTENSIONS:
        return jsonify({
            "status": "error", 
            "message": f"File extension '{suffix}' not supported. Allowed: {', '.join(settings.ALLOWED_EXTENSIONS)}"
        }), 400
        
    save_path = settings.UPLOAD_FOLDER / filename
    file.save(str(save_path))
    
    # Extract text content
    extracted_text = DocumentProcessor.extract_text_from_file(save_path)
    if not extracted_text or len(extracted_text.strip()) < 10:
        return jsonify({"status": "error", "message": "Could not extract readable text from document."}), 400
        
    # Save document in database
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO knowledge_documents (title, domain, category, file_path, file_type, content, is_active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
    """, (title, domain, category, str(save_path), suffix, extracted_text))
    doc_id = cur.lastrowid
    
    # Chunk document
    chunks = DocumentProcessor.chunk_text(extracted_text, chunk_size=settings.CHUNK_SIZE, overlap=settings.CHUNK_OVERLAP)
    for idx, chunk in enumerate(chunks):
        cur.execute("""
            INSERT INTO document_chunks (document_id, chunk_index, content, category, domain)
            VALUES (?, ?, ?, ?, ?)
        """, (doc_id, idx, chunk, category, domain))
        
    cur.execute("UPDATE knowledge_documents SET chunk_count = ? WHERE id = ?", (len(chunks), doc_id))
    conn.commit()
    conn.close()
    
    # Rebuild vector index
    rebuild_vector_store()
    
    return jsonify({
        "status": "success",
        "message": f"Document '{title}' uploaded and indexed ({len(chunks)} chunks).",
        "document_id": doc_id,
        "chunk_count": len(chunks)
    }), 201

@knowledge_bp.route("/documents/<int:doc_id>", methods=["DELETE"])
@require_role("admin")
def delete_document(doc_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM knowledge_documents WHERE id = ?", (doc_id,))
    conn.commit()
    conn.close()
    
    rebuild_vector_store()
    return jsonify({"status": "success", "message": "Document deleted and index updated."})

@knowledge_bp.route("/reindex", methods=["POST"])
@require_role("admin")
def reindex_knowledge():
    rebuild_vector_store()
    return jsonify({
        "status": "success",
        "message": "Knowledge base vector index rebuilt successfully."
    })

@knowledge_bp.route("/crawl-url", methods=["POST"])
@require_role("admin")
def crawl_url():
    from app.rag.web_ingester import WebIngester
    data = request.get_json() or {}
    url = data.get("url", "").strip()
    domain = data.get("domain", "student").strip()
    category = data.get("category", "Official Website").strip()
    
    if not url:
        return jsonify({"status": "error", "message": "URL is required."}), 400
        
    scrape_res = WebIngester.scrape_url(url)
    if not scrape_res.get("success"):
        return jsonify({
            "status": "error", 
            "message": scrape_res.get("error", "Failed to retrieve webpage content.")
        }), 400
        
    title = data.get("title") or scrape_res["title"] or url
    content = scrape_res["content"]
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO knowledge_documents (title, domain, category, file_path, file_type, content, is_active)
        VALUES (?, ?, ?, ?, 'web_url', ?, 1)
    """, (title, domain, category, url, content))
    doc_id = cur.lastrowid
    
    chunks = DocumentProcessor.chunk_text(content, chunk_size=settings.CHUNK_SIZE, overlap=settings.CHUNK_OVERLAP)
    for idx, chunk in enumerate(chunks):
        cur.execute("""
            INSERT INTO document_chunks (document_id, chunk_index, content, category, domain)
            VALUES (?, ?, ?, ?, ?)
        """, (doc_id, idx, chunk, category, domain))
        
    cur.execute("UPDATE knowledge_documents SET chunk_count = ? WHERE id = ?", (len(chunks), doc_id))
    conn.commit()
    conn.close()
    
    # Rebuild vector store with the newly scraped website content
    rebuild_vector_store()
    
    return jsonify({
        "status": "success",
        "message": f"Successfully ingested '{title}' from {url}. Created and indexed {len(chunks)} knowledge chunks.",
        "document_id": doc_id,
        "chunk_count": len(chunks),
        "title": title
    }), 201

