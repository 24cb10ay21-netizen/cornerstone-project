from flask import Blueprint, request, jsonify, g
from app.utils.db import get_db_connection
from app.authentication.dependencies import require_auth

ticket_bp = Blueprint("tickets", __name__, url_prefix="/api/tickets")

@ticket_bp.route("", methods=["GET"])
@require_auth
def list_tickets():
    user = g.current_user
    status = request.args.get("status")
    priority = request.args.get("priority")
    domain = request.args.get("domain")
    
    conn = get_db_connection()
    query = """
        SELECT t.*, u.full_name as user_name, u.email as user_email 
        FROM support_tickets t 
        JOIN users u ON t.user_id = u.id 
        WHERE 1=1
    """
    params = []
    
    # If not admin, restrict to user's tickets
    if user["role"] != "admin":
        query += " AND t.user_id = ?"
        params.append(user["id"])
        
    if domain:
        query += " AND t.domain = ?"
        params.append(domain)
        
    if status and status != "all":
        query += " AND t.status = ?"
        params.append(status)
        
    if priority and priority != "all":
        query += " AND t.priority = ?"
        params.append(priority)
        
    query += " ORDER BY t.created_at DESC"
    tickets = conn.execute(query, params).fetchall()
    conn.close()
    
    return jsonify({
        "status": "success",
        "tickets": [dict(t) for t in tickets]
    })

@ticket_bp.route("", methods=["POST"])
@require_auth
def create_ticket():
    user = g.current_user
    data = request.get_json() or {}
    
    subject = data.get("subject", "").strip()
    description = data.get("description", "").strip()
    category = data.get("category", "General")
    domain = data.get("domain", user.get("role", "student"))
    if domain not in ["student", "customer"]:
        domain = "student"
    priority = data.get("priority", "medium").lower()
    if priority not in ["low", "medium", "high", "urgent"]:
        priority = "medium"
        
    if not subject or not description:
        return jsonify({"status": "error", "message": "Subject and description are required."}), 400
        
    conn = get_db_connection()
    cur = conn.cursor()
    
    count = cur.execute("SELECT COUNT(*) FROM support_tickets").fetchone()[0] + 1
    prefix = "STU" if domain == "student" else "CUST"
    ticket_num = f"TCK-{prefix}-{1000 + count}"
    
    cur.execute("""
        INSERT INTO support_tickets 
        (ticket_number, user_id, domain, category, subject, description, priority, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'open')
    """, (ticket_num, user["id"], domain, category, subject, description, priority))
    
    ticket_id = cur.lastrowid
    
    # Insert initial creator message in response thread
    cur.execute("""
        INSERT INTO ticket_responses (ticket_id, sender_id, sender_name, sender_role, message)
        VALUES (?, ?, ?, ?, ?)
    """, (ticket_id, user["id"], user["full_name"], user["role"], description))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        "status": "success",
        "message": f"Support ticket {ticket_num} created successfully.",
        "ticket": {
            "id": ticket_id,
            "ticket_number": ticket_num,
            "subject": subject,
            "status": "open",
            "priority": priority
        }
    }), 201

@ticket_bp.route("/<int:ticket_id>", methods=["GET"])
@require_auth
def get_ticket_details(ticket_id):
    user = g.current_user
    conn = get_db_connection()
    
    ticket = conn.execute("""
        SELECT t.*, u.full_name as user_name, u.email as user_email, u.role as user_role
        FROM support_tickets t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.id = ?
    """, (ticket_id,)).fetchone()
    
    if not ticket:
        conn.close()
        return jsonify({"status": "error", "message": "Ticket not found."}), 404
        
    if user["role"] != "admin" and ticket["user_id"] != user["id"]:
        conn.close()
        return jsonify({"status": "error", "message": "Forbidden. You cannot view this ticket."}), 403
        
    responses = conn.execute("""
        SELECT * FROM ticket_responses 
        WHERE ticket_id = ? 
        ORDER BY created_at ASC
    """, (ticket_id,)).fetchall()
    
    conn.close()
    
    return jsonify({
        "status": "success",
        "ticket": dict(ticket),
        "responses": [dict(r) for r in responses]
    })

@ticket_bp.route("/<int:ticket_id>/respond", methods=["POST"])
@require_auth
def add_ticket_response(ticket_id):
    user = g.current_user
    data = request.get_json() or {}
    message = data.get("message", "").strip()
    
    if not message:
        return jsonify({"status": "error", "message": "Response message cannot be empty."}), 400
        
    conn = get_db_connection()
    ticket = conn.execute("SELECT * FROM support_tickets WHERE id = ?", (ticket_id,)).fetchone()
    if not ticket:
        conn.close()
        return jsonify({"status": "error", "message": "Ticket not found."}), 404
        
    if user["role"] != "admin" and ticket["user_id"] != user["id"]:
        conn.close()
        return jsonify({"status": "error", "message": "Forbidden."}), 403
        
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO ticket_responses (ticket_id, sender_id, sender_name, sender_role, message)
        VALUES (?, ?, ?, ?, ?)
    """, (ticket_id, user["id"], user["full_name"], user["role"], message))
    
    # If admin replied, automatically update status to in_progress or set admin_response
    if user["role"] == "admin":
        cur.execute("""
            UPDATE support_tickets 
            SET admin_response = ?, status = CASE WHEN status = 'open' THEN 'in_progress' ELSE status END, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (message, ticket_id))
        
    conn.commit()
    conn.close()
    
    return jsonify({
        "status": "success",
        "message": "Response added successfully."
    })

@ticket_bp.route("/<int:ticket_id>/status", methods=["PATCH"])
@require_auth
def update_ticket_status(ticket_id):
    user = g.current_user
    if user["role"] != "admin":
        return jsonify({"status": "error", "message": "Only administrators can update ticket status."}), 403
        
    data = request.get_json() or {}
    new_status = data.get("status")
    priority = data.get("priority")
    admin_response = data.get("admin_response")
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    updates = []
    params = []
    
    if new_status and new_status in ["open", "in_progress", "resolved", "closed"]:
        updates.append("status = ?")
        params.append(new_status)
        if new_status == "resolved":
            updates.append("resolved_at = CURRENT_TIMESTAMP")
            
    if priority and priority in ["low", "medium", "high", "urgent"]:
        updates.append("priority = ?")
        params.append(priority)
        
    if admin_response:
        updates.append("admin_response = ?")
        params.append(admin_response)
        
    if not updates:
        conn.close()
        return jsonify({"status": "error", "message": "No valid fields to update."}), 400
        
    updates.append("updated_at = CURRENT_TIMESTAMP")
    params.append(ticket_id)
    
    sql = f"UPDATE support_tickets SET {', '.join(updates)} WHERE id = ?"
    cur.execute(sql, params)
    
    # If admin response was provided, also log in response thread
    if admin_response:
        cur.execute("""
            INSERT INTO ticket_responses (ticket_id, sender_id, sender_name, sender_role, message)
            VALUES (?, ?, ?, 'admin', ?)
        """, (ticket_id, user["id"], user["full_name"], f"[Status: {new_status or 'Updated'}] {admin_response}"))
        
    conn.commit()
    conn.close()
    
    return jsonify({
        "status": "success",
        "message": "Ticket updated successfully."
    })
