import json
from app.utils.db import get_db_connection, init_db
from app.authentication.password import hash_password
from app.rag.document_processor import DocumentProcessor
from app.rag.vector_store import vector_store

STUDENT_FAQS = [
    {
        "category": "Admissions",
        "question": "What is the eligibility criteria for B.Tech in Computer Science and Engineering?",
        "answer": "Candidates must have passed 10+2 or equivalent with Physics, Mathematics, and Chemistry/Computer Science with an aggregate minimum of 60% marks (55% for reserved categories). Admission is based on university entrance test scores or valid national engineering entrance rank.",
        "keywords": "admission, eligibility, btech, cse, cut off, criteria, percentage"
    },
    {
        "category": "Admissions",
        "question": "What is the last date to submit the online admission application form?",
        "answer": "The regular admission portal closes on July 15th for the upcoming academic year. Late applications with a nominal late fine of $50/INR 2,000 are accepted until July 25th, subject to seat availability.",
        "keywords": "application deadline, last date, admission portal, late fee, registration"
    },
    {
        "category": "Admissions",
        "question": "Is lateral entry available for diploma holders into the 2nd year?",
        "answer": "Yes, candidates holding a 3-year state board technical diploma in Computer, Electrical, or Mechanical Engineering with at least 60% aggregate are eligible for direct admission to the 3rd semester (2nd year) under the Lateral Entry quota.",
        "keywords": "lateral entry, diploma, 2nd year, direct admission, 3rd semester"
    },
    {
        "category": "Courses & Syllabus",
        "question": "Where can I download the complete syllabus and curriculum for my semester?",
        "answer": "The full academic syllabus for all engineering and management programs is available on the Student ERP Portal under 'Academic Curriculum > Syllabus Repository'. You can filter by department, batch regulation, and semester.",
        "keywords": "syllabus, curriculum, course structure, subjects, electives, erp"
    },
    {
        "category": "Courses & Syllabus",
        "question": "How many open elective courses can I choose in the 6th semester?",
        "answer": "Students in the 6th semester can select up to two open electives from outside their parent department. Elective registrations open two weeks prior to semester commencement on the ERP portal on a first-come, first-served basis.",
        "keywords": "open electives, 6th semester, choice based credit system, department, registration"
    },
    {
        "category": "Examinations",
        "question": "When will the end-semester examination datesheet and hall tickets be released?",
        "answer": "The tentative datesheet is published 4 weeks prior to exams on the official examination board board notice page. Hall tickets (admit cards) are generated on the ERP 7 days before exams, provided the student has cleared dues and met attendance criteria.",
        "keywords": "exam datesheet, timetable, hall ticket, admit card, end semester, schedule"
    },
    {
        "category": "Examinations",
        "question": "What is the procedure and fee for applying for paper revaluation or copy scrutiny?",
        "answer": "Students can apply for answer script photocopy and revaluation within 10 days of result declaration via the ERP Examination module. The fee is $15/INR 750 per subject for revaluation, refundable if marks increase by more than 15%.",
        "keywords": "revaluation, scrutiny, marks review, answer sheet, exam result, recheck"
    },
    {
        "category": "Examinations",
        "question": "What is the minimum passing grade and CGPA requirement?",
        "answer": "A minimum of 40% marks in both internal assessments and end-semester examinations independently (Grade 'P') is required to pass a course. An overall cumulative CGPA of 5.0 or above is mandatory for degree award.",
        "keywords": "passing marks, grading system, cgpa, gpa, passing criteria, minimum grade"
    },
    {
        "category": "Attendance",
        "question": "What is the mandatory minimum attendance percentage required to sit for exams?",
        "answer": "Students must maintain a minimum of 75% aggregate attendance in each registered theory and practical subject. Attendance is tracked bi-weekly and updated live on the Student Portal.",
        "keywords": "attendance criteria, 75 percent, minimum attendance, shortage, exam eligibility"
    },
    {
        "category": "Attendance",
        "question": "Can I obtain attendance condonation for medical hospitalization or sports events?",
        "answer": "Yes, condonation up to 10% (allowing students with 65%-74% attendance) is granted for verified medical hospitalization or university-represented sports/cultural competitions. Valid medical certificates must be submitted to the HOD within 7 days of resuming classes.",
        "keywords": "medical certificate, condonation, attendance shortage, medical leave, sports leave"
    },
    {
        "category": "Fee Structure",
        "question": "What is the tuition fee structure and payment schedule for the academic year?",
        "answer": "The annual tuition fee for B.Tech programs is $3,200 (or INR 1,40,000) payable in two equal installments at the beginning of the Autumn and Spring semesters. Detailed breakdowns including lab fees and development charges are on the finance portal.",
        "keywords": "fee structure, tuition fee, annual fee, installment, semester fee"
    },
    {
        "category": "Fee Structure",
        "question": "What payment methods are supported for tuition and hostel fees?",
        "answer": "Payments can be made online via Credit/Debit card, Net Banking, and UPI through the integrated HDFC/SBI payment gateway on the Student ERP. Demand Drafts (DD) drawn in favor of 'The Registrar' are also accepted at the university cash counter.",
        "keywords": "payment method, online fee, upi, net banking, demand draft, fee receipt"
    },
    {
        "category": "Fee Structure",
        "question": "How do I download my official fee receipt and 80E tax deduction certificate?",
        "answer": "Once transaction is successful, fee receipts are instantly generated in your ERP profile under 'Fee Transactions > Receipts'. You can also generate an automated Form 16 / 80E educational loan tax certificate from the same page.",
        "keywords": "fee receipt, payment receipt, tax certificate, 80e, education loan"
    },
    {
        "category": "Scholarships",
        "question": "What merit scholarships and financial assistance are offered by the institution?",
        "answer": "The university awards: 1) Chancellor's Merit Scholarship (100% tuition waiver for batch top 1%), 2) Dean's Honor Roll (50% waiver for CGPA > 9.2), and 3) Need-Based Financial Aid for students with parental income below $4,000/INR 3.5 Lakhs annually.",
        "keywords": "scholarship, merit scholarship, financial aid, fee waiver, deans list, concession"
    },
    {
        "category": "Scholarships",
        "question": "How and when can I apply for National Scholarship Portal (NSP) schemes?",
        "answer": "NSP applications open every year in August. After submitting online on the government NSP portal, students must submit hard copies of documents along with income proof to the College Scholarship Desk for biometric college verification.",
        "keywords": "nsp, national scholarship, government scholarship, biometric verification, post matric"
    },
    {
        "category": "Placements",
        "question": "What companies visit for campus placements and what was the highest CTC last year?",
        "answer": "Over 240 marquee recruiters visit campus annually including Google, Microsoft, Amazon, TCS, Infosys, and Deloitte. In the 2024-25 placement season, the highest international CTC reached $58,000 (INR 48 LPA) and average CSE CTC was $10,500 (INR 9.2 LPA).",
        "keywords": "placements, campus recruitment, highest package, average ctc, companies, recruiters"
    },
    {
        "category": "Placements",
        "question": "Are internships compulsory during the 6th and 7th semesters?",
        "answer": "Yes, students must undergo an industry internship or research training of at least 6-8 weeks between the 6th and 7th semester breaks. It carries 3 academic credits evaluated through viva and internship report.",
        "keywords": "internship, summer training, industry credits, placement cell, tpo"
    },
    {
        "category": "Academic Calendar",
        "question": "When does the next semester start and what are the scheduled vacation dates?",
        "answer": "The upcoming Spring Semester commences on January 8th. The mid-term break runs from March 14th to March 22nd, and summer vacation spans June 1st to July 20th. The full calendar is on the university notices dashboard.",
        "keywords": "academic calendar, semester start, vacations, holidays, schedule, mid term"
    },
    {
        "category": "Facilities",
        "question": "What are the Central Library operating hours and book borrowing limits?",
        "answer": "The Central Library is open from 8:00 AM to 11:00 PM on weekdays and 9:00 AM to 6:00 PM on weekends. Undergraduate students can borrow up to 5 books simultaneously for 21 days with one online renewal allowed.",
        "keywords": "library hours, book renewal, borrowing limit, central library, reading room"
    },
    {
        "category": "Facilities",
        "question": "How do I register for campus hostel accommodation and mess facilities?",
        "answer": "Hostel room allotments are managed through the Hostel Portal before each academic term. Rooms are allocated based on year of study and distance from home. All hostelites receive four meals daily (breakfast, lunch, snacks, dinner) with veg and non-veg options.",
        "keywords": "hostel allotment, mess, hostel fee, room booking, campus accommodation"
    }
]

CUSTOMER_FAQS = [
    {
        "category": "Product Information",
        "question": "What are the core capabilities and specifications of SmartAssist AI Suite?",
        "answer": "SmartAssist AI Suite provides omnichannel automated customer and student query resolution, natural language understanding, RAG-grounded vector search, real-time ticket escalation, multilingual sentiment tracking, and high-throughput analytics.",
        "keywords": "product specs, capabilities, features, ai suite, system specs"
    },
    {
        "category": "Product Information",
        "question": "Is SmartAssist AI compatible with existing CRM and ERP platforms?",
        "answer": "Yes, SmartAssist AI features plug-and-play REST APIs and Webhook triggers compatible with Salesforce, HubSpot, Zendesk, SAP, Canvas LMS, Moodle, and popular database backends like PostgreSQL and MongoDB.",
        "keywords": "crm integration, erp compatibility, salesforce, hubspot, api integration"
    },
    {
        "category": "Product Information",
        "question": "Can I deploy the application on-premise or in an isolated private cloud?",
        "answer": "Yes, SmartAssist AI provides fully containerized Docker configurations and Helm charts for on-premise deployment or hosting inside AWS GovCloud, Google Cloud Platform, and Microsoft Azure private VPCs.",
        "keywords": "on premise, self hosted, docker, private cloud, aws, gcp, azure"
    },
    {
        "category": "Pricing & Billing",
        "question": "What subscription tiers and enterprise pricing plans are available?",
        "answer": "We offer three plans: Starter ($49/month for up to 5,000 queries), Professional ($199/month for 35,000 queries with custom knowledge upload), and Enterprise (Custom billing for unlimited seats, dedicated SLAs, and custom LLM tuning).",
        "keywords": "pricing plans, subscription tier, cost, starter, professional, enterprise quote"
    },
    {
        "category": "Pricing & Billing",
        "question": "Are there discounts available for educational institutions and non-profit organizations?",
        "answer": "Yes, accredited educational institutions, universities, and registered 501(c)(3) non-profit organizations qualify for a 35% discount on all annual Professional and Enterprise plans upon providing verification.",
        "keywords": "education discount, non profit, university discount, annual billing, waiver"
    },
    {
        "category": "Order Status",
        "question": "How do I track my hardware delivery or license provisioning status?",
        "answer": "Enter your Order ID (e.g. ORD-9821) on our Customer Portal under 'Track Order' to view live shipment milestones, tracking numbers, assigned logistics carriers (FedEx/DHL), and real-time delivery estimates.",
        "keywords": "track order, shipping status, delivery estimate, tracking number, courier"
    },
    {
        "category": "Order Status",
        "question": "What is the typical shipping and fulfillment turnaround time?",
        "answer": "Digital licenses and cloud instances are provisioned within 15 minutes of payment confirmation. Physical edge hardware and sensor modules are dispatched within 2 business days via express courier (3-5 business days delivery).",
        "keywords": "delivery time, fulfillment, dispatch, shipping duration, license provisioning"
    },
    {
        "category": "Refund & Cancellation",
        "question": "What is your refund policy for software subscriptions and hardware purchases?",
        "answer": "We offer an unconditional 30-day money-back guarantee for all SaaS software subscriptions. Physical hardware items can be returned within 14 days of delivery in original packaging with all accessories for a 100% refund.",
        "keywords": "refund policy, money back guarantee, return window, cancellation, reverse charge"
    },
    {
        "category": "Refund & Cancellation",
        "question": "How long does it take for a refund to reflect in my bank account?",
        "answer": "Once a refund is approved by our billing department, it is processed within 48 hours. Depending on your financial institution or card issuer, funds will appear in your statement within 5 to 7 business days.",
        "keywords": "refund timeline, bank credit, processing time, reverse transaction, statement"
    },
    {
        "category": "Complaints",
        "question": "How can I register an official service complaint or dispute?",
        "answer": "You can file a formal complaint directly through the Customer Portal by selecting 'Register Complaint', or escalate an ongoing chat to our Tier-2 Support team. Every complaint is assigned a tracking reference and SLA resolution within 24 hours.",
        "keywords": "complaint, file dispute, report issue, poor service, escalation"
    },
    {
        "category": "Complaints",
        "question": "What should I do if a received hardware device is defective or damaged?",
        "answer": "Immediately take clear photos of the damaged packaging and unit, then open a Support Ticket under 'Hardware RMA'. Our logistics team will issue a prepaid return courier label and ship an expedited replacement within 24 hours.",
        "keywords": "defective device, damaged item, rma, warranty replacement, broken unit"
    },
    {
        "category": "Technical Support",
        "question": "How do I reset my account password or configure Two-Factor Authentication (2FA)?",
        "answer": "Click 'Profile Settings > Security' in your dashboard. You can update your password and enable authenticator app (TOTP) based 2FA by scanning the provided QR code with Google Authenticator or Authy.",
        "keywords": "password reset, 2fa, two factor, security, authenticator, login issue"
    },
    {
        "category": "Technical Support",
        "question": "What are the API rate limits and how do I generate API keys?",
        "answer": "API keys are generated under 'Developer Settings > API Keys'. Standard tiers are limited to 120 requests/minute, while Enterprise tiers can make up to 1,500 requests/minute with dedicated burst capacity.",
        "keywords": "api rate limit, api keys, developer documentation, authentication header, token"
    },
    {
        "category": "Technical Support",
        "question": "Why is my chatbot returning fallback answers on newly uploaded documents?",
        "answer": "After uploading new documents, click the 'Re-Index Knowledge Base' button in the Admin Knowledge Management panel. The vector store chunks and generates term indices asynchronously, typically taking 2-5 seconds.",
        "keywords": "reindex, knowledge base, fallback, vector search, chunking issue, update index"
    },
    {
        "category": "Customer Feedback",
        "question": "How do I submit product feedback or request a new feature?",
        "answer": "Navigate to the 'Feedback' tab in your Customer Dashboard, select the relevant product module, rate your experience (1-5 stars), and submit your feature request. Our product engineering team reviews feedback weekly.",
        "keywords": "product feedback, feature request, suggestions, rating, roadmap"
    },
    {
        "category": "Security & Privacy",
        "question": "How is customer and student data protected under data privacy regulations?",
        "answer": "All data in transit is encrypted using TLS 1.3, and data at rest is protected with AES-256 encryption. We comply strictly with GDPR, FERPA, and SOC 2 Type II guidelines. User conversation data is never used to train public foundational models.",
        "keywords": "data privacy, gdpr, ferpa, encryption, security, confidentiality, soc 2"
    },
    {
        "category": "Warranty",
        "question": "What does the standard hardware warranty cover?",
        "answer": "All SmartAssist smart terminals and edge devices include a 2-year manufacturer warranty covering component defects, motherboard failures, and power supply issues. Accidental liquid or physical damage can be covered through our Care+ plan.",
        "keywords": "warranty, guarantee, repair, care plus, replacement coverage"
    },
    {
        "category": "Account Management",
        "question": "Can I add multiple team members or student admins with role permissions?",
        "answer": "Yes, administrators can invite team members under 'Admin Panel > User Management' and assign granular roles including 'Administrator', 'Support Agent', 'Student', or 'Customer' with customized view and edit privileges.",
        "keywords": "user roles, invite team, permissions, access control, rbac"
    },
    {
        "category": "Pricing & Billing",
        "question": "Can I cancel my subscription anytime without penalties?",
        "answer": "Yes, monthly subscriptions can be cancelled at any time from your billing portal with zero cancellation penalties. You will retain access until the end of your current paid billing period.",
        "keywords": "cancel subscription, cancellation fee, billing period, downgrade"
    },
    {
        "category": "Technical Support",
        "question": "What are your support team's operating hours and response SLAs?",
        "answer": "Our automated AI chatbot is available 24/7/365. Human support agents operate Monday through Friday from 8:00 AM to 8:00 PM EST. Critical priority tickets have a guaranteed initial response time of under 1 hour.",
        "keywords": "support hours, sla, human agent, response time, 24/7 support"
    }
]

SAMPLE_DOCUMENTS = [
    {
        "title": "SmartAssist University Student Academic Handbook 2026",
        "domain": "student",
        "category": "Academic Guidelines",
        "content": """SmartAssist University - Official Student Handbook (Academic Year 2025-2026)

Section 1: Admission and Enrollment Regulations
All admitted students must register for their designated courses within the first 5 working days of each academic term. Lateral entry students admitted into the third semester must complete prerequisite bridging mathematics and computing modules during the 3rd and 4th semesters without extra tuition costs.

Section 2: Examination and Grading System
Examinations comprise Continuous Internal Evaluation (CIE) carrying 40% weightage and Semester End Examination (SEE) carrying 60% weightage. To pass, a student must score at least 40% in SEE and 40% aggregate. The 10-point letter grading scale applies: O (90-100), A+ (80-89), A (70-79), B+ (60-69), B (55-59), C (50-54), P (40-49), and F (Below 40). Revaluation results are announced within 21 days of application.

Section 3: Mandatory Attendance Policy & Condonation
Every student must attend at least 75% of scheduled lectures and laboratory sessions in each course. Students having attendance between 65% and 74.9% due to medical emergencies or college representation can apply for Dean's condonation by paying a prescribed condonation fee of $20 and submitting authentic hospital discharge documents within 7 days. Students with less than 65% attendance are detained from SEE and must re-register the course in the subsequent term.

Section 4: Fee Policies & Financial Assistance
Tuition fees are due on July 31st for Fall term and January 15th for Spring term. A grace period of 7 days is provided, after which a $5 daily late fee applies. Need-based scholarships up to 50% tuition waiver are available for students whose household gross income is under $4,000 annually.

Section 5: Training & Placement Division Guidelines
Students with a minimum CGPA of 6.5 and no standing active backlogs are eligible for campus recruitment drives commencing in the 7th semester. Mock interviews, aptitude masterclasses, and soft skills training are organized by the TPO free of cost.
"""
    },
    {
        "title": "SmartAssist Enterprise Customer Operations & SLA Policy",
        "domain": "customer",
        "category": "Service Policy",
        "content": """SmartAssist AI Technologies - Customer Operations, Warranty & Service Level Agreement (SLA)

1. Service Availability & Uptime Guarantee
SmartAssist AI cloud platforms maintain an enterprise service uptime guarantee of 99.95% excluding pre-notified scheduled maintenance windows. In the event of system downtime exceeding SLA thresholds, customers are eligible for service credits on their monthly invoice.

2. Hardware Return & Refund (RMA) Lifecycle
Customers are entitled to return unopened hardware units within 14 calendar days of delivery. For defective products covered under the 2-Year Limited Manufacturer Warranty, SmartAssist provides an Advance Replacement RMA service: a replacement unit is shipped within 24 hours of RMA verification along with a pre-paid courier return label.

3. Order Fulfillment & Tracking
All standard orders are dispatched from our centralized fulfillment hub within 2 business days. Express shipping delivers within 2-4 business days across North America, Europe, and Asia Pacific. Real-time carrier tracking numbers are immediately emailed upon shipment and visible in the Customer Dashboard.

4. Data Privacy, Encryption & Compliance
All customer conversational transcripts and analytics are processed in isolated multi-tenant environments encrypted at rest with AES-256 and in transit via TLS 1.3. We do not inspect or sell customer communications and comply with GDPR, CCPA, and ISO/IEC 27001 standards.

5. Technical Escalation & Priority Levels
Ticket Priority Levels:
- Urgent (P1): Production outage, immediate response within 1 hour, 24/7.
- High (P2): Core feature failure, response within 4 hours.
- Medium (P3): Minor performance or cosmetic issue, response within 12 hours.
- Low (P4): General questions or documentation requests, response within 24 hours.
"""
    }
]

def seed_database():
    init_db()
    conn = get_db_connection()
    cur = conn.cursor()
    
    # 1. Check if already seeded
    existing_users = cur.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if existing_users > 0:
        conn.close()
        # Still make sure vector index is built
        rebuild_vector_store()
        return
        
    print("[Seed] Seeding Users...")
    # Admin User
    admin_pw = hash_password("admin123")
    cur.execute(
        "INSERT INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'admin', 1)",
        ("admin@smartassist.edu", admin_pw, "Dr. Sarah Mitchell (Administrator)")
    )
    admin_id = cur.lastrowid
    
    # Student User
    student_pw = hash_password("student123")
    cur.execute(
        "INSERT INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'student', 1)",
        ("alex.student@smartassist.edu", student_pw, "Alex Chen")
    )
    student_id = cur.lastrowid
    cur.execute("""
        INSERT INTO student_profiles 
        (user_id, student_id, department, program, year_of_study, semester, roll_number, cgpa, attendance_pct)
        VALUES (?, 'STU2024CS089', 'Computer Science & Engineering', 'B.Tech CSE', 3, 6, '22CS1042', 8.85, 84.5)
    """, (student_id,))
    
    # Customer User
    customer_pw = hash_password("customer123")
    cur.execute(
        "INSERT INTO users (email, password_hash, full_name, role, is_active) VALUES (?, ?, ?, 'customer', 1)",
        ("sarah.buyer@acmecorp.com", customer_pw, "Sarah Jenkins")
    )
    customer_id = cur.lastrowid
    cur.execute("""
        INSERT INTO customer_profiles 
        (user_id, customer_code, company_name, phone_number, customer_tier, address)
        VALUES (?, 'CUST-8841', 'Acme Solutions Inc.', '+1 (555) 234-5678', 'Enterprise', '742 Evergreen Terrace, Suite 400')
    """, (customer_id,))

    print("[Seed] Seeding 20 Student FAQs...")
    for faq in STUDENT_FAQS:
        cur.execute("""
            INSERT INTO faqs (domain, category, question, answer, keywords, view_count, is_active)
            VALUES ('student', ?, ?, ?, ?, 12, 1)
        """, (faq["category"], faq["question"], faq["answer"], faq["keywords"]))

    print("[Seed] Seeding 20 Customer FAQs...")
    for faq in CUSTOMER_FAQS:
        cur.execute("""
            INSERT INTO faqs (domain, category, question, answer, keywords, view_count, is_active)
            VALUES ('customer', ?, ?, ?, ?, 18, 1)
        """, (faq["category"], faq["question"], faq["answer"], faq["keywords"]))

    print("[Seed] Seeding Knowledge Documents & Chunks...")
    for doc in SAMPLE_DOCUMENTS:
        cur.execute("""
            INSERT INTO knowledge_documents (title, domain, category, file_path, file_type, content, is_active)
            VALUES (?, ?, ?, 'knowledge_base/sample.txt', 'txt', ?, 1)
        """, (doc["title"], doc["domain"], doc["category"], doc["content"]))
        doc_id = cur.lastrowid
        
        chunks = DocumentProcessor.chunk_text(doc["content"], chunk_size=350, overlap=40)
        cur.execute("UPDATE knowledge_documents SET chunk_count = ? WHERE id = ?", (len(chunks), doc_id))
        
        for idx, chunk in enumerate(chunks):
            cur.execute("""
                INSERT INTO document_chunks (document_id, chunk_index, content, category, domain)
                VALUES (?, ?, ?, ?, ?)
            """, (doc_id, idx, chunk, doc["category"], doc["domain"]))

    print("[Seed] Seeding Sample Support Tickets...")
    # Student Ticket 1 (Resolved)
    cur.execute("""
        INSERT INTO support_tickets 
        (ticket_number, user_id, domain, category, subject, description, priority, status, admin_response, resolved_at)
        VALUES ('TCK-STU-1001', ?, 'student', 'Examinations', 'Request for Hall Ticket barcode clearance', 
        'My hall ticket generated on the portal is missing the barcode verification mark for the CSE 601 exam.', 
        'high', 'resolved', 'Barcode re-generated on student ERP portal. Please re-download your admit card PDF.', CURRENT_TIMESTAMP)
    """, (student_id,))
    ticket1_id = cur.lastrowid
    cur.execute("""
        INSERT INTO ticket_responses (ticket_id, sender_id, sender_name, sender_role, message)
        VALUES (?, ?, 'Dr. Sarah Mitchell', 'admin', 'Your admit card barcode has been refreshed. The verification desk has been notified.')
    """, (ticket1_id, admin_id))

    # Student Ticket 2 (In Progress)
    cur.execute("""
        INSERT INTO support_tickets 
        (ticket_number, user_id, domain, category, subject, description, priority, status)
        VALUES ('TCK-STU-1002', ?, 'student', 'Attendance', 'Medical leave condonation application', 
        'Attaching hospital discharge summary for 5 days absence from March 2 to March 6 due to acute dengue fever.', 
        'medium', 'in_progress')
    """, (student_id,))

    # Customer Ticket 1 (Open)
    cur.execute("""
        INSERT INTO support_tickets 
        (ticket_number, user_id, domain, category, subject, description, priority, status)
        VALUES ('TCK-CUST-2001', ?, 'customer', 'Technical Support', 'API webhook signature verification error', 
        'When receiving payload at our webhook endpoint https://api.acmecorp.com/webhooks, the HMAC signature header returns 401 unauthorized.', 
        'high', 'open')
    """, (customer_id,))

    # Customer Ticket 2 (Resolved)
    cur.execute("""
        INSERT INTO support_tickets 
        (ticket_number, user_id, domain, category, subject, description, priority, status, admin_response, resolved_at)
        VALUES ('TCK-CUST-2002', ?, 'customer', 'Refund & Cancellation', 'Invoice credit note adjustment request', 
        'Requesting credit note for the 2 unused user licenses on invoice INV-2026-039.', 
        'low', 'resolved', 'Credit note CN-8902 for $98.00 has been applied to your next billing cycle statement.', CURRENT_TIMESTAMP)
    """, (customer_id,))

    print("[Seed] Seeding User Feedback & Chatbot Analytics Records...")
    cur.execute("""
        INSERT INTO user_feedback (user_id, domain, rating, category, feedback_text)
        VALUES (?, 'student', 5, 'AI Accuracy', 'The chatbot accurately quoted the exact attendance percentage and condonation steps!')
    """, (student_id,))
    cur.execute("""
        INSERT INTO user_feedback (user_id, domain, rating, category, feedback_text)
        VALUES (?, 'customer', 5, 'Response Speed', 'Instant resolution for order tracking question without waiting on human telephone hold.')
    """, (customer_id,))

    # Seed analytics queries
    analytics_samples = [
        ("student", "What is the minimum attendance required?", "attendance", 0.94, 210, 1, "rag_exact", 1),
        ("student", "How can I apply for merit scholarship?", "scholarships", 0.91, 180, 1, "rag_synthesis", 1),
        ("student", "What is the fee for B.Tech CS?", "fees", 0.96, 160, 1, "rag_exact", 1),
        ("student", "When are semester exam dates?", "examinations", 0.88, 195, 1, "rag_synthesis", 1),
        ("student", "Can I change my branch in 2nd year?", "general_student", 0.45, 140, 0, "fallback", 0),
        ("customer", "How do I track my active shipment?", "order_status", 0.95, 175, 1, "rag_exact", 1),
        ("customer", "What is your 30 day return policy?", "refund_cancellation", 0.92, 190, 1, "rag_synthesis", 1),
        ("customer", "Do you offer education institution discounts?", "pricing", 0.89, 220, 1, "rag_exact", 1),
        ("customer", "Is SmartAssist compatible with Salesforce CRM?", "product_info", 0.93, 205, 1, "rag_synthesis", 1),
        ("customer", "Do you support quantum computing processors?", "general_customer", 0.35, 130, 0, "fallback", -1)
    ]
    for row in analytics_samples:
        cur.execute("""
            INSERT INTO chatbot_analytics 
            (domain, query_text, intent, confidence, response_time_ms, was_answered, resolution_method, feedback)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, row)

    conn.commit()
    conn.close()
    
    # Build vector store index
    rebuild_vector_store()
    print("[Seed] Seeding completed successfully!")

def rebuild_vector_store():
    """Reads all active documents and FAQs from database and rebuilds the vector index."""
    vector_store.clear()
    conn = get_db_connection()
    
    # Index document chunks
    chunks = conn.execute("""
        SELECT c.id, c.domain, c.content, c.category, d.title 
        FROM document_chunks c 
        JOIN knowledge_documents d ON c.document_id = d.id 
        WHERE d.is_active = 1
    """).fetchall()
    
    for c in chunks:
        vector_store.add_chunk(
            domain=c["domain"],
            chunk_id=f"doc_{c['id']}",
            content=c["content"],
            title=c["title"],
            category=c["category"],
            source_type="doc"
        )
        
    # Index FAQs as high-value chunks
    faqs = conn.execute("SELECT id, domain, category, question, answer FROM faqs WHERE is_active = 1").fetchall()
    for f in faqs:
        combined_text = f"Question: {f['question']}\nAnswer: {f['answer']}"
        vector_store.add_chunk(
            domain=f["domain"],
            chunk_id=f"faq_{f['id']}",
            content=combined_text,
            title=f"FAQ: {f['question']}",
            category=f["category"],
            source_type="faq"
        )
        
    conn.close()
    vector_store.build_index()
    print(f"[VectorStore] Indexed {len(chunks)} document chunks and {len(faqs)} FAQs successfully.")
