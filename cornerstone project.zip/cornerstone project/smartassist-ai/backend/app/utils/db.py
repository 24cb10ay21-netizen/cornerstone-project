import sqlite3
import os
from pathlib import Path
from config.settings import settings

def get_db_path():
    # Extract path from sqlite URL or fallback
    url = settings.DATABASE_URL
    if url.startswith("sqlite:///"):
        path_str = url.replace("sqlite:///", "")
        path = Path(path_str)
    else:
        path = settings.BASE_DIR / "database" / "smartassist.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    return str(path)

def get_db_connection():
    db_path = get_db_path()
    conn = sqlite3.connect(db_path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 1. Users table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('student', 'customer', 'admin')),
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)
    
    # 2. Student Profiles
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS student_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        student_id TEXT UNIQUE,
        department TEXT,
        program TEXT,
        year_of_study INTEGER,
        semester INTEGER,
        roll_number TEXT,
        cgpa REAL,
        attendance_pct REAL,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 3. Customer Profiles
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customer_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE NOT NULL,
        customer_code TEXT UNIQUE,
        company_name TEXT,
        phone_number TEXT,
        customer_tier TEXT DEFAULT 'Standard',
        address TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 4. Conversations
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS conversations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT DEFAULT 'New Conversation',
        domain TEXT NOT NULL CHECK(domain IN ('student', 'customer')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    );
    """)

    # 5. Chat Messages
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id INTEGER NOT NULL,
        sender TEXT NOT NULL CHECK(sender IN ('user', 'assistant', 'system')),
        text TEXT NOT NULL,
        intent TEXT,
        confidence REAL,
        sources_json TEXT,
        helpful_rating INTEGER DEFAULT 0, -- 1: helpful, -1: unhelpful, 0: neutral
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE
    );
    """)

    # 6. Knowledge Documents
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS knowledge_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        domain TEXT NOT NULL CHECK(domain IN ('student', 'customer', 'general')),
        category TEXT NOT NULL,
        file_path TEXT,
        file_type TEXT,
        content TEXT NOT NULL,
        chunk_count INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 7. Document Chunks for RAG
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS document_chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        chunk_index INTEGER NOT NULL,
        content TEXT NOT NULL,
        category TEXT,
        domain TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (document_id) REFERENCES knowledge_documents (id) ON DELETE CASCADE
    );
    """)

    # 8. FAQs
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS faqs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT NOT NULL CHECK(domain IN ('student', 'customer')),
        category TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        keywords TEXT,
        view_count INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    """)

    # 9. Support Tickets
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS support_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_number TEXT UNIQUE NOT NULL,
        user_id INTEGER NOT NULL,
        domain TEXT NOT NULL CHECK(domain IN ('student', 'customer')),
        category TEXT NOT NULL,
        subject TEXT NOT NULL,
        description TEXT NOT NULL,
        priority TEXT NOT NULL CHECK(priority IN ('low', 'medium', 'high', 'urgent')),
        status TEXT NOT NULL CHECK(status IN ('open', 'in_progress', 'resolved', 'closed')),
        admin_response TEXT,
        resolved_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 10. Ticket Responses
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ticket_responses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        sender_id INTEGER NOT NULL,
        sender_name TEXT NOT NULL,
        sender_role TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ticket_id) REFERENCES support_tickets (id) ON DELETE CASCADE,
        FOREIGN KEY (sender_id) REFERENCES users (id) ON DELETE CASCADE
    );
    """)

    # 11. User Feedback
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS user_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        domain TEXT NOT NULL CHECK(domain IN ('student', 'customer')),
        rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        category TEXT,
        feedback_text TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
    );
    """)

    # 12. Chatbot Analytics
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chatbot_analytics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        domain TEXT NOT NULL,
        query_text TEXT NOT NULL,
        intent TEXT,
        confidence REAL,
        response_time_ms INTEGER,
        was_answered BOOLEAN DEFAULT 1,
        resolution_method TEXT, -- 'rag_exact', 'rag_synthesis', 'faq_direct', 'fallback'
        feedback INTEGER DEFAULT 0 -- 1: helpful, -1: unhelpful
    );
    """)

    # Indexes for fast querying
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_faqs_domain ON faqs (domain);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_faqs_category ON faqs (category);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tickets_user ON support_tickets (user_id);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_tickets_status ON support_tickets (status);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_analytics_domain ON chatbot_analytics (domain);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_domain ON document_chunks (domain);")

    conn.commit()
    conn.close()
