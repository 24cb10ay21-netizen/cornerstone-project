import re
from typing import Dict, Any, Tuple

# Domain keywords
STUDENT_KEYWORDS = {
    "admission", "admissions", "enroll", "enrollment", "course", "courses", "syllabus", 
    "exam", "exams", "examination", "hall ticket", "attendance", "absent", "cgpa", "gpa", 
    "grade", "semester", "fee", "fees", "tuition", "scholarship", "financial aid", 
    "placement", "internship", "campus", "hostel", "mess", "library", "faculty", 
    "professor", "hod", "bonafide", "revaluation", "convocation", "student id", "curriculum"
}

CUSTOMER_KEYWORDS = {
    "product", "products", "order", "orders", "shipping", "delivery", "track", "tracking", 
    "invoice", "billing", "price", "pricing", "discount", "coupon", "refund", "return", 
    "replace", "replacement", "warranty", "complaint", "broken", "defective", "subscription", 
    "license", "api", "support ticket", "client", "customer service", "cancellation", "cancel"
}

# Fine-grained Intent keywords mapping
STUDENT_INTENTS = {
    "admissions": [
        "admission", "admit", "eligibility", "cut off", "cutoff", "apply", "application form",
        "entrance exam", "seat matrix", "lateral entry", "quota", "intake", "criteria"
    ],
    "courses": [
        "syllabus", "curriculum", "subject", "electives", "credit", "branch", "department",
        "specialization", "course structure", "btech", "mtech", "bba", "mba", "labs"
    ],
    "examinations": [
        "exam", "examination", "datesheet", "timetable", "time table", "hall ticket", "admit card",
        "revaluation", "backlog", "supplementary", "passing marks", "grading", "cgpa", "sgpa"
    ],
    "attendance": [
        "attendance", "shortage", "condonation", "medical certificate", "absent", "leave application",
        "75 percent", "percentage", "minimum attendance", "detained"
    ],
    "fees": [
        "fee", "fees", "tuition", "hostel fee", "installment", "payment portal", "challan",
        "due date", "fine", "late fee", "receipt", "caution deposit", "refund of caution"
    ],
    "scholarships": [
        "scholarship", "financial aid", "merit", "fee concession", "waiver", "freeship",
        "nsp", "national scholarship", "economically weaker", "stipend"
    ],
    "placements": [
        "placement", "internship", "companies", "recruiter", "package", "ctc", "highest package",
        "average package", "drive", "interview", "resume", "aptitude", "tpo"
    ],
    "calendar": [
        "academic calendar", "holiday", "vacation", "semester start", "term end", "fest", 
        "cultural event", "sports day", "schedule"
    ],
    "facilities": [
        "hostel", "mess", "library", "transport", "bus", "gym", "sports", "cafeteria",
        "wifi", "health center", "hospital", "canteen", "labs"
    ]
}

CUSTOMER_INTENTS = {
    "product_info": [
        "product", "feature", "specification", "spec", "compatibility", "model", "version",
        "hardware", "software", "device", "catalogue", "catalog", "manual"
    ],
    "pricing": [
        "price", "pricing", "cost", "quote", "discount", "bulk order", "tier", "subscription",
        "enterprise plan", "payment method", "credit card", "tax", "gst"
    ],
    "order_status": [
        "order", "track", "tracking", "dispatch", "courier", "awb", "consignment", "delivery",
        "shipped", "shipping status", "where is my order", "delay", "estimated delivery"
    ],
    "complaints": [
        "complaint", "defective", "damaged", "broken", "poor service", "not working",
        "issue", "problem", "disappointed", "faulty", "escalate", "unacceptable"
    ],
    "refund_cancellation": [
        "refund", "cancel", "cancellation", "return", "replace", "exchange", "money back",
        "chargeback", "reverse payment", "policy"
    ],
    "tech_support": [
        "error", "bug", "troubleshoot", "crash", "login failed", "password reset", "api error",
        "connection", "setup", "install", "configuration", "server down", "timeout"
    ],
    "feedback": [
        "feedback", "suggestion", "review", "rate", "rating", "recommendation", "improve"
    ]
}

# Common spelling correction mapping
TYPO_CORRECTIONS = {
    "admisn": "admission", "admision": "admission", "attandance": "attendance", 
    "atendance": "attendance", "syllubus": "syllabus", "syllbus": "syllabus",
    "fee": "fee", "feee": "fee", "scolarship": "scholarship", "sholarship": "scholarship",
    "hostle": "hostel", "complnt": "complaint", "refnd": "refund", "refeund": "refund",
    "cancle": "cancel", "shiping": "shipping", "delvery": "delivery", "ordr": "order"
}

def clean_and_normalize(text: str) -> str:
    text = text.lower().strip()
    words = re.findall(r'\b[a-z0-9_-]+\b', text)
    corrected_words = [TYPO_CORRECTIONS.get(w, w) for w in words]
    return " ".join(corrected_words)

class IntentClassifier:
    @staticmethod
    def detect_domain(text: str, default_domain: str = "student") -> Tuple[str, float]:
        norm = clean_and_normalize(text)
        tokens = set(norm.split())
        
        student_matches = len(tokens.intersection(STUDENT_KEYWORDS))
        customer_matches = len(tokens.intersection(CUSTOMER_KEYWORDS))
        
        total = student_matches + customer_matches
        if total == 0:
            return default_domain, 0.5
            
        if student_matches > customer_matches:
            confidence = student_matches / total
            return "student", min(0.98, max(0.6, confidence))
        elif customer_matches > student_matches:
            confidence = customer_matches / total
            return "customer", min(0.98, max(0.6, confidence))
        else:
            return default_domain, 0.55

    @staticmethod
    def classify_intent(text: str, domain: str) -> Dict[str, Any]:
        norm = clean_and_normalize(text)
        
        # Check greetings
        if re.search(r'\b(hello|hi|hey|good morning|good evening|good afternoon|namaste|help)\b', norm):
            return {
                "intent": f"greeting_{domain}",
                "category": "general",
                "confidence": 0.95
            }
            
        intents_dict = STUDENT_INTENTS if domain == "student" else CUSTOMER_INTENTS
        best_intent = "general_inquiry"
        best_score = 0
        best_category = "General"
        
        for intent_name, keywords in intents_dict.items():
            score = 0
            for kw in keywords:
                if " " in kw:
                    if kw in norm:
                        score += 3
                else:
                    if re.search(r'\b' + re.escape(kw) + r'\b', norm):
                        score += 1
                        
            if score > best_score:
                best_score = score
                best_intent = intent_name
                best_category = intent_name.replace("_", " ").title()
                
        confidence = min(0.95, 0.5 + (best_score * 0.15)) if best_score > 0 else 0.40
        return {
            "intent": best_intent,
            "category": best_category,
            "confidence": round(confidence, 2)
        }
