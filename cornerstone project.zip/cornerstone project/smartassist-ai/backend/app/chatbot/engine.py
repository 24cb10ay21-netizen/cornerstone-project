import time
import json
from typing import Dict, Any, Optional, List
from app.chatbot.intent_classifier import IntentClassifier
from app.rag.retriever import Retriever
from app.rag.llm_client import llm_client
from app.utils.db import get_db_connection

class ChatbotEngine:
    @staticmethod
    def process_message(
        query: str, 
        domain: str, 
        user_id: Optional[int] = None, 
        conversation_id: Optional[int] = None
    ) -> Dict[str, Any]:
        start_time = time.time()
        
        # 1. Domain Detection and Validation
        detected_domain, domain_conf = IntentClassifier.detect_domain(query, default_domain=domain)
        # Prefer user explicit domain unless strongly mismatched
        active_domain = domain if domain in ["student", "customer"] else detected_domain
        
        # 2. Intent Classification
        intent_info = IntentClassifier.classify_intent(query, domain=active_domain)
        
        # 3. Retrieve Context via RAG
        retrieval_data = Retriever.retrieve_context(
            query=query, 
            domain=active_domain, 
            top_k=4, 
            threshold=0.15
        )
        
        # 4. Fetch recent conversation history if conversation_id provided
        chat_history = []
        conn = get_db_connection()
        if conversation_id:
            recent_rows = conn.execute(
                "SELECT sender, text FROM chat_messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 4",
                (conversation_id,)
            ).fetchall()
            chat_history = [{"role": r["sender"], "text": r["text"]} for r in reversed(recent_rows)]
            
        # 5. Generate Response via LLM / Local RAG Engine
        gen_result = llm_client.generate_response(
            query=query,
            domain=active_domain,
            intent_info=intent_info,
            retrieval_data=retrieval_data,
            chat_history=chat_history
        )
        
        elapsed_ms = int((time.time() - start_time) * 1000)
        
        # 6. Database Logging
        # Ensure conversation exists
        if not conversation_id:
            # Create a new conversation
            conv_title = query[:40] + ("..." if len(query) > 40 else "")
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO conversations (user_id, title, domain) VALUES (?, ?, ?)",
                (user_id, conv_title, active_domain)
            )
            conversation_id = cur.lastrowid
            conn.commit()
            
        # Store user query
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO chat_messages (conversation_id, sender, text, intent, confidence) VALUES (?, 'user', ?, ?, ?)",
            (conversation_id, query, intent_info["intent"], intent_info["confidence"])
        )
        user_msg_id = cur.lastrowid
        
        # Store assistant response
        sources_json = json.dumps(gen_result.get("sources", []))
        cur.execute(
            "INSERT INTO chat_messages (conversation_id, sender, text, intent, confidence, sources_json) VALUES (?, 'assistant', ?, ?, ?, ?)",
            (conversation_id, gen_result["answer"], intent_info["intent"], intent_info["confidence"], sources_json)
        )
        assistant_msg_id = cur.lastrowid
        
        # Log analytics
        cur.execute("""
            INSERT INTO chatbot_analytics 
            (domain, query_text, intent, confidence, response_time_ms, was_answered, resolution_method) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            active_domain,
            query,
            intent_info["intent"],
            intent_info["confidence"],
            elapsed_ms,
            0 if gen_result.get("is_fallback") else 1,
            gen_result.get("engine", "rag_engine")
        ))
        conn.commit()
        conn.close()
        
        return {
            "conversation_id": conversation_id,
            "user_message_id": user_msg_id,
            "assistant_message_id": assistant_msg_id,
            "answer": gen_result["answer"],
            "domain": active_domain,
            "intent": intent_info["intent"],
            "category": intent_info["category"],
            "confidence": intent_info["confidence"],
            "sources": gen_result.get("sources", []),
            "suggested_questions": gen_result.get("suggested_questions", []),
            "can_escalate": gen_result.get("can_escalate", False),
            "engine": gen_result.get("engine", "smartassist_rag_engine"),
            "is_fallback": gen_result.get("is_fallback", False),
            "response_time_ms": elapsed_ms
        }
