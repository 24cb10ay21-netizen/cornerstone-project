from functools import wraps
from flask import request, jsonify, g
from app.authentication.jwt_handler import JWTHandler
from app.utils.db import get_db_connection

def get_current_user_from_token():
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
        
    parts = auth_header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
        
    token = parts[1]
    payload = JWTHandler.decode_access_token(token)
    if not payload:
        return None
        
    user_id = payload.get("user_id") or payload.get("sub")
    if not user_id:
        return None
        
    conn = get_db_connection()
    user = conn.execute("SELECT id, email, full_name, role, is_active FROM users WHERE id = ?", (user_id,)).fetchone()
    conn.close()
    
    if not user or not user["is_active"]:
        return None
        
    return dict(user)

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user_from_token()
        if not user:
            return jsonify({
                "status": "error",
                "message": "Authentication required. Please login."
            }), 401
        g.current_user = user
        return f(*args, **kwargs)
    return decorated

def require_role(*allowed_roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = get_current_user_from_token()
            if not user:
                return jsonify({
                    "status": "error",
                    "message": "Authentication required. Please login."
                }), 401
            
            if user["role"] not in allowed_roles:
                return jsonify({
                    "status": "error",
                    "message": f"Forbidden. Role '{user['role']}' is not authorized for this resource."
                }), 403
                
            g.current_user = user
            return f(*args, **kwargs)
        return decorated
    return decorator

def optional_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user_from_token()
        g.current_user = user
        return f(*args, **kwargs)
    return decorated
