import hashlib
import secrets

try:
    from werkzeug.security import generate_password_hash as wz_gen_hash, check_password_hash as wz_chk_hash
    HAS_WERKZEUG = True
except ImportError:
    HAS_WERKZEUG = False

def hash_password(password: str) -> str:
    """Hashes a password securely using Werkzeug or PBKDF2-HMAC-SHA256."""
    if HAS_WERKZEUG:
        return wz_gen_hash(password)
    
    salt = secrets.token_hex(16)
    key = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000
    )
    return f"pbkdf2:sha256:{salt}:{key.hex()}"

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password against the stored hash."""
    if not plain_password or not hashed_password:
        return False
        
    if HAS_WERKZEUG and (hashed_password.startswith('scrypt:') or hashed_password.startswith('pbkdf2:')):
        try:
            return wz_chk_hash(hashed_password, plain_password)
        except Exception:
            pass
            
    if hashed_password.startswith("pbkdf2:sha256:"):
        parts = hashed_password.split(':')
        if len(parts) == 4:
            _, _, salt, stored_key = parts
            key = hashlib.pbkdf2_hmac(
                'sha256',
                plain_password.encode('utf-8'),
                salt.encode('utf-8'),
                100000
            )
            return secrets.compare_digest(key.hex(), stored_key)
            
    return False
