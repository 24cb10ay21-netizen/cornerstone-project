import hmac
import hashlib
import base64
import json
import time
from typing import Dict, Any, Optional
from config.settings import settings

def _base64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode('utf-8').rstrip('=')

def _base64url_decode(data: str) -> bytes:
    padding = '=' * (-len(data) % 4)
    return base64.urlsafe_b64decode((data + padding).encode('utf-8'))

class JWTHandler:
    @staticmethod
    def create_access_token(payload: Dict[str, Any], expires_in_seconds: Optional[int] = None) -> str:
        if expires_in_seconds is None:
            expires_in_seconds = settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60
            
        header = {"alg": "HS256", "typ": "JWT"}
        token_payload = payload.copy()
        now = int(time.time())
        token_payload.setdefault("iat", now)
        token_payload.setdefault("exp", now + expires_in_seconds)
        
        header_b64 = _base64url_encode(json.dumps(header, separators=(',', ':')).encode('utf-8'))
        payload_b64 = _base64url_encode(json.dumps(token_payload, separators=(',', ':')).encode('utf-8'))
        
        signing_input = f"{header_b64}.{payload_b64}".encode('utf-8')
        signature = hmac.new(settings.SECRET_KEY.encode('utf-8'), signing_input, hashlib.sha256).digest()
        signature_b64 = _base64url_encode(signature)
        
        return f"{header_b64}.{payload_b64}.{signature_b64}"

    @staticmethod
    def decode_access_token(token: str) -> Optional[Dict[str, Any]]:
        try:
            parts = token.strip().split('.')
            if len(parts) != 3:
                return None
            
            header_b64, payload_b64, signature_b64 = parts
            signing_input = f"{header_b64}.{payload_b64}".encode('utf-8')
            expected_sig = hmac.new(settings.SECRET_KEY.encode('utf-8'), signing_input, hashlib.sha256).digest()
            expected_sig_b64 = _base64url_encode(expected_sig)
            
            if not hmac.compare_digest(signature_b64, expected_sig_b64):
                return None
                
            payload_bytes = _base64url_decode(payload_b64)
            payload = json.loads(payload_bytes.decode('utf-8'))
            
            # Check expiration
            if "exp" in payload and payload["exp"] < int(time.time()):
                return None
                
            return payload
        except Exception:
            return None
