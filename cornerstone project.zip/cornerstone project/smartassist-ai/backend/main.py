import os
import sys
from pathlib import Path

# Add backend directory to sys.path
backend_dir = Path(__file__).resolve().parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from config.settings import settings
from app.utils.seed_data import seed_database

# Import Blueprints
from app.routes.auth_routes import auth_bp
from app.routes.chat_routes import chat_bp
from app.routes.student_routes import student_bp
from app.routes.customer_routes import customer_bp
from app.routes.ticket_routes import ticket_bp
from app.routes.knowledge_routes import knowledge_bp
from app.routes.admin_routes import admin_bp
from app.routes.analytics_routes import analytics_bp

def create_app():
    dist_dir = backend_dir.parent / "frontend" / "dist"
    
    if dist_dir.exists():
        app = Flask(__name__, static_folder=str(dist_dir), static_url_path="/")
    else:
        app = Flask(__name__)
        
    app.config["SECRET_KEY"] = settings.SECRET_KEY
    app.config["MAX_CONTENT_LENGTH"] = settings.MAX_CONTENT_LENGTH
    
    # Enable CORS for development (e.g. Vite on port 5173 or 3000)
    CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)
    
    # Register API Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(chat_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(customer_bp)
    app.register_blueprint(ticket_bp)
    app.register_blueprint(knowledge_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(analytics_bp)
    
    @app.route("/api/health", methods=["GET"])
    def health_check():
        return jsonify({
            "status": "online",
            "version": settings.VERSION,
            "service": "SmartAssist AI",
            "llm_provider": settings.LLM_PROVIDER,
            "has_gemini_key": bool(settings.GEMINI_API_KEY),
            "rag_engine": "active"
        })

    # Serve Built Frontend SPA
    if dist_dir.exists():
        @app.route("/", defaults={"path": ""})
        @app.route("/<path:path>")
        def serve_spa(path):
            if path != "" and (dist_dir / path).exists():
                return send_from_directory(str(dist_dir), path)
            return send_from_directory(str(dist_dir), "index.html")
    else:
        @app.route("/", methods=["GET"])
        def index():
            return jsonify({
                "name": "SmartAssist AI API Gateway",
                "version": settings.VERSION,
                "status": "healthy",
                "documentation": "/api/health"
            })
        
    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api/"):
            return jsonify({"status": "error", "message": "API endpoint not found."}), 404
        if dist_dir.exists():
            return send_from_directory(str(dist_dir), "index.html")
        return jsonify({"status": "error", "message": "Not found"}), 404

    @app.errorhandler(500)
    def internal_error(e):
        return jsonify({"status": "error", "message": "An internal server error occurred."}), 500

    return app

# Instantiate app
app = create_app()

if __name__ == "__main__":
    print(f"[*] Initializing SmartAssist AI Backend v{settings.VERSION}...")
    seed_database()
    port = int(os.getenv("PORT", 5000))
    print(f"[*] Server listening on http://127.0.0.1:{port}")
    print(f"[*] Web Application ready: open http://127.0.0.1:{port} in your browser")
    app.run(host="0.0.0.0", port=port, debug=settings.DEBUG)
