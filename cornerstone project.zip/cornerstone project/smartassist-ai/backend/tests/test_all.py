import sys
import unittest
import json
from pathlib import Path

# Set up paths
backend_dir = Path(__file__).resolve().parent.parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from main import app
from app.utils.seed_data import seed_database
from app.chatbot.intent_classifier import IntentClassifier
from app.rag.retriever import Retriever
from app.rag.llm_client import llm_client

class SmartAssistTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        seed_database()
        cls.client = app.test_client()

    def test_01_healthcheck(self):
        """Test API Gateway Healthcheck"""
        resp = self.client.get("/api/health")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["status"], "online")
        self.assertEqual(data["service"], "SmartAssist AI")

    def test_02_intent_classification(self):
        """Test Intent Classifier on Student and Customer queries"""
        # Student queries
        res_stu = IntentClassifier.classify_intent("What is the minimum attendance required for exams?", domain="student")
        self.assertEqual(res_stu["intent"], "attendance")
        self.assertGreater(res_stu["confidence"], 0.6)

        # Customer queries
        res_cust = IntentClassifier.classify_intent("How can I track my shipment package status?", domain="customer")
        self.assertEqual(res_cust["intent"], "order_status")
        self.assertGreater(res_cust["confidence"], 0.6)

        # Domain detection
        domain, conf = IntentClassifier.detect_domain("Can I apply for B.Tech CS admission?")
        self.assertEqual(domain, "student")

        domain2, conf2 = IntentClassifier.detect_domain("Where is my product delivery tracking number?")
        self.assertEqual(domain2, "customer")

    def test_03_rag_retrieval(self):
        """Test RAG Knowledge Base Retrieval"""
        retrieval = Retriever.retrieve_context("What is the fee for B.Tech?", domain="student")
        self.assertTrue(retrieval["has_context"])
        self.assertGreater(len(retrieval["results"]), 0)

        retrieval_cust = Retriever.retrieve_context("What is your refund policy?", domain="customer")
        self.assertTrue(retrieval_cust["has_context"])
        self.assertGreater(len(retrieval_cust["results"]), 0)

    def test_04_auth_login_and_roles(self):
        """Test Login for Admin, Student, and Customer"""
        # Admin login
        resp = self.client.post("/api/auth/login", json={
            "email": "admin@smartassist.edu",
            "password": "admin123"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("token", data)
        self.assertEqual(data["user"]["role"], "admin")
        admin_token = data["token"]

        # Student login
        resp_s = self.client.post("/api/auth/login", json={
            "email": "alex.student@smartassist.edu",
            "password": "student123"
        })
        self.assertEqual(resp_s.status_code, 200)
        self.assertEqual(resp_s.get_json()["user"]["role"], "student")

        # Customer login
        resp_c = self.client.post("/api/auth/login", json={
            "email": "sarah.buyer@acmecorp.com",
            "password": "customer123"
        })
        self.assertEqual(resp_c.status_code, 200)
        self.assertEqual(resp_c.get_json()["user"]["role"], "customer")

        # Invalid login test
        resp_bad = self.client.post("/api/auth/login", json={
            "email": "admin@smartassist.edu",
            "password": "wrongpassword"
        })
        self.assertEqual(resp_bad.status_code, 401)

    def test_05_student_chatbot_endpoint(self):
        """Test End-to-End Chatbot Message Processing for Student Support"""
        resp = self.client.post("/api/chat/message", json={
            "query": "What is the mandatory attendance percentage?",
            "domain": "student"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()["data"]
        self.assertEqual(data["domain"], "student")
        self.assertEqual(data["intent"], "attendance")
        self.assertIn("75%", data["answer"])
        self.assertIn("conversation_id", data)

    def test_06_customer_chatbot_endpoint(self):
        """Test End-to-End Chatbot Message Processing for Customer Support"""
        resp = self.client.post("/api/chat/message", json={
            "query": "What is your refund policy for software subscriptions?",
            "domain": "customer"
        })
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()["data"]
        self.assertEqual(data["domain"], "customer")
        self.assertIn("30-day", data["answer"])

    def test_07_support_tickets_crud(self):
        """Test Ticket Creation, Threading, and Admin Status Update"""
        # 1. Login as Student
        resp_s = self.client.post("/api/auth/login", json={
            "email": "alex.student@smartassist.edu",
            "password": "student123"
        })
        student_token = resp_s.get_json()["token"]
        headers_student = {"Authorization": f"Bearer {student_token}"}

        # 2. Create ticket
        create_resp = self.client.post("/api/tickets", headers=headers_student, json={
            "subject": "Missing Lab Assignment Marks in ERP",
            "description": "Lab practical marks for Database Systems (CS304) have not synced into ERP portal.",
            "category": "Courses & Syllabus",
            "priority": "high",
            "domain": "student"
        })
        self.assertEqual(create_resp.status_code, 201)
        ticket_id = create_resp.get_json()["ticket"]["id"]

        # 3. Add student reply
        reply_resp = self.client.post(f"/api/tickets/{ticket_id}/respond", headers=headers_student, json={
            "message": "Attaching screenshot of submission receipt."
        })
        self.assertEqual(reply_resp.status_code, 200)

        # 4. Admin updates ticket
        resp_adm = self.client.post("/api/auth/login", json={
            "email": "admin@smartassist.edu",
            "password": "admin123"
        })
        admin_token = resp_adm.get_json()["token"]
        headers_admin = {"Authorization": f"Bearer {admin_token}"}

        patch_resp = self.client.patch(f"/api/tickets/{ticket_id}/status", headers=headers_admin, json={
            "status": "resolved",
            "admin_response": "Marks updated in ERP database after faculty verification."
        })
        self.assertEqual(patch_resp.status_code, 200)

        # 5. Verify resolved status
        get_resp = self.client.get(f"/api/tickets/{ticket_id}", headers=headers_student)
        self.assertEqual(get_resp.status_code, 200)
        self.assertEqual(get_resp.get_json()["ticket"]["status"], "resolved")

    def test_08_admin_dashboard_overview(self):
        """Test Admin Overview Metrics & Role Protection"""
        # Unauthorized access test
        unauth = self.client.get("/api/admin/overview")
        self.assertEqual(unauth.status_code, 401)

        # Authorized admin test
        resp_adm = self.client.post("/api/auth/login", json={
            "email": "admin@smartassist.edu",
            "password": "admin123"
        })
        admin_token = resp_adm.get_json()["token"]
        resp = self.client.get("/api/admin/overview", headers={"Authorization": f"Bearer {admin_token}"})
        self.assertEqual(resp.status_code, 200)
        metrics = resp.get_json()["data"]["metrics"]
        self.assertGreater(metrics["total_users"], 0)
        self.assertGreater(metrics["total_queries"], 0)

if __name__ == "__main__":
    unittest.main()
