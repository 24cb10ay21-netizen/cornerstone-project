# SmartAssist AI: Cloud-Based AI Chatbot for Automated Student & Customer Support Management

**SmartAssist AI** is a complete, production-grade, full-stack conversational support platform engineered for university campuses and enterprise businesses. It implements **Retrieval-Augmented Generation (RAG)**, **Natural Language Understanding (NLU)**, **strict zero-hallucination guardrails**, and **human-in-the-loop support ticketing**.

This repository serves as a major third-year B.Tech Computer Science Cornerstone Project.

---

## 🌟 Key Highlights & System Features

### 🎓 1. Independent Student Support Portal
- **Admissions & Eligibility**: Requirements for undergraduate, lateral entry, and cut-off marks.
- **Examinations**: Datesheet publication, hall ticket generation, revaluation procedures, 10-point grading scales.
- **Attendance & Condonation**: 75% minimum criteria tracking, hospital discharge condonation workflow.
- **Fee Structure**: Tuition breakdowns, installment deadlines, instant receipt download & 80E tax certificates.
- **Scholarships**: Chancellor's Merit, Dean's Honor Roll, Need-Based Aid, National Scholarship Portal (NSP).
- **Placements & Internships**: 240+ recruiting companies, average/highest CTC, summer credit guidelines.
- **Facilities**: Library hours & borrowing limits, hostel room allotment, cafeteria & bus transport.

### 🏢 2. Independent Customer Care Portal
- **Product Information**: Technical specs, system requirements, CRM/ERP plug-and-play integrations.
- **Pricing & Subscriptions**: Starter, Professional, and Enterprise bulk pricing plans.
- **Live Order Tracking**: Real-time lookup tool with milestones, courier carrier details, and estimated delivery.
- **Complaint Registration**: Direct SLA incident registration with 24-hour turnaround guarantees.
- **Refund & Cancellation**: 30-day money-back guarantee, 14-day hardware returns, bank refund turnaround.
- **Feedback & Rating**: 5-star customer experience evaluation.

### ⚙️ 3. Comprehensive Administrator Control Center
- **System Overview KPIs**: Active users, total student/customer queries, RAG resolution rate, avg response time.
- **User Role Management**: Search users, toggle accounts active/inactive, assign Administrator/Student/Customer roles.
- **Knowledge Base & RAG Management**: Add/edit/delete FAQs, upload PDF/DOCX/TXT handbooks with auto-chunking, and trigger real-time vector re-indexing.
- **Incident & Ticket Desk**: Assign priorities (Low, Medium, High, Urgent), threaded replies, and resolution tracking.
- **Interactive Analytics**: Daily query trend charts, intent distributions, most asked FAQs, and unanswered fallback query log.

---

## 🏗️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, Vite, Tailwind CSS, Lucide React, Axios, React Router 6 |
| **Backend** | Python 3, Flask / REST API Architecture, CORS |
| **Authentication** | RFC 7519 JWT (HS256), PBKDF2-HMAC-SHA256 Password Hashing |
| **AI & NLP** | Intent Classification, Typo Normalization, In-Memory Vector Store (TF-IDF & BM25 Cosine Similarity) |
| **RAG Engine** | Sliding-window semantic text chunking, verified fact grounding, zero-hallucination fallback |
| **LLM Layer** | Configurable: Local RAG Synthesizer (Zero-cost, built-in) or Google Gemini Pro / OpenAI |
| **Database** | SQLite (Zero-setup local) & PostgreSQL ready with full ORM schema & seed scripts |
| **Deployment** | Docker, Docker Compose, Nginx, Shell / Batch Launchers |

---

## ⚡ Quick Start: Running the Project Locally

### 1. Requirements
- Python 3.10+ (Tested on Python 3.11 and 3.13)
- Node.js 18+ and npm

### 2. Single-Step Launch (Serves Frontend & Backend on Port 5000)
From the project root:
```bash
# On Windows:
.\start_app.bat

# On Linux / macOS:
chmod +x start_app.sh
./start_app.sh
```
Or directly via Python:
```bash
cd smartassist-ai/backend
python main.py
```
Open **`http://127.0.0.1:5000`** in your browser.

---

## 🔑 Demonstration Accounts

The database comes pre-seeded with 40 FAQs, sample handbooks, and test accounts. You can also use the **1-Click Quick Demo Login buttons** on the sign-in page:

| Role | Email | Password | Access Privileges |
|---|---|---|---|
| **Administrator** | `admin@smartassist.edu` | `admin123` | Full admin panel, user roles, document upload, ticket resolution |
| **Student** | `alex.student@smartassist.edu` | `student123` | Academic chatbot, attendance stats, student tickets, syllabus FAQs |
| **Customer** | `sarah.buyer@acmecorp.com` | `customer123` | Commercial chatbot, order tracking, complaints, feedback submission |

---

## 🧪 Automated Testing Suite

Run the complete test suite verifying healthchecks, intent classification, vector retrieval, auth, student chatbot, customer chatbot, and ticket workflows:

```bash
cd smartassist-ai/backend
python tests/test_all.py
```
*Result: 8/8 integration tests pass in ~2 seconds.*

---

## 🐳 Docker Deployment

To launch the complete containerized stack:
```bash
cd smartassist-ai
docker-compose up --build -d
```
- Frontend: `http://localhost:80`
- Backend API: `http://localhost:5000`

---

## 📁 Repository Structure

```
smartassist-ai/
├── backend/
│   ├── app/
│   │   ├── authentication/     # JWT handler, password hashing, RBAC decorators
│   │   ├── chatbot/            # NLU intent classifier & chatbot engine
│   │   ├── models/             # Schema definitions & database connector
│   │   ├── rag/                # Document processor, vector store, retriever, LLM client
│   │   ├── routes/             # REST blueprints (auth, chat, student, customer, admin, tickets)
│   │   └── utils/              # Database schema migrations & 40+ item seed script
│   ├── config/                 # Central settings & env variables
│   ├── database/               # SQLite persistent database file
│   ├── uploads/                # User document uploads
│   ├── tests/                  # Unit and integration test suite
│   ├── requirements.txt
│   └── main.py                 # Application gateway & SPA server
├── frontend/
│   ├── src/
│   │   ├── components/         # Navbar, Footer, ChatWindow, TicketModal
│   │   ├── context/            # Global AuthContext
│   │   ├── pages/              # Landing, Login, Register, Student, Customer, Admin, Tickets
│   │   └── services/           # Axios API services
│   ├── dist/                   # Built production bundle
│   └── package.json
├── docs/                       # System architecture, ER diagram, workflow diagrams, API docs
├── docker/                     # Dockerfiles & Nginx configs
├── docker-compose.yml
├── .env.example
└── README.md
```
