import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Package, 
  Search, 
  LifeBuoy, 
  AlertTriangle, 
  Star, 
  CheckCircle, 
  Clock, 
  Truck, 
  Send, 
  ChevronDown, 
  ShieldCheck, 
  FileText 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import ChatWindow from '../components/ChatWindow';
import TicketModal from '../components/TicketModal';
import api from '../services/api';

export default function CustomerDashboard() {
  const { user } = useAuth();
  
  // FAQs
  const [faqs, setFaqs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFaq, setExpandedFaq] = useState(null);

  // Tickets
  const [tickets, setTickets] = useState([]);
  const [ticketModalOpen, setTicketModalOpen] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState(null);
  const [ticketPrefill, setTicketPrefill] = useState({});

  // Order Lookup Tool
  const [orderInput, setOrderInput] = useState('ORD-9821');
  const [orderResult, setOrderResult] = useState(null);
  const [orderLoading, setOrderLoading] = useState(false);

  // Complaint Form
  const [complaintSubject, setComplaintSubject] = useState('');
  const [complaintDesc, setComplaintDesc] = useState('');
  const [complaintSuccess, setComplaintSuccess] = useState(false);

  // Feedback Form
  const [starRating, setStarRating] = useState(5);
  const [feedbackCategory, setFeedbackCategory] = useState('AI Chatbot Response');
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);

  useEffect(() => {
    loadFaqs();
    loadCustomerData();
    handleOrderLookup('ORD-9821');
  }, [selectedCategory, searchQuery]);

  const loadFaqs = async () => {
    try {
      const params = {};
      if (selectedCategory !== 'All') params.category = selectedCategory;
      if (searchQuery) params.search = searchQuery;
      const res = await api.get('/customer/faqs', { params });
      if (res.data.status === 'success') {
        setFaqs(res.data.faqs || []);
        if (res.data.categories && categories.length === 0) {
          setCategories(['All', ...res.data.categories]);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadCustomerData = async () => {
    try {
      const res = await api.get('/tickets', { params: { domain: 'customer' } });
      if (res.data.status === 'success') {
        setTickets(res.data.tickets || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleOrderLookup = async (idToLook = null) => {
    const oid = idToLook || orderInput;
    if (!oid) return;
    setOrderLoading(true);
    try {
      const res = await api.post('/customer/order-status', { order_id: oid.trim() });
      if (res.data.status === 'success') {
        setOrderResult(res.data.order);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setOrderLoading(false);
    }
  };

  const handleRegisterComplaint = async (e) => {
    e.preventDefault();
    if (!complaintSubject.trim() || !complaintDesc.trim()) return;
    try {
      await api.post('/tickets', {
        subject: `[Complaint] ${complaintSubject}`,
        description: complaintDesc,
        domain: 'customer',
        category: 'Complaints',
        priority: 'high'
      });
      setComplaintSuccess(true);
      setComplaintSubject('');
      setComplaintDesc('');
      loadCustomerData();
      setTimeout(() => setComplaintSuccess(false), 5000);
    } catch (e) {
      console.error(e);
    }
  };

  const handleFeedbackSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/customer/feedback', {
        rating: starRating,
        category: feedbackCategory,
        feedback_text: feedbackText
      });
      setFeedbackSuccess(true);
      setFeedbackText('');
      setTimeout(() => setFeedbackSuccess(false), 5000);
    } catch (e) {
      console.error(e);
    }
  };

  const handleEscalateFromChat = (prefillData) => {
    setSelectedTicketId(null);
    setTicketPrefill({
      subject: prefillData.subject || 'Customer Service Escalation',
      description: prefillData.description || '',
      domain: 'customer',
      category: 'Technical Support'
    });
    setTicketModalOpen(true);
  };

  const profile = user?.profile || {
    company_name: 'Acme Solutions Inc.',
    customer_tier: 'Enterprise Tier',
    customer_code: 'CUST-8841',
    phone_number: '+1 (555) 234-5678'
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-purple-950 via-purple-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/30 text-purple-200 border border-purple-400/30 text-xs font-semibold">
              <Building2 className="w-3.5 h-3.5 text-purple-300" />
              <span>Commercial & Enterprise Support Desk</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome, {user?.full_name || 'Sarah Jenkins'}!
            </h1>
            <p className="text-xs sm:text-sm text-purple-200 max-w-xl">
              {profile.company_name} • {profile.customer_tier} • Code: {profile.customer_code}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => {
                setSelectedTicketId(null);
                setTicketPrefill({ domain: 'customer', category: 'Technical Support' });
                setTicketModalOpen(true);
              }}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-white text-purple-950 hover:bg-slate-100 shadow-md transition-all"
            >
              <LifeBuoy className="w-4 h-4 text-purple-600" />
              <span>Open Support Ticket</span>
            </button>
          </div>
        </div>

        {/* Commercial Status Quick KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-lg">
              99.95%
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Enterprise SLA Uptime</div>
              <div className="text-sm font-bold text-emerald-600 flex items-center">
                <CheckCircle className="w-3.5 h-3.5 mr-1" /> All Systems Online
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-lg">
              {profile.customer_tier.split(' ')[0]}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Account Tier</div>
              <div className="text-sm font-bold text-slate-800">Priority Routing</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-lg">
              {tickets.filter(t => t.status === 'resolved').length}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Resolved Cases</div>
              <div className="text-sm font-bold text-slate-800">&lt; 4 hr Turnaround</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-lg">
              {tickets.filter(t => t.status !== 'resolved').length}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Active Tickets</div>
              <div className="text-sm font-bold text-amber-700">Track Below</div>
            </div>
          </div>
        </div>

        {/* Main Grid: Chatbot (Left) + Order Tracking & Tools (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Chatbot Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                  <span>Customer Support AI Assistant</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                </h2>
                <p className="text-xs text-slate-500">
                  Ask about specifications, order tracking, warranties, and return policies
                </p>
              </div>
            </div>

            <ChatWindow 
              domain="customer"
              onEscalate={handleEscalateFromChat}
              title="SmartAssist Commercial Bot"
              subtitle="Grounded on Enterprise Service Catalogs & Warranty SLAs"
              initialSuggestions={[
                "How do I track my active package?",
                "What is your 30-day refund policy?",
                "Is SmartAssist compatible with Salesforce CRM?",
                "What subscription tiers are available?"
              ]}
            />
          </div>

          {/* Right Column: Order Tracker & Complaints */}
          <div className="lg:col-span-5 space-y-6">
            {/* Live Order Status Inquiry Form */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <Truck className="w-4 h-4 text-purple-600" />
                  <span>Live Package & Order Tracking</span>
                </h3>
                <span className="text-[10px] text-purple-600 font-semibold bg-purple-50 px-2 py-0.5 rounded-full">
                  Real-Time Logistics
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={orderInput}
                  onChange={(e) => setOrderInput(e.target.value.toUpperCase())}
                  placeholder="e.g. ORD-9821"
                  className="flex-1 text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20"
                />
                <button
                  type="button"
                  onClick={() => handleOrderLookup()}
                  disabled={orderLoading}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
                >
                  {orderLoading ? 'Searching...' : 'Track'}
                </button>
              </div>

              {orderResult && (
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-800">{orderResult.order_id}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      {orderResult.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 font-medium">{orderResult.item}</p>

                  <div className="text-[11px] text-slate-500 space-y-1">
                    <div>Carrier: <strong className="text-slate-700">{orderResult.carrier}</strong></div>
                    <div>AWB: <code className="bg-slate-200 px-1 py-0.5 rounded text-[10px]">{orderResult.tracking_number}</code></div>
                    <div>Delivery ETA: <span className="text-indigo-600 font-medium">{orderResult.estimated_delivery}</span></div>
                  </div>

                  {/* Visual Steps */}
                  <div className="pt-2 border-t border-slate-200/80 space-y-2">
                    {orderResult.steps?.map((step, idx) => (
                      <div key={idx} className="flex items-center space-x-2 text-xs">
                        <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center text-[9px] ${
                          step.completed ? 'bg-emerald-500 text-white' : 'bg-slate-300 text-slate-600'
                        }`}>
                          {step.completed ? '✓' : '•'}
                        </span>
                        <span className={`flex-1 ${step.completed ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                          {step.stage}
                        </span>
                        <span className="text-[10px] text-slate-400">{step.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Complaint Registration Box */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span>Quick Complaint Registration</span>
              </h3>
              <p className="text-xs text-slate-500">
                Log product defects, billing disputes, or delivery delays with 24h SLA response.
              </p>

              {complaintSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-xl flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 flex-shrink-0" />
                  <span>Complaint registered! Reference ticket has been generated.</span>
                </div>
              )}

              <form onSubmit={handleRegisterComplaint} className="space-y-3">
                <input
                  type="text"
                  value={complaintSubject}
                  onChange={(e) => setComplaintSubject(e.target.value)}
                  placeholder="Complaint Subject (e.g. Damaged unit on arrival)"
                  className="w-full text-xs px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
                <textarea
                  rows={2}
                  value={complaintDesc}
                  onChange={(e) => setComplaintDesc(e.target.value)}
                  placeholder="Details of complaint..."
                  className="w-full text-xs p-3.5 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-slate-800 hover:bg-slate-900 text-white py-2 rounded-xl text-xs font-semibold transition-colors"
                >
                  File Complaint
                </button>
              </form>
            </div>

            {/* Customer Feedback Form */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-3">
              <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                <Star className="w-4 h-4 text-amber-500" />
                <span>Submit Experience Feedback</span>
              </h3>

              {feedbackSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs rounded-xl flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 flex-shrink-0" />
                  <span>Thank you for your valuable feedback!</span>
                </div>
              )}

              <form onSubmit={handleFeedbackSubmit} className="space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-slate-600 font-medium">Rating:</span>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setStarRating(star)}
                        className={`text-lg transition-transform ${star <= starRating ? 'text-amber-400 scale-110' : 'text-slate-300'}`}
                      >
                        ★
                      </button>
                    ))}
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Share suggestions or comments..."
                  className="w-full text-xs p-3 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-xl text-xs font-semibold shadow-sm transition-all"
                >
                  Submit Feedback
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* BROWSE CUSTOMER FAQS */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900">Product & Service Knowledge Base</h3>
              <p className="text-xs text-slate-500">
                Official policies covering hardware warranties, return guidelines, and cloud integrations
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search orders, refunds, warranties..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20"
              />
            </div>
          </div>

          {categories.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pb-2 border-b border-slate-100">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                    selectedCategory === cat
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className="border border-slate-200 rounded-2xl p-4 transition-all hover:border-purple-300"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === faq.id ? null : faq.id)}
                  className="w-full text-left flex items-start justify-between gap-2"
                >
                  <div>
                    <span className="text-[10px] font-bold text-purple-600 uppercase tracking-wider block mb-1">
                      {faq.category}
                    </span>
                    <h4 className="text-xs sm:text-sm font-semibold text-slate-900">{faq.question}</h4>
                  </div>
                  <ChevronDown className={`w-4 h-4 text-slate-400 flex-shrink-0 transition-transform ${expandedFaq === faq.id ? 'rotate-180 text-purple-600' : ''}`} />
                </button>

                {expandedFaq === faq.id && (
                  <div className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <TicketModal
        isOpen={ticketModalOpen}
        onClose={() => setTicketModalOpen(false)}
        ticketId={selectedTicketId}
        prefilled={ticketPrefill}
        onSuccess={() => {
          loadCustomerData();
        }}
      />
    </div>
  );
}
