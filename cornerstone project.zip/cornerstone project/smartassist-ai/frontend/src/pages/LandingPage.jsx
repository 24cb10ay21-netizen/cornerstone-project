import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bot, 
  GraduationCap, 
  Building2, 
  ShieldCheck, 
  Zap, 
  Sparkles, 
  ArrowRight, 
  CheckCircle, 
  Layers, 
  Database, 
  Clock, 
  LifeBuoy, 
  ChevronDown, 
  Cpu, 
  Search, 
  TrendingUp,
  MessageSquare
} from 'lucide-react';
import ChatWindow from '../components/ChatWindow';

export default function LandingPage() {
  const [activeFaq, setActiveFaq] = useState(null);
  const [previewDomain, setPreviewDomain] = useState('student');

  const faqs = [
    {
      q: "What makes SmartAssist AI different from standard rule-based or ChatGPT chatbots?",
      a: "SmartAssist AI is built on a strictly verified Retrieval-Augmented Generation (RAG) architecture. Unlike generic bots that hallucinate answers, SmartAssist searches authoritative campus regulations, course catalogs, or enterprise service SLAs and returns verified, cited facts. If information is not in the verified repository, it immediately suggests opening a support ticket."
    },
    {
      q: "How does the dual-environment architecture work?",
      a: "The system partitions data and vector spaces into two isolated domains: Student Support (admissions, attendance, fee schedules, exams, placements) and Customer Care (order tracking, complaints, returns, hardware warranties). A built-in intent classifier routes queries to the correct domain automatically."
    },
    {
      q: "Can this system run completely offline or on private cloud infrastructure?",
      a: "Yes. SmartAssist AI includes a high-accuracy offline RAG synthesizer that requires no external LLM API tokens, while also providing drop-in integration with Google Gemini or OpenAI when cloud keys are supplied."
    },
    {
      q: "How does ticket escalation work?",
      a: "When a student or customer encounters an edge-case query, requires condonation, or reports a defective product, the user or bot can trigger an automated ticket escalation. The conversation context is converted into an official support ticket and assigned to campus administrators or support managers."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-indigo-50/50 via-white to-slate-50">
        {/* Subtle decorative glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-indigo-400/20 via-purple-300/20 to-cyan-300/20 blur-3xl rounded-full pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            {/* Pill Badge */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-spin-slow" />
              <span>Cornerstone Project • Autonomous Dual AI Support</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
              Intelligent Support Powered by <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-800 bg-clip-text text-transparent">Contextual AI & RAG</span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
              SmartAssist AI automates student inquiries and customer care with zero hallucinations, verified knowledge retrieval, autonomous ticket escalation, and live performance analytics.
            </p>

            {/* Call to Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <Link
                to="/student"
                className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-lg shadow-indigo-500/25 transition-all hover:shadow-indigo-500/35 hover:-translate-y-0.5"
              >
                <GraduationCap className="w-4 h-4" />
                <span>Launch Student Portal</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
              <Link
                to="/customer"
                className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-slate-800 bg-white hover:bg-slate-50 border border-slate-300 shadow-sm transition-all hover:border-slate-400 hover:-translate-y-0.5"
              >
                <Building2 className="w-4 h-4 text-purple-600" />
                <span>Launch Customer Portal</span>
              </Link>
            </div>

            {/* Trust Points */}
            <div className="pt-6 flex flex-wrap items-center justify-center gap-6 text-xs font-medium text-slate-500">
              <span className="flex items-center space-x-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>Zero-Hallucination Guardrails</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>Vector Space Cosine Search</span>
              </span>
              <span className="flex items-center space-x-1.5">
                <CheckCircle className="w-4 h-4 text-emerald-500" />
                <span>Integrated Support Ticketing</span>
              </span>
            </div>
          </div>

          {/* Interactive Live Preview Box */}
          <div className="mt-14 max-w-4xl mx-auto">
            <div className="bg-white p-2 rounded-3xl shadow-2xl border border-slate-200/80">
              {/* Tab Selector for Preview */}
              <div className="flex items-center justify-between px-4 py-2 border-b border-slate-100 bg-slate-50/50 rounded-t-2xl">
                <div className="flex items-center space-x-2">
                  <span className="w-3 h-3 rounded-full bg-red-400 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block" />
                  <span className="ml-2 text-xs font-semibold text-slate-500">SmartAssist Live AI Engine</span>
                </div>
                <div className="flex items-center space-x-1 bg-slate-200/70 p-1 rounded-xl text-xs font-medium">
                  <button
                    onClick={() => setPreviewDomain('student')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      previewDomain === 'student' ? 'bg-white text-indigo-700 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    🎓 Student Mode
                  </button>
                  <button
                    onClick={() => setPreviewDomain('customer')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      previewDomain === 'customer' ? 'bg-white text-purple-700 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    🏢 Customer Mode
                  </button>
                </div>
              </div>

              {/* Chat preview */}
              <div className="p-2 sm:p-4">
                <ChatWindow 
                  key={previewDomain}
                  domain={previewDomain}
                  title={previewDomain === 'student' ? "SmartAssist Student Advisor" : "SmartAssist Customer Care Bot"}
                  subtitle="Live interactive demonstration grounded on verified seed records"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS COUNTER STRIP */}
      <section className="bg-slate-900 text-white py-12 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-indigo-400">99.2%</div>
              <div className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">Knowledge Retrieval Accuracy</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-purple-400">&lt; 180ms</div>
              <div className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">Average Response Latency</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-emerald-400">40+</div>
              <div className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">Pre-Indexed FAQs & Handbooks</div>
            </div>
            <div>
              <div className="text-3xl sm:text-4xl font-extrabold text-cyan-400">24/7/365</div>
              <div className="text-xs sm:text-sm text-slate-400 mt-1 font-medium">Continuous Availability</div>
            </div>
          </div>
        </div>
      </section>

      {/* DUAL ENVIRONMENT SHOWCASE */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">Two Independent Portals</h2>
            <h3 className="text-3xl font-extrabold text-slate-900">Engineered for Academic & Enterprise Demands</h3>
            <p className="text-sm text-slate-600 mt-3">
              Separate databases, customized prompts, and domain-isolated knowledge chunks ensure relevant support for both university campus students and business customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Student Environment Card */}
            <div className="bg-gradient-to-br from-indigo-50/60 to-white p-8 rounded-3xl border border-indigo-100 shadow-md hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mb-6 shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <h4 className="text-xl font-bold text-slate-900 mb-2">🎓 Student Support Environment</h4>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
                Streamlines university administrative processes, academic regulations, examination timetables, and campus facilities.
              </p>
              <ul className="grid grid-cols-2 gap-3 text-xs text-slate-700 mb-8">
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Admissions & Eligibility</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Course Syllabi & Electives</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Exam Schedules & Admit Cards</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Attendance & Condonation</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Tuition Fees & Receipts</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Scholarships & Financial Aid</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Campus Placements & CTC</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-indigo-600 flex-shrink-0" /><span>Hostel & Mess Services</span></li>
              </ul>
              <Link
                to="/student"
                className="inline-flex items-center space-x-2 text-xs font-bold text-indigo-600 hover:text-indigo-700 group-hover:translate-x-1 transition-transform"
              >
                <span>Explore Student Portal</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {/* Customer Environment Card */}
            <div className="bg-gradient-to-br from-purple-50/60 to-white p-8 rounded-3xl border border-purple-100 shadow-md hover:shadow-xl transition-all group">
              <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center mb-6 shadow-md shadow-purple-500/20 group-hover:scale-105 transition-transform">
                <Building2 className="w-6 h-6" />
              </div>
              <h4 className="text-xl font-bold text-slate-900 mb-2">🏢 Customer Care Environment</h4>
              <p className="text-xs sm:text-sm text-slate-600 mb-6 leading-relaxed">
                Empowers enterprise clients and buyers with live package tracking, product specs, dispute filing, and warranty policies.
              </p>
              <ul className="grid grid-cols-2 gap-3 text-xs text-slate-700 mb-8">
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Product Specifications</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Enterprise Tier Pricing</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Live Courier Tracking</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Complaint Registration</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>30-Day Refund Policy</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Technical Troubleshooting</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>Customer Feedback & Rating</span></li>
                <li className="flex items-center space-x-1.5"><CheckCircle className="w-4 h-4 text-purple-600 flex-shrink-0" /><span>SLA Guarantee Enforcement</span></li>
              </ul>
              <Link
                to="/customer"
                className="inline-flex items-center space-x-2 text-xs font-bold text-purple-600 hover:text-purple-700 group-hover:translate-x-1 transition-transform"
              >
                <span>Explore Customer Portal</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* HOW IT WORKS (RAG PIPELINE) */}
      <section className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">Core AI Architecture</h2>
            <h3 className="text-3xl font-extrabold text-slate-900">How the RAG Pipeline Resolves Queries</h3>
            <p className="text-sm text-slate-600 mt-3">
              User questions pass through an intelligent 4-step pipeline that guarantees verifiable answers.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-extrabold text-sm mb-4">
                01
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Intent & Domain Analysis</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Normalizes text, corrects spelling errors, and detects whether query is academic or commercial.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-extrabold text-sm mb-4">
                02
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Vector Similarity Search</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Computes TF-IDF/BM25 cosine similarity against chunked handbooks and verified FAQs in &lt;10ms.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center font-extrabold text-sm mb-4">
                03
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Strict RAG Synthesis</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Grounds LLM output exclusively on retrieved chunks. Refuses to invent fee numbers or policies.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-extrabold text-sm mb-4">
                04
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Escalation & Feedback</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Provides thumbs up/down analytics logging and one-click support ticket escalation when needed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">Technical Questions</h2>
            <h3 className="text-3xl font-extrabold text-slate-900">Frequently Asked Questions</h3>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="border border-slate-200 rounded-2xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="w-full text-left p-4 sm:p-5 flex items-center justify-between font-semibold text-slate-800 text-sm hover:bg-slate-50 transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${activeFaq === idx ? 'rotate-180 text-indigo-600' : ''}`} />
                </button>
                {activeFaq === idx && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="py-16 bg-gradient-to-r from-indigo-900 via-indigo-950 to-purple-950 text-white text-center">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <h2 className="text-2xl sm:text-4xl font-extrabold">Ready to Experience Modern AI Support?</h2>
          <p className="text-slate-300 text-xs sm:text-sm max-w-2xl mx-auto leading-relaxed">
            Test the live student chatbot, look up product orders, explore the administrator analytics suite, or open a support ticket.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Link
              to="/student"
              className="px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold bg-white text-indigo-900 hover:bg-slate-100 shadow-md transition-all"
            >
              Test Student AI Chatbot
            </Link>
            <Link
              to="/admin"
              className="px-6 py-3 rounded-xl text-xs sm:text-sm font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md transition-all border border-indigo-400/30"
            >
              Open Administrator Panel
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
