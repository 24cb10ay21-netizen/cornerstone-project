import React, { useState, useEffect } from 'react';
import { 
  GraduationCap, 
  Calendar, 
  Award, 
  Clock, 
  LifeBuoy, 
  Search, 
  BookOpen, 
  CheckCircle, 
  FileText, 
  DollarSign, 
  TrendingUp, 
  Bell, 
  ChevronRight, 
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import ChatWindow from '../components/ChatWindow';
import TicketModal from '../components/TicketModal';
import api from '../services/api';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [faqs, setFaqs] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFaq, setExpandedFaq] = useState(null);
  
  const [tickets, setTickets] = useState([]);
  const [ticketModalOpen, setTicketModalOpen] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState(null);
  const [ticketPrefill, setTicketPrefill] = useState({});

  useEffect(() => {
    loadFaqs();
    loadStudentData();
  }, [selectedCategory, searchQuery]);

  const loadFaqs = async () => {
    try {
      const params = {};
      if (selectedCategory !== 'All') params.category = selectedCategory;
      if (searchQuery) params.search = searchQuery;
      const res = await api.get('/student/faqs', { params });
      if (res.data.status === 'success') {
        setFaqs(res.data.faqs || []);
        if (res.data.categories && categories.length === 0) {
          setCategories(['All', ...res.data.categories]);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadStudentData = async () => {
    try {
      const res = await api.get('/tickets', { params: { domain: 'student' } });
      if (res.data.status === 'success') {
        setTickets(res.data.tickets || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleEscalateFromChat = (prefillData) => {
    setSelectedTicketId(null);
    setTicketPrefill({
      subject: prefillData.subject || 'Student Query Escalation',
      description: prefillData.description || '',
      domain: 'student',
      category: 'General'
    });
    setTicketModalOpen(true);
  };

  const handleViewTicket = (tId) => {
    setSelectedTicketId(tId);
    setTicketModalOpen(true);
  };

  const profile = user?.profile || {
    department: 'Computer Science & Engineering',
    program: 'B.Tech CSE',
    semester: 6,
    roll_number: '22CS1042',
    cgpa: 8.85,
    attendance_pct: 84.5
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Welcome Header */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 text-xs font-semibold">
              <GraduationCap className="w-3.5 h-3.5 text-indigo-300" />
              <span>SmartAssist Student ERP Integrated Portal</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.full_name || 'Alex Chen'}!
            </h1>
            <p className="text-xs sm:text-sm text-indigo-200 max-w-xl">
              {profile.program} • Semester {profile.semester} • Roll No: {profile.roll_number}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => {
                setSelectedTicketId(null);
                setTicketPrefill({ domain: 'student', category: 'Examinations' });
                setTicketModalOpen(true);
              }}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-white text-indigo-950 hover:bg-slate-100 shadow-md transition-all"
            >
              <LifeBuoy className="w-4 h-4 text-indigo-600" />
              <span>New Support Ticket</span>
            </button>
          </div>
        </div>

        {/* Academic Status Quick KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-lg">
              {profile.attendance_pct}%
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Class Attendance</div>
              <div className="text-sm font-bold text-slate-800">
                {profile.attendance_pct >= 75 ? (
                  <span className="text-emerald-600 flex items-center space-x-1">
                    <CheckCircle className="w-3.5 h-3.5 inline mr-1" />
                    Above 75% Criteria
                  </span>
                ) : (
                  <span className="text-amber-600">Shortage Risk</span>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-lg">
              {profile.cgpa}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Cumulative CGPA</div>
              <div className="text-sm font-bold text-indigo-700">Dean's Honor List</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold text-lg">
              {tickets.filter(t => t.status === 'resolved').length}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Resolved Tickets</div>
              <div className="text-sm font-bold text-slate-800">100% Administrative SLA</div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-lg">
              {tickets.filter(t => t.status !== 'resolved').length}
            </div>
            <div>
              <div className="text-xs text-slate-500 font-medium">Active Inquiries</div>
              <div className="text-sm font-bold text-amber-700">Track in Real-Time</div>
            </div>
          </div>
        </div>

        {/* Main Grid: AI Chatbot (Left 60%) + Knowledge & Tickets (Right 40%) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* AI Chatbot Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center space-x-2">
                  <span>Student Support AI Assistant</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse" />
                </h2>
                <p className="text-xs text-slate-500">
                  Ask any question about university policies, fees, exams, and attendance
                </p>
              </div>
            </div>

            <ChatWindow 
              domain="student"
              onEscalate={handleEscalateFromChat}
              title="SmartAssist Student Advisor"
              subtitle="Grounded on 2025-2026 University Regulations & Handbooks"
              initialSuggestions={[
                "What is the minimum attendance requirement?",
                "What is the tuition fee and payment schedule?",
                "When will semester exam hall tickets be available?",
                "Can I obtain attendance condonation for medical leave?"
              ]}
            />
          </div>

          {/* Right Column: Support Tickets & Quick Guides */}
          <div className="lg:col-span-5 space-y-6">
            {/* My Support Tickets */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <LifeBuoy className="w-4 h-4 text-indigo-600" />
                  <span>My Academic Support Tickets</span>
                </h3>
                <button
                  onClick={() => {
                    setSelectedTicketId(null);
                    setTicketPrefill({ domain: 'student' });
                    setTicketModalOpen(true);
                  }}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
                >
                  + New Ticket
                </button>
              </div>

              {tickets.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">
                  No tickets opened yet. Ask the chatbot or create a ticket for human escalation.
                </div>
              ) : (
                <div className="space-y-2.5">
                  {tickets.slice(0, 4).map((ticket) => (
                    <div
                      key={ticket.id}
                      onClick={() => handleViewTicket(ticket.id)}
                      className="p-3 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/30 cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-bold text-slate-800">{ticket.ticket_number}</span>
                        <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize ${
                          ticket.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' :
                          ticket.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {ticket.status.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-1 font-medium">{ticket.subject}</p>
                      <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                        <span>{ticket.category}</span>
                        <span>{new Date(ticket.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Campus Contacts */}
            <div className="bg-gradient-to-br from-indigo-50 to-slate-50 rounded-2xl border border-indigo-100 p-5 shadow-sm space-y-3">
              <h3 className="text-xs font-bold text-indigo-900 uppercase tracking-wider flex items-center space-x-1.5">
                <Bell className="w-3.5 h-3.5 text-indigo-600" />
                <span>Important Academic Deadlines</span>
              </h3>
              <ul className="text-xs space-y-2 text-slate-700">
                <li className="flex items-center justify-between py-1 border-b border-indigo-100/60">
                  <span>Spring Semester Tuition Due:</span>
                  <strong className="text-indigo-900">January 15, 2027</strong>
                </li>
                <li className="flex items-center justify-between py-1 border-b border-indigo-100/60">
                  <span>SEE Hall Ticket Generation:</span>
                  <strong className="text-indigo-900">7 Days Prior</strong>
                </li>
                <li className="flex items-center justify-between py-1 border-b border-indigo-100/60">
                  <span>Medical Condonation Submission:</span>
                  <strong className="text-indigo-900">Within 7 Days</strong>
                </li>
                <li className="flex items-center justify-between py-1">
                  <span>Campus Placement Drives:</span>
                  <strong className="text-indigo-900">Sem 7 Onwards</strong>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* BROWSE FAQS SECTION */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900">Student Knowledge Repository & FAQs</h3>
              <p className="text-xs text-slate-500">
                Browse official university answers curated by the Academic Dean and Registrar
              </p>
            </div>

            {/* Search Box */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search regulations, fees, exams..."
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
          </div>

          {/* Category Tabs */}
          {categories.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pb-2 border-b border-slate-100">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          )}

          {/* FAQs List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {faqs.map((faq) => (
              <div
                key={faq.id}
                className="border border-slate-200 rounded-2xl p-4 transition-all hover:border-indigo-300"
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === faq.id ? null : faq.id)}
                  className="w-full text-left flex items-start justify-between gap-2"
                >
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider block mb-1">
                      {faq.category}
                    </span>
                    <h4 className="text-xs sm:text-sm font-semibold text-slate-900">{faq.question}</h4>
                  </div>
                  <ChevronDown className={`w-4 h-4 text-slate-400 flex-shrink-0 transition-transform ${expandedFaq === faq.id ? 'rotate-180 text-indigo-600' : ''}`} />
                </button>

                {expandedFaq === faq.id && (
                  <div className="mt-3 pt-3 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Ticket Modal */}
      <TicketModal
        isOpen={ticketModalOpen}
        onClose={() => setTicketModalOpen(false)}
        ticketId={selectedTicketId}
        prefilled={ticketPrefill}
        onSuccess={() => {
          loadStudentData();
        }}
      />
    </div>
  );
}
