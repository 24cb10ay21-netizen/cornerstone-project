import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  MessageSquare, 
  LifeBuoy, 
  BarChart3, 
  FileText, 
  Upload, 
  RefreshCw, 
  Trash2, 
  CheckCircle, 
  AlertCircle, 
  Search, 
  TrendingUp, 
  Clock, 
  HelpCircle, 
  Plus, 
  Tag, 
  UserCheck, 
  UserX,
  Sparkles,
  Globe
} from 'lucide-react';
import { adminService } from '../services/adminService';
import { knowledgeService } from '../services/knowledgeService';
import { ticketService } from '../services/ticketService';
import TicketModal from '../components/TicketModal';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview'); // overview | users | knowledge | tickets | analytics
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Overview metrics
  const [metrics, setMetrics] = useState({
    total_users: 3,
    total_queries: 10,
    student_queries: 6,
    customer_queries: 4,
    total_conversations: 5,
    resolved_tickets: 2,
    pending_tickets: 2,
    resolution_rate: 94.5,
    avg_response_time_ms: 185,
    satisfaction_score: 92.0
  });

  // Users State
  const [users, setUsers] = useState([]);
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('all');

  // Knowledge State
  const [faqs, setFaqs] = useState([]);
  const [faqDomain, setFaqDomain] = useState('all');
  const [documents, setDocuments] = useState([]);
  const [uploadFile, setUploadFile] = useState(null);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadDomain, setUploadDomain] = useState('student');
  const [uploadCategory, setUploadCategory] = useState('Handbooks');
  const [crawlUrl, setCrawlUrl] = useState('');
  const [crawlDomain, setCrawlDomain] = useState('student');
  const [crawlCategory, setCrawlCategory] = useState('Official Website');
  const [crawlLoading, setCrawlLoading] = useState(false);
  const [newFaqModal, setNewFaqModal] = useState(false);
  const [newFaq, setNewFaq] = useState({ domain: 'student', category: 'General', question: '', answer: '', keywords: '' });

  // Tickets State
  const [tickets, setTickets] = useState([]);
  const [ticketFilterStatus, setTicketFilterStatus] = useState('all');
  const [ticketFilterDomain, setTicketFilterDomain] = useState('all');
  const [selectedTicketId, setSelectedTicketId] = useState(null);
  const [ticketModalOpen, setTicketModalOpen] = useState(false);

  // Analytics State
  const [analyticsData, setAnalyticsData] = useState(null);
  const [topFaqs, setTopFaqs] = useState([]);
  const [unanswered, setUnanswered] = useState([]);

  useEffect(() => {
    loadOverview();
  }, []);

  const showBanner = (msg) => {
    setMessage(msg);
    setTimeout(() => setMessage(''), 4000);
  };

  const loadOverview = async () => {
    setLoading(true);
    try {
      const res = await adminService.getOverview();
      if (res.status === 'success') {
        setMetrics(res.data.metrics);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const res = await adminService.getUsers({ role: userRoleFilter, search: userSearch });
      if (res.status === 'success') {
        setUsers(res.users);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const loadKnowledge = async () => {
    try {
      const fRes = await knowledgeService.getFaqs(faqDomain !== 'all' ? faqDomain : null);
      const dRes = await knowledgeService.getDocuments();
      if (fRes.status === 'success') setFaqs(fRes.faqs);
      if (dRes.status === 'success') setDocuments(dRes.documents);
    } catch (e) {
      console.error(e);
    }
  };

  const loadTickets = async () => {
    try {
      const params = {};
      if (ticketFilterStatus !== 'all') params.status = ticketFilterStatus;
      if (ticketFilterDomain !== 'all') params.domain = ticketFilterDomain;
      const res = await ticketService.getTickets(params);
      if (res.status === 'success') setTickets(res.tickets);
    } catch (e) {
      console.error(e);
    }
  };

  const loadAnalytics = async () => {
    try {
      const sRes = await adminService.getAnalyticsSummary();
      const tRes = await adminService.getTopFaqs();
      const uRes = await adminService.getUnanswered();
      if (sRes.status === 'success') setAnalyticsData(sRes.data);
      if (tRes.status === 'success') setTopFaqs(tRes.top_faqs);
      if (uRes.status === 'success') setUnanswered(uRes.unanswered);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (activeTab === 'users') loadUsers();
    if (activeTab === 'knowledge') loadKnowledge();
    if (activeTab === 'tickets') loadTickets();
    if (activeTab === 'analytics') loadAnalytics();
  }, [activeTab, userRoleFilter, userSearch, faqDomain, ticketFilterStatus, ticketFilterDomain]);

  // Actions
  const handleToggleUser = async (userId) => {
    try {
      await adminService.toggleUserStatus(userId);
      showBanner('User active status updated.');
      loadUsers();
    } catch (e) {
      setError('Could not update user status.');
    }
  };

  const handleChangeRole = async (userId, newRole) => {
    try {
      await adminService.updateUserRole(userId, newRole);
      showBanner(`User role updated to ${newRole}.`);
      loadUsers();
    } catch (e) {
      setError('Could not change role.');
    }
  };

  const handleCreateFaq = async (e) => {
    e.preventDefault();
    if (!newFaq.question || !newFaq.answer) return;
    try {
      await knowledgeService.createFaq(newFaq);
      showBanner('FAQ added & vector index rebuilt!');
      setNewFaqModal(false);
      setNewFaq({ domain: 'student', category: 'General', question: '', answer: '', keywords: '' });
      loadKnowledge();
    } catch (e) {
      setError('Could not create FAQ.');
    }
  };

  const handleDeleteFaq = async (faqId) => {
    if (!window.confirm('Delete this FAQ from knowledge base?')) return;
    try {
      await knowledgeService.deleteFaq(faqId);
      showBanner('FAQ deleted and index re-synchronized.');
      loadKnowledge();
    } catch (e) {
      setError('Could not delete FAQ.');
    }
  };

  const handleUploadDoc = async (e) => {
    e.preventDefault();
    if (!uploadFile) return;
    const formData = new FormData();
    formData.append('file', uploadFile);
    formData.append('title', uploadTitle || uploadFile.name);
    formData.append('domain', uploadDomain);
    formData.append('category', uploadCategory);

    try {
      await knowledgeService.uploadDocument(formData);
      showBanner('Document processed, chunked and re-indexed into Vector Store!');
      setUploadFile(null);
      setUploadTitle('');
      loadKnowledge();
    } catch (err) {
      setError(err.response?.data?.message || 'File upload failed.');
    }
  };

  const handleCrawlUrl = async (e) => {
    e.preventDefault();
    if (!crawlUrl.trim()) return;
    setCrawlLoading(true);
    try {
      const res = await knowledgeService.crawlUrl({
        url: crawlUrl.trim(),
        domain: crawlDomain,
        category: crawlCategory
      });
      if (res.status === 'success') {
        showBanner(`Successfully crawled '${res.title}' (${res.chunk_count} chunks indexed)!`);
        setCrawlUrl('');
        loadKnowledge();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to crawl official URL.');
    } finally {
      setCrawlLoading(false);
    }
  };

  const handleReindex = async () => {
    try {
      await knowledgeService.reindex();
      showBanner('All document chunks and FAQs re-indexed into TF-IDF vector space successfully!');
    } catch (e) {
      setError('Re-index failed.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Admin Header */}
        <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border border-slate-800">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>SmartAssist AI Administrator Control Center</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">System Administration</h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Manage knowledge repositories, support tickets, user access roles, and monitor conversational AI metrics.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handleReindex}
              className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md transition-all"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Re-Index Vector Space</span>
            </button>
          </div>
        </div>

        {/* Global Toast Messages */}
        {message && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium rounded-2xl flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>{message}</span>
          </div>
        )}
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 text-red-800 text-xs font-medium rounded-2xl flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex overflow-x-auto space-x-2 p-1.5 bg-white border border-slate-200 rounded-2xl shadow-xs">
          {[
            { id: 'overview', label: 'Dashboard Overview', icon: BarChart3 },
            { id: 'users', label: 'User Management', icon: Users },
            { id: 'knowledge', label: 'Knowledge Base & RAG', icon: FileText },
            { id: 'tickets', label: 'Support Tickets', icon: LifeBuoy },
            { id: 'analytics', label: 'AI Analytics', icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
                  <span>Registered Users</span>
                  <Users className="w-4 h-4 text-indigo-500" />
                </div>
                <div className="text-2xl font-extrabold text-slate-900">{metrics.total_users}</div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {metrics.total_students || 1} Students • {metrics.total_customers || 1} Customers
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
                  <span>AI Queries Processed</span>
                  <MessageSquare className="w-4 h-4 text-purple-500" />
                </div>
                <div className="text-2xl font-extrabold text-slate-900">{metrics.total_queries}</div>
                <div className="text-[11px] text-purple-600 mt-1 font-medium">
                  {metrics.student_queries} Student / {metrics.customer_queries} Customer
                </div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
                  <span>RAG Resolution Rate</span>
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                </div>
                <div className="text-2xl font-extrabold text-emerald-600">{metrics.resolution_rate}%</div>
                <div className="text-[11px] text-slate-400 mt-1">Verified Grounded Answers</div>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
                  <span>Pending Tickets</span>
                  <LifeBuoy className="w-4 h-4 text-amber-500" />
                </div>
                <div className="text-2xl font-extrabold text-amber-600">{metrics.pending_tickets}</div>
                <div className="text-[11px] text-slate-400 mt-1">{metrics.resolved_tickets} Cases Resolved</div>
              </div>
            </div>

            {/* Quick Actions & Recent Stream */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  <span>Recent Conversational Inquiries</span>
                </h3>
                <div className="divide-y divide-slate-100 text-xs">
                  <div className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 block">What is the minimum attendance required?</span>
                      <span className="text-[10px] text-indigo-600 font-medium">[Student Support] Intent: attendance</span>
                    </div>
                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Answered (160ms)</span>
                  </div>
                  <div className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 block">How do I track active package ORD-9821?</span>
                      <span className="text-[10px] text-purple-600 font-medium">[Customer Care] Intent: order_status</span>
                    </div>
                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Answered (175ms)</span>
                  </div>
                  <div className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 block">What is your 30 day refund policy?</span>
                      <span className="text-[10px] text-purple-600 font-medium">[Customer Care] Intent: refund_cancellation</span>
                    </div>
                    <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Answered (190ms)</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <LifeBuoy className="w-4 h-4 text-amber-500" />
                  <span>Urgent Support Action Items</span>
                </h3>
                <div className="space-y-3">
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between font-bold text-amber-900">
                      <span>TCK-STU-1002 (Attendance Condonation)</span>
                      <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded">In Progress</span>
                    </div>
                    <p className="text-slate-600">Student Alex Chen submitted hospital medical discharge summary.</p>
                  </div>

                  <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs space-y-1">
                    <div className="flex items-center justify-between font-bold text-blue-900">
                      <span>TCK-CUST-2001 (API Webhook Auth Error)</span>
                      <span className="text-[10px] bg-blue-200 text-blue-900 px-2 py-0.5 rounded">Open</span>
                    </div>
                    <p className="text-slate-600">Client Acme Corp requested verification for HMAC payload signatures.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: USER MANAGEMENT */}
        {activeTab === 'users' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">User Account Management</h3>
                <p className="text-xs text-slate-500">View registered students, customers, and assign security roles</p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative w-64">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="Search by name or email..."
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <select
                  value={userRoleFilter}
                  onChange={(e) => setUserRoleFilter(e.target.value)}
                  className="text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  <option value="all">All Roles</option>
                  <option value="student">Students</option>
                  <option value="customer">Customers</option>
                  <option value="admin">Administrators</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-y border-slate-200">
                  <tr>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Role</th>
                    <th className="py-3 px-4">Profile Details</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-800">{u.full_name}</div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <select
                          value={u.role}
                          onChange={(e) => handleChangeRole(u.id, e.target.value)}
                          className={`text-xs px-2.5 py-1 rounded-lg border font-semibold ${
                            u.role === 'admin' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                            u.role === 'student' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                            'bg-blue-50 text-blue-700 border-blue-200'
                          }`}
                        >
                          <option value="student">Student</option>
                          <option value="customer">Customer</option>
                          <option value="admin">Administrator</option>
                        </select>
                      </td>
                      <td className="py-3.5 px-4">
                        {u.role === 'student' ? (
                          <span>{u.program || 'B.Tech CS'} • {u.student_id || 'STU01'}</span>
                        ) : u.role === 'customer' ? (
                          <span>{u.company_name || 'Independent Client'}</span>
                        ) : (
                          <span className="text-slate-400">System Admin</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center space-x-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          u.is_active ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}>
                          <span>{u.is_active ? 'Active' : 'Deactivated'}</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => handleToggleUser(u.id)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                            u.is_active
                              ? 'text-red-600 border-red-200 hover:bg-red-50'
                              : 'text-emerald-600 border-emerald-200 hover:bg-emerald-50'
                          }`}
                        >
                          {u.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: KNOWLEDGE BASE & RAG */}
        {activeTab === 'knowledge' && (
          <div className="space-y-6">
            {/* Upload Document Box */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-800 flex items-center space-x-2">
                    <Upload className="w-4 h-4 text-indigo-600" />
                    <span>Upload Knowledge Base Document (PDF / DOCX / TXT / MD)</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Documents are automatically parsed into text, split into semantic overlapping chunks, and indexed into the vector store.
                  </p>
                </div>
              </div>

              <form onSubmit={handleUploadDoc} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Document Title</label>
                  <input
                    type="text"
                    value={uploadTitle}
                    onChange={(e) => setUploadTitle(e.target.value)}
                    placeholder="e.g. Student Academic Regulation 2026"
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Domain</label>
                  <select
                    value={uploadDomain}
                    onChange={(e) => setUploadDomain(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="student">🎓 Student Support</option>
                    <option value="customer">🏢 Customer Support</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Select File</label>
                  <input
                    type="file"
                    onChange={(e) => setUploadFile(e.target.files[0])}
                    className="w-full text-xs text-slate-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                    required
                  />
                </div>

                <div>
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-xl text-xs font-semibold shadow-sm transition-all flex items-center justify-center space-x-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload & Re-Index</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Ingest from Official Website URL Box */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-800 flex items-center space-x-2">
                    <Globe className="w-4 h-4 text-emerald-600" />
                    <span>Ingest Official Website URL (Live Web Crawler)</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Crawl admissions pages, official fee notices, syllabi, or enterprise service terms directly from the live web.
                  </p>
                </div>
              </div>

              <form onSubmit={handleCrawlUrl} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Official Website URL</label>
                  <input
                    type="url"
                    value={crawlUrl}
                    onChange={(e) => setCrawlUrl(e.target.value)}
                    placeholder="https://example-university.edu/admissions or policies"
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Domain</label>
                  <select
                    value={crawlDomain}
                    onChange={(e) => setCrawlDomain(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="student">🎓 Student Support</option>
                    <option value="customer">🏢 Customer Support</option>
                  </select>
                </div>

                <div>
                  <button
                    type="submit"
                    disabled={crawlLoading}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 rounded-xl text-xs font-semibold shadow-sm transition-all flex items-center justify-center space-x-1.5 disabled:opacity-50"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>{crawlLoading ? 'Crawling & Indexing...' : 'Crawl & Ingest URL'}</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Indexed Documents Table */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                <FileText className="w-4 h-4 text-purple-600" />
                <span>Indexed Documents in RAG Vector Store ({documents.length})</span>
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-50 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-y border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4">Title</th>
                      <th className="py-2.5 px-4">Domain</th>
                      <th className="py-2.5 px-4">Category</th>
                      <th className="py-2.5 px-4">Vector Chunks</th>
                      <th className="py-2.5 px-4">Date</th>
                      <th className="py-2.5 px-4 text-right">Delete</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {documents.map((doc) => (
                      <tr key={doc.id}>
                        <td className="py-3 px-4 font-semibold text-slate-800">{doc.title}</td>
                        <td className="py-3 px-4 capitalize font-medium text-indigo-600">{doc.domain}</td>
                        <td className="py-3 px-4">{doc.category}</td>
                        <td className="py-3 px-4 font-bold text-slate-700">{doc.chunk_total || doc.chunk_count} Chunks</td>
                        <td className="py-3 px-4 text-slate-400">{new Date(doc.created_at).toLocaleDateString()}</td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={async () => {
                              if (window.confirm('Delete document?')) {
                                await knowledgeService.deleteDocument(doc.id);
                                showBanner('Document deleted.');
                                loadKnowledge();
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* FAQs Management Section */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h3 className="text-base font-bold text-slate-800">Verified FAQs ({faqs.length})</h3>
                  <p className="text-xs text-slate-500">Edit, add, or remove verified question-answer pairs</p>
                </div>

                <div className="flex items-center space-x-2">
                  <select
                    value={faqDomain}
                    onChange={(e) => setFaqDomain(e.target.value)}
                    className="text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="all">All Domains</option>
                    <option value="student">Student Support</option>
                    <option value="customer">Customer Care</option>
                  </select>

                  <button
                    onClick={() => setNewFaqModal(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1 shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add FAQ</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
                {faqs.map((faq) => (
                  <div key={faq.id} className="p-3.5 border border-slate-200 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[10px] font-bold text-indigo-600 uppercase bg-indigo-50 px-2 py-0.5 rounded">
                        [{faq.domain}] {faq.category}
                      </span>
                      <button
                        onClick={() => handleDeleteFaq(faq.id)}
                        className="text-slate-400 hover:text-red-600 p-1 rounded"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="text-xs font-bold text-slate-900">{faq.question}</div>
                    <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SUPPORT TICKETS */}
        {activeTab === 'tickets' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Support Ticket Management</h3>
                <p className="text-xs text-slate-500">Respond to escalated queries, set priorities, and mark tickets as resolved</p>
              </div>

              <div className="flex items-center space-x-2">
                <select
                  value={ticketFilterDomain}
                  onChange={(e) => setTicketFilterDomain(e.target.value)}
                  className="text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  <option value="all">All Domains</option>
                  <option value="student">Student</option>
                  <option value="customer">Customer</option>
                </select>

                <select
                  value={ticketFilterStatus}
                  onChange={(e) => setTicketFilterStatus(e.target.value)}
                  className="text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  <option value="all">All Statuses</option>
                  <option value="open">Open</option>
                  <option value="in_progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                </select>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-700 uppercase tracking-wider border-y border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Ticket</th>
                    <th className="py-3 px-4">Subject</th>
                    <th className="py-3 px-4">User</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {tickets.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3.5 px-4 font-bold text-slate-800">{t.ticket_number}</td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{t.subject}</div>
                        <div className="text-[10px] text-slate-400">[{t.domain}] {t.category}</div>
                      </td>
                      <td className="py-3.5 px-4">{t.user_name || 'User'}</td>
                      <td className="py-3.5 px-4 capitalize">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          t.priority === 'urgent' || t.priority === 'high' ? 'bg-red-100 text-red-800' :
                          t.priority === 'medium' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {t.priority}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          t.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' :
                          t.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {t.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => {
                            setSelectedTicketId(t.id);
                            setTicketModalOpen(true);
                          }}
                          className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold px-3 py-1.5 rounded-lg text-xs"
                        >
                          View & Reply
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5: AI ANALYTICS */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            {/* Visual Analytics Chart Strip */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Daily Trend Chart */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-indigo-600" />
                  <span>Daily AI Query Traffic (Past 7 Days)</span>
                </h3>
                <div className="h-48 flex items-end justify-between gap-3 pt-6 px-2">
                  {analyticsData?.trends?.map((item, idx) => {
                    const maxH = 160;
                    const height = Math.min(maxH, Math.max(30, item.count * 2.5));
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-1 group">
                        <div className="text-[10px] font-bold text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
                          {item.count}
                        </div>
                        <div
                          style={{ height: `${height}px` }}
                          className="w-full bg-gradient-to-t from-indigo-600 to-purple-500 rounded-t-lg shadow-xs group-hover:brightness-110 transition-all"
                        />
                        <span className="text-[9px] text-slate-400 mt-1">{item.query_date.slice(5)}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Domain & Intent Distribution */}
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center space-x-2">
                  <BarChart3 className="w-4 h-4 text-purple-600" />
                  <span>Top User Query Intents</span>
                </h3>
                <div className="space-y-2.5 pt-2">
                  {analyticsData?.intents?.map((intent, idx) => (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-800 capitalize">{intent.intent.replace('_', ' ')}</span>
                        <span className="text-slate-500">{intent.count} queries</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full"
                          style={{ width: `${Math.min(100, intent.count * 12)}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Unanswered Queries Log */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-800 flex items-center space-x-2">
                  <HelpCircle className="w-4 h-4 text-amber-500" />
                  <span>Unanswered / Low-Confidence Queries Log</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Queries that triggered the strict-guardrail fallback. Add verified answers to expand knowledge base.
                </p>
              </div>

              {unanswered.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">
                  No unanswered queries recorded. RAG engine coverage is 100%.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 text-xs">
                  {unanswered.map((q) => (
                    <div key={q.id} className="py-3 flex items-center justify-between gap-4">
                      <div>
                        <span className="font-bold text-slate-800 block">"{q.query_text}"</span>
                        <span className="text-[10px] text-slate-400">Domain: {q.domain} • Method: {q.resolution_method}</span>
                      </div>
                      <button
                        onClick={() => {
                          setNewFaq({
                            domain: q.domain,
                            category: 'General',
                            question: q.query_text,
                            answer: '',
                            keywords: q.intent || ''
                          });
                          setActiveTab('knowledge');
                          setNewFaqModal(true);
                        }}
                        className="text-indigo-600 hover:text-indigo-700 font-semibold px-2.5 py-1 rounded bg-indigo-50 border border-indigo-200"
                      >
                        + Create FAQ for this Query
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Ticket Modal */}
      <TicketModal
        isOpen={ticketModalOpen}
        onClose={() => setTicketModalOpen(false)}
        ticketId={selectedTicketId}
        onSuccess={() => {
          loadTickets();
          loadOverview();
        }}
      />

      {/* Add FAQ Modal */}
      {newFaqModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900">Add New Verified FAQ</h3>
            <form onSubmit={handleCreateFaq} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Domain</label>
                  <select
                    value={newFaq.domain}
                    onChange={(e) => setNewFaq({ ...newFaq, domain: e.target.value })}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="student">Student</option>
                    <option value="customer">Customer</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={newFaq.category}
                    onChange={(e) => setNewFaq({ ...newFaq, category: e.target.value })}
                    placeholder="Admissions / Pricing"
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Question</label>
                <input
                  type="text"
                  value={newFaq.question}
                  onChange={(e) => setNewFaq({ ...newFaq, question: e.target.value })}
                  placeholder="e.g. What is the fee structure?"
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Answer</label>
                <textarea
                  rows={4}
                  value={newFaq.answer}
                  onChange={(e) => setNewFaq({ ...newFaq, answer: e.target.value })}
                  placeholder="Official verified answer..."
                  className="w-full text-xs p-3 bg-slate-50 border border-slate-300 rounded-xl"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Search Keywords</label>
                <input
                  type="text"
                  value={newFaq.keywords}
                  onChange={(e) => setNewFaq({ ...newFaq, keywords: e.target.value })}
                  placeholder="fee, tuition, semester, deadline"
                  className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setNewFaqModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl"
                >
                  Save & Index
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
