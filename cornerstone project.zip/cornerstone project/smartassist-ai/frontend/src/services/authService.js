import api from './api';

export const authService = {
  async login(email, password) {
    const res = await api.post('/auth/login', { email, password });
    if (res.data.token) {
      localStorage.setItem('smartassist_token', res.data.token);
      localStorage.setItem('smartassist_user', JSON.stringify(res.data.user));
    }
    return res.data;
  },

  async register(userData) {
    const res = await api.post('/auth/register', userData);
    if (res.data.token) {
      localStorage.setItem('smartassist_token', res.data.token);
      localStorage.setItem('smartassist_user', JSON.stringify(res.data.user));
    }
    return res.data;
  },

  async getMe() {
    const res = await api.get('/auth/me');
    return res.data;
  },

  logout() {
    localStorage.removeItem('smartassist_token');
    localStorage.removeItem('smartassist_user');
  },

  getStoredToken() {
    return localStorage.getItem('smartassist_token');
  },

  getStoredUser() {
    const u = localStorage.getItem('smartassist_user');
    return u ? JSON.parse(u) : null;
  }
};
