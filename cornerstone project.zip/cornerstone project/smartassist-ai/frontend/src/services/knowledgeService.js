import api from './api';

export const knowledgeService = {
  async getFaqs(domain = null, category = null) {
    const params = {};
    if (domain) params.domain = domain;
    if (category) params.category = category;
    const res = await api.get('/knowledge/faqs', { params });
    return res.data;
  },

  async createFaq(faqData) {
    const res = await api.post('/knowledge/faqs', faqData);
    return res.data;
  },

  async updateFaq(id, faqData) {
    const res = await api.put(`/knowledge/faqs/${id}`, faqData);
    return res.data;
  },

  async deleteFaq(id) {
    const res = await api.delete(`/knowledge/faqs/${id}`);
    return res.data;
  },

  async getDocuments() {
    const res = await api.get('/knowledge/documents');
    return res.data;
  },

  async uploadDocument(formData) {
    const res = await api.post('/knowledge/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return res.data;
  },

  async deleteDocument(id) {
    const res = await api.delete(`/knowledge/documents/${id}`);
    return res.data;
  },

  async reindex() {
    const res = await api.post('/knowledge/reindex');
    return res.data;
  },

  async crawlUrl(payload) {
    const res = await api.post('/knowledge/crawl-url', payload);
    return res.data;
  }
};
