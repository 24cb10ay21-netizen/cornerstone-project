import api from './api';

export const adminService = {
  async getOverview() {
    const res = await api.get('/admin/overview');
    return res.data;
  },

  async getUsers(params = {}) {
    const res = await api.get('/admin/users', { params });
    return res.data;
  },

  async updateUserRole(userId, role) {
    const res = await api.patch(`/admin/users/${userId}/role`, { role });
    return res.data;
  },

  async toggleUserStatus(userId) {
    const res = await api.patch(`/admin/users/${userId}/status`);
    return res.data;
  },

  async getAnalyticsSummary() {
    const res = await api.get('/analytics/summary');
    return res.data;
  },

  async getTopFaqs() {
    const res = await api.get('/analytics/top-faqs');
    return res.data;
  },

  async getUnanswered() {
    const res = await api.get('/analytics/unanswered');
    return res.data;
  }
};
