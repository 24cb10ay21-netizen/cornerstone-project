import api from './api';

export const chatService = {
  async sendMessage(query, domain = 'student', conversation_id = null) {
    const res = await api.post('/chat/message', { query, domain, conversation_id });
    return res.data;
  },

  async getConversations(domain = null) {
    const params = domain ? { domain } : {};
    const res = await api.get('/chat/conversations', { params });
    return res.data;
  },

  async getConversationDetail(id) {
    const res = await api.get(`/chat/conversations/${id}`);
    return res.data;
  },

  async deleteConversation(id) {
    const res = await api.delete(`/chat/conversations/${id}`);
    return res.data;
  },

  async sendFeedback(message_id, rating) {
    const res = await api.post('/chat/feedback', { message_id, rating });
    return res.data;
  },

  async escalateToTicket(payload) {
    const res = await api.post('/chat/escalate-ticket', payload);
    return res.data;
  }
};
