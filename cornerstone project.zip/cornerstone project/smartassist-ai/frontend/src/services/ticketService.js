import api from './api';

export const ticketService = {
  async getTickets(filters = {}) {
    const res = await api.get('/tickets', { params: filters });
    return res.data;
  },

  async createTicket(ticketData) {
    const res = await api.post('/tickets', ticketData);
    return res.data;
  },

  async getTicketDetail(id) {
    const res = await api.get(`/tickets/${id}`);
    return res.data;
  },

  async addResponse(id, message) {
    const res = await api.post(`/tickets/${id}/respond`, { message });
    return res.data;
  },

  async updateStatus(id, statusData) {
    const res = await api.patch(`/tickets/${id}/status`, statusData);
    return res.data;
  }
};
