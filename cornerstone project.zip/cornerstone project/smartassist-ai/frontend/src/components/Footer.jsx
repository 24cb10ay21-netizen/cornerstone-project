import React from 'react';
import { Bot, Heart, Sparkles, Shield, Cpu, Cloud } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="col-span-1 md:col-span-1 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
                <Bot className="w-5 h-5" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">SmartAssist AI</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Cloud-Based AI Support Engine with verified Retrieval-Augmented Generation (RAG) for academic institutions and enterprise businesses.
            </p>
            <div className="flex items-center space-x-2 text-xs text-indigo-400 font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Cornerstone Academic Project</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">Support Portals</h4>
            <ul className="space-y-2 text-xs">
              <li><a href="/student" className="hover:text-indigo-400 transition-colors">Student Admissions & FAQs</a></li>
              <li><a href="/student" className="hover:text-indigo-400 transition-colors">Examination Schedules</a></li>
              <li><a href="/customer" className="hover:text-indigo-400 transition-colors">Customer Care & Tracking</a></li>
              <li><a href="/customer" className="hover:text-indigo-400 transition-colors">Return & Refund Policy</a></li>
              <li><a href="/tickets" className="hover:text-indigo-400 transition-colors">Ticket Escalation Desk</a></li>
            </ul>
          </div>

          {/* Core Tech Stack */}
          <div>
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-3">Architectural Stack</h4>
            <ul className="space-y-2 text-xs">
              <li className="flex items-center space-x-1.5"><Cpu className="w-3 h-3 text-indigo-400" /><span>RAG & Vector Embeddings</span></li>
              <li className="flex items-center space-x-1.5"><Bot className="w-3 h-3 text-purple-400" /><span>NLU & Intent Classification</span></li>
              <li className="flex items-center space-x-1.5"><Cloud className="w-3 h-3 text-cyan-400" /><span>REST API & Docker Container</span></li>
              <li className="flex items-center space-x-1.5"><Shield className="w-3 h-3 text-emerald-400" /><span>Role-Based Access Control</span></li>
            </ul>
          </div>

          {/* Demonstration Credentials */}
          <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 space-y-2">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider">Demo Credentials</h4>
            <div className="text-[11px] space-y-1">
              <div><span className="text-indigo-300 font-medium">Admin:</span> admin@smartassist.edu / admin123</div>
              <div><span className="text-indigo-300 font-medium">Student:</span> alex.student@smartassist.edu / student123</div>
              <div><span className="text-indigo-300 font-medium">Customer:</span> sarah.buyer@acmecorp.com / customer123</div>
            </div>
            <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-700">
              *Sample data pre-seeded for demonstration
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500">
          <p>© {new Date().getFullYear()} SmartAssist AI. Developed for B.Tech Computer Science Cornerstone Project.</p>
          <p className="mt-2 sm:mt-0 flex items-center space-x-1">
            <span>Built with precision and high-accuracy AI pipelines</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
