import React, { useState, useEffect } from 'react';
import { 
  X, 
  LifeBuoy, 
  Send, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  User, 
  ShieldCheck,
  Tag,
  Calendar
} from 'lucide-react';
import { ticketService } from '../services/ticketService';
import { useAuth } from '../context/AuthContext';

export default function TicketModal({ 
  isOpen, 
  onClose, 
  ticketId = null, 
  prefilled = {}, 
  onSuccess = null 
}) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [ticket, setTicket] = useState(null);
  const [responses, setResponses] = useState([]);
  const [replyText, setReplyText] = useState('');
  
  // New ticket form state
  const [subject, setSubject] = useState(prefilled.subject || '');
  const [description, setDescription] = useState(prefilled.description || '');
  const [domain, setDomain] = useState(prefilled.domain || (user?.role === 'customer' ? 'customer' : 'student'));
  const [category, setCategory] = useState(prefilled.category || (domain === 'student' ? 'Admissions' : 'Technical Support'));
  const [priority, setPriority] = useState(prefilled.priority || 'medium');
  const [error, setError] = useState('');

  useEffect(() => {
    if (prefilled.subject) setSubject(prefilled.subject);
    if (prefilled.description) setDescription(prefilled.description);
    if (prefilled.domain) setDomain(prefilled.domain);
    if (prefilled.category) setCategory(prefilled.category);
  }, [prefilled]);

  useEffect(() => {
    if (isOpen && ticketId) {
      loadTicketDetails();
    } else {
      setTicket(null);
      setResponses([]);
    }
  }, [isOpen, ticketId]);

  const loadTicketDetails = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await ticketService.getTicketDetail(ticketId);
      if (res.status === 'success') {
        setTicket(res.ticket);
        setResponses(res.responses || []);
      }
    } catch (err) {
      setError('Could not load ticket details.');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTicket = async (e) => {
    e.preventDefault();
    if (!subject.trim() || !description.trim()) {
      setError('Subject and description are required.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await ticketService.createTicket({
        subject,
        description,
        domain,
        category,
        priority
      });
      if (res.status === 'success') {
        if (onSuccess) onSuccess(res.ticket);
        onClose();
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create ticket.');
    } finally {
      setLoading(false);
    }
  };

  const handleSendReply = async (e) => {
    e.preventDefault();
    if (!replyText.trim() || !ticketId) return;
    setLoading(true);
    try {
      await ticketService.addResponse(ticketId, replyText.trim());
      setReplyText('');
      await loadTicketDetails();
      if (onSuccess) onSuccess();
    } catch (err) {
      setError('Failed to send response.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <LifeBuoy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">
                {ticketId ? `Ticket ${ticket?.ticket_number || `#${ticketId}`}` : 'Create Support Ticket'}
              </h3>
              <p className="text-xs text-slate-400">
                {ticketId ? 'Official Support Thread & Updates' : 'Direct Escalation to Human Support Administration'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {ticketId ? (
            /* VIEW TICKET DETAIL & THREAD */
            <div className="space-y-5">
              {/* Ticket Summary Card */}
              {ticket && (
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/90 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-sm font-bold text-slate-800">{ticket.subject}</span>
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                      ticket.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' :
                      ticket.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {ticket.status.replace('_', ' ')}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed bg-white p-3 rounded-lg border border-slate-200">
                    {ticket.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1">
                    <span className="flex items-center space-x-1">
                      <Tag className="w-3.5 h-3.5 text-slate-400" />
                      <span>Category: <strong className="text-slate-700">{ticket.category}</strong></span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>Priority: <strong className="text-slate-700 capitalize">{ticket.priority}</strong></span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>Created: {new Date(ticket.created_at).toLocaleDateString()}</span>
                    </span>
                  </div>
                </div>
              )}

              {/* Thread Responses */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Conversation Thread ({responses.length})
                </h4>
                <div className="space-y-3">
                  {responses.map((resp) => (
                    <div
                      key={resp.id}
                      className={`p-3.5 rounded-xl border text-xs leading-relaxed ${
                        resp.sender_role === 'admin'
                          ? 'bg-indigo-50/70 border-indigo-200/80 text-indigo-950 ml-4'
                          : 'bg-white border-slate-200 text-slate-800 mr-4'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-black/5">
                        <span className="font-semibold flex items-center space-x-1.5">
                          {resp.sender_role === 'admin' ? (
                            <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                          ) : (
                            <User className="w-3.5 h-3.5 text-slate-500" />
                          )}
                          <span>{resp.sender_name}</span>
                          <span className="text-[10px] text-slate-400 capitalize">({resp.sender_role})</span>
                        </span>
                        <span className="text-[10px] text-slate-400">{new Date(resp.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <p className="whitespace-pre-wrap">{resp.message}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSendReply} className="pt-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type a reply to the support administration..."
                    className="flex-1 text-xs sm:text-sm px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    disabled={loading}
                  />
                  <button
                    type="submit"
                    disabled={!replyText.trim() || loading}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 shadow-sm disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            /* CREATE TICKET FORM */
            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Support Domain</label>
                  <select
                    value={domain}
                    onChange={(e) => {
                      setDomain(e.target.value);
                      setCategory(e.target.value === 'student' ? 'Admissions' : 'Technical Support');
                    }}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="student">🎓 Student Support</option>
                    <option value="customer">🏢 Customer Support</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {domain === 'student' ? (
                      <>
                        <option value="Admissions">Admissions & Eligibility</option>
                        <option value="Courses & Syllabus">Courses & Syllabus</option>
                        <option value="Examinations">Examinations & Hall Tickets</option>
                        <option value="Attendance">Attendance Condonation</option>
                        <option value="Fee Structure">Fee Structure & Receipts</option>
                        <option value="Scholarships">Scholarships & Aid</option>
                        <option value="Placements">Placements & Internships</option>
                        <option value="Facilities">Hostel, Mess & Library</option>
                      </>
                    ) : (
                      <>
                        <option value="Technical Support">Technical Support</option>
                        <option value="Order Status">Order & Shipping Status</option>
                        <option value="Pricing & Billing">Pricing & Invoices</option>
                        <option value="Refund & Cancellation">Refund & Cancellation</option>
                        <option value="Complaints">Complaint Registration</option>
                        <option value="Product Information">Product Specifications</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Subject</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Discrepancy in Semester Fee Payment Receipt"
                  className="w-full text-xs sm:text-sm px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Detailed Description</label>
                <textarea
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide all relevant details, error codes, dates, or student/order IDs..."
                  className="w-full text-xs sm:text-sm p-3.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Priority Level</label>
                <div className="grid grid-cols-4 gap-2">
                  {['low', 'medium', 'high', 'urgent'].map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => setPriority(p)}
                      className={`text-xs py-2 rounded-xl capitalize font-medium border transition-all ${
                        priority === p
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm transition-all disabled:opacity-50 flex items-center space-x-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{loading ? 'Creating...' : 'Submit Support Ticket'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
