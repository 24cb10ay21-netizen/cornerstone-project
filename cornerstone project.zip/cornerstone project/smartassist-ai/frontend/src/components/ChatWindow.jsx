import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  ThumbsUp, 
  ThumbsDown, 
  RotateCcw, 
  LifeBuoy, 
  ExternalLink, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { chatService } from '../services/chatService';

export default function ChatWindow({ 
  domain = 'student', 
  initialSuggestions = [], 
  onEscalate = null,
  title = null,
  subtitle = null
}) {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      sender: 'assistant',
      text: domain === 'student'
        ? "Hello! 👋 I am your **SmartAssist Student AI Advisor**. Ask me about admissions, fees, exam timetables, scholarships, attendance criteria, syllabus, or placement drives!"
        : "Welcome to **SmartAssist Customer Support**! 🛍️ I can assist with product specifications, order tracking updates, pricing quotes, return/refund policies, and troubleshooting.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sources: [],
      suggested_questions: initialSuggestions.length > 0 ? initialSuggestions : (
        domain === 'student' ? [
          "What is the minimum attendance requirement for exams?",
          "How can I apply for merit scholarships?",
          "When will the semester exam datesheet be released?"
        ] : [
          "How do I track my active order package?",
          "What is your 30-day return and refund policy?",
          "Are discounts available for educational institutions?"
        ]
      )
    }
  ]);
  
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const [feedbackGiven, setFeedbackGiven] = useState({});
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (queryText = null) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const userTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsg = {
      id: `user_${Date.now()}`,
      sender: 'user',
      text: textToSend.trim(),
      timestamp: userTimestamp
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInputQuery('');
    setLoading(true);

    try {
      const res = await chatService.sendMessage(textToSend.trim(), domain, conversationId);
      if (res.status === 'success' && res.data) {
        const d = res.data;
        if (d.conversation_id) {
          setConversationId(d.conversation_id);
        }

        const aiMsg = {
          id: d.assistant_message_id || `ai_${Date.now()}`,
          sender: 'assistant',
          text: d.answer,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources: d.sources || [],
          suggested_questions: d.suggested_questions || [],
          can_escalate: d.can_escalate || d.is_fallback,
          engine: d.engine,
          is_fallback: d.is_fallback,
          latency: d.response_time_ms,
          originalQuery: textToSend.trim()
        };

        setMessages((prev) => [...prev, aiMsg]);
      }
    } catch (err) {
      console.error("Chat error:", err);
      const errorMsg = {
        id: `err_${Date.now()}`,
        sender: 'assistant',
        text: "⚠️ **Connection Notice:** Unable to reach the AI assistant. Please verify that the backend server is running on `http://127.0.0.1:5000`.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: [],
        suggested_questions: [],
        can_escalate: true,
        is_fallback: true
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleFeedback = async (messageId, rating) => {
    if (feedbackGiven[messageId]) return;
    setFeedbackGiven((prev) => ({ ...prev, [messageId]: rating }));
    try {
      await chatService.sendFeedback(messageId, rating);
    } catch (e) {
      // ignore
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'welcome_reset',
        sender: 'assistant',
        text: `Chat reset. What else would you like to know about ${domain === 'student' ? 'SmartAssist University' : 'SmartAssist AI Suite'}?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggested_questions: domain === 'student' ? [
          "What is the eligibility for B.Tech CS?",
          "What are the library hours?",
          "Tell me about campus placements and recruiters"
        ] : [
          "Is SmartAssist compatible with Salesforce CRM?",
          "What subscription tiers are available?",
          "How do I submit product feedback?"
        ]
      }
    ]);
    setConversationId(null);
  };

  // Helper to format basic markdown (bold, lists, headers)
  const renderFormattedText = (text) => {
    const lines = text.split('\n');
    return lines.map((line, idx) => {
      let content = line;
      if (line.startsWith('### ')) {
        return <h3 key={idx} className="text-sm font-bold text-slate-800 mt-2 mb-1">{line.replace('### ', '')}</h3>;
      }
      if (line.startsWith('#### ')) {
        return <h4 key={idx} className="text-xs font-bold text-slate-700 mt-1.5 mb-0.5">{line.replace('#### ', '')}</h4>;
      }
      if (line.startsWith('- ')) {
        return (
          <li key={idx} className="text-xs text-slate-700 list-disc ml-4 my-0.5">
            {formatBold(line.replace('- ', ''))}
          </li>
        );
      }
      if (line.trim() === '---') {
        return <hr key={idx} className="my-2 border-slate-200" />;
      }
      if (!line.trim()) {
        return <div key={idx} className="h-1.5" />;
      }
      return <p key={idx} className="text-xs leading-relaxed text-slate-700">{formatBold(line)}</p>;
    });
  };

  const formatBold = (str) => {
    const parts = str.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="flex flex-col h-[650px] bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
      {/* Chat Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-4 text-white flex items-center justify-between border-b border-indigo-900/50">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${
              domain === 'student' 
                ? 'bg-gradient-to-tr from-indigo-500 to-indigo-700' 
                : 'bg-gradient-to-tr from-purple-500 to-purple-700'
            }`}>
              <Bot className="w-5 h-5 text-white" />
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-slate-900 rounded-full" />
          </div>
          <div>
            <h3 className="text-sm font-bold flex items-center space-x-2">
              <span>{title || (domain === 'student' ? 'Student AI Assistant' : 'Customer Care Bot')}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                domain === 'student' ? 'bg-indigo-500/30 text-indigo-200 border border-indigo-400/30' : 'bg-purple-500/30 text-purple-200 border border-purple-400/30'
              }`}>
                {domain === 'student' ? 'Academic RAG' : 'Enterprise RAG'}
              </span>
            </h3>
            <p className="text-[11px] text-slate-400 flex items-center space-x-1.5">
              <span>{subtitle || 'Grounded on verified official knowledge documents'}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleClearChat}
            className="text-xs text-slate-400 hover:text-white flex items-center space-x-1 bg-white/5 hover:bg-white/10 px-2.5 py-1.5 rounded-lg transition-colors border border-white/10"
            title="Reset Conversation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-slate-50/60">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-end space-x-2 max-w-[88%] sm:max-w-[80%]">
              {msg.sender === 'assistant' && (
                <div className={`w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center text-white mb-1 shadow-sm ${
                  domain === 'student' ? 'bg-indigo-600' : 'bg-purple-600'
                }`}>
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`p-3.5 sm:p-4 rounded-2xl shadow-sm ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-br-none'
                    : 'bg-white border border-slate-200/90 text-slate-800 rounded-bl-none'
                }`}
              >
                {/* Message Body */}
                <div className="space-y-1">
                  {msg.sender === 'user' ? (
                    <p className="text-xs sm:text-sm font-normal leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                  ) : (
                    <div className="prose-xs">
                      {renderFormattedText(msg.text)}
                    </div>
                  )}
                </div>

                {/* Assistant Citations & Verified Sources */}
                {msg.sender === 'assistant' && msg.sources && msg.sources.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      <span>Verified Knowledge Sources:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.map((src, i) => (
                        <span
                          key={i}
                          className="inline-flex items-center space-x-1 text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md border border-slate-200"
                        >
                          <span className="font-semibold text-indigo-600">[{src.category}]</span>
                          <span>{src.title}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Human Escalation Trigger button */}
                {msg.can_escalate && onEscalate && (
                  <div className="mt-3 pt-2.5 border-t border-amber-100 bg-amber-50/50 p-2.5 rounded-lg border">
                    <p className="text-[11px] text-amber-800 font-medium mb-2 flex items-center space-x-1.5">
                      <LifeBuoy className="w-4 h-4 text-amber-600 flex-shrink-0" />
                      <span>Need human administration assistance for this query?</span>
                    </p>
                    <button
                      onClick={() => onEscalate({
                        subject: msg.originalQuery ? `Escalated Query: ${msg.originalQuery.slice(0, 50)}` : 'Assistance Needed',
                        description: msg.originalQuery || 'Need assistance with specific request.',
                        domain: domain
                      })}
                      className="w-full sm:w-auto inline-flex items-center justify-center space-x-1.5 text-xs font-semibold bg-amber-500 hover:bg-amber-600 text-white px-3.5 py-1.5 rounded-lg shadow-sm transition-colors"
                    >
                      <LifeBuoy className="w-3.5 h-3.5" />
                      <span>Open Support Ticket Now</span>
                    </button>
                  </div>
                )}

                {/* Footer bar inside bubble */}
                <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-black/5 text-[10px]">
                  <span className={`${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'} flex items-center space-x-1`}>
                    <Clock className="w-2.5 h-2.5" />
                    <span>{msg.timestamp}</span>
                    {msg.latency && <span className="ml-1 text-[9px] text-slate-400">({msg.latency}ms)</span>}
                  </span>

                  {msg.sender === 'assistant' && msg.id !== 'welcome' && (
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] text-slate-400 mr-1">Helpful?</span>
                      <button
                        onClick={() => handleFeedback(msg.id, 1)}
                        className={`p-1 rounded hover:bg-slate-100 transition-colors ${
                          feedbackGiven[msg.id] === 1 ? 'text-emerald-600 bg-emerald-50' : 'text-slate-400'
                        }`}
                        title="Yes, helpful"
                      >
                        <ThumbsUp className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleFeedback(msg.id, -1)}
                        className={`p-1 rounded hover:bg-slate-100 transition-colors ${
                          feedbackGiven[msg.id] === -1 ? 'text-rose-600 bg-rose-50' : 'text-slate-400'
                        }`}
                        title="Not helpful"
                      >
                        <ThumbsDown className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg flex-shrink-0 bg-slate-800 flex items-center justify-center text-white mb-1 shadow-sm">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>

            {/* Suggested Question Chips */}
            {msg.sender === 'assistant' && msg.suggested_questions && msg.suggested_questions.length > 0 && (
              <div className="ml-9 mt-2 flex flex-wrap gap-1.5 max-w-[85%]">
                {msg.suggested_questions.map((suggestion, sIdx) => (
                  <button
                    key={sIdx}
                    onClick={() => handleSend(suggestion)}
                    className="text-[11px] font-medium bg-white hover:bg-indigo-50 text-indigo-700 hover:text-indigo-800 border border-indigo-200/80 px-2.5 py-1 rounded-full shadow-xs transition-all hover:border-indigo-300 flex items-center space-x-1"
                  >
                    <span>{suggestion}</span>
                    <ChevronRight className="w-3 h-3 text-indigo-400" />
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Typing indicator */}
        {loading && (
          <div className="flex items-end space-x-2">
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-white ${
              domain === 'student' ? 'bg-indigo-600' : 'bg-purple-600'
            }`}>
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-bl-none shadow-sm flex items-center space-x-1.5">
              <span className="text-xs text-slate-500 font-medium mr-1">Synthesizing verified answer</span>
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '0ms' }} />
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '150ms' }} />
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box Footer */}
      <div className="p-3.5 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center space-x-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder={domain === 'student' ? "Ask about admissions, fee due dates, exam syllabus, hostels..." : "Ask about product specs, pricing, tracking ORD-9821, refunds..."}
              className="w-full text-xs sm:text-sm pl-4 pr-10 py-3 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all placeholder:text-slate-400"
              disabled={loading}
            />
            {inputQuery && (
              <button
                type="button"
                onClick={() => setInputQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={!inputQuery.trim() || loading}
            className={`p-3 rounded-xl flex items-center justify-center text-white transition-all shadow-md ${
              inputQuery.trim() && !loading
                ? (domain === 'student' ? 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/20' : 'bg-purple-600 hover:bg-purple-700 shadow-purple-500/20')
                : 'bg-slate-300 cursor-not-allowed shadow-none'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2 px-1">
          <span className="flex items-center space-x-1">
            <Sparkles className="w-3 h-3 text-indigo-500" />
            <span>Strict zero-hallucination verification active</span>
          </span>
          {onEscalate && (
            <button
              onClick={() => onEscalate({
                subject: 'Support Assistance Request',
                description: '',
                domain: domain
              })}
              className="hover:text-indigo-600 font-medium flex items-center space-x-1"
            >
              <LifeBuoy className="w-3 h-3" />
              <span>Escalate to Human Agent</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
