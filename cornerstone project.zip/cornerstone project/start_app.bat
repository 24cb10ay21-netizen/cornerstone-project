@echo off
TITLE SmartAssist AI - Full-Stack AI Platform
echo ========================================================
echo       Starting SmartAssist AI Application
echo   Dual-Domain Student and Customer Support System
echo ========================================================
echo.

cd smartassist-ai\backend
python main.py
pause
