# SmartAssist AI - Cloud-Based AI Support Platform

This workspace contains the complete **SmartAssist AI** Cornerstone Project.

### Quick Start
To launch the complete application (Frontend + Backend on `http://127.0.0.1:5000`):
- **Windows:** Double-click `start_app.bat` or run:
  ```powershell
  cd smartassist-ai\backend
  python main.py
  ```
- **Linux/macOS:** Run `./start_app.sh`

### Demo Credentials
- **Admin:** `admin@smartassist.edu` / `admin123`
- **Student:** `alex.student@smartassist.edu` / `student123`
- **Customer:** `sarah.buyer@acmecorp.com` / `customer123`

Please refer to [`smartassist-ai/README.md`](smartassist-ai/README.md) and [`smartassist-ai/docs/`](smartassist-ai/docs/) for complete architectural documentation, ER diagrams, test execution guides, and API specifications.
